--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

-- Started on 2025-07-04 02:43:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 248 (class 1255 OID 16967)
-- Name: create_comment(integer, integer, text, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_comment(IN p_member_id integer, IN p_review_id integer, IN p_content text, IN p_parent_id integer DEFAULT NULL::integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Error handling: content must not be empty
    IF TRIM(p_content) = '' THEN
        RAISE EXCEPTION 'Comment content cannot be empty.';
    END IF;

    -- Optional: Check if review exists
    IF NOT EXISTS (SELECT 1 FROM review WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review does not exist.';
    END IF;

    INSERT INTO comment (member_id, review_id, content, parent_id)
    VALUES (p_member_id, p_review_id, p_content, p_parent_id);
END;
$$;


--
-- TOC entry 251 (class 1255 OID 16964)
-- Name: create_review(integer, integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_review(IN p_member_id integer, IN p_product_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check for missing/null required fields
    IF p_product_id IS NULL THEN
        RAISE EXCEPTION 'Missing productId';
    END IF;
    IF p_rating IS NULL THEN
        RAISE EXCEPTION 'Missing rating';
    END IF;
    IF p_review_text IS NULL OR TRIM(p_review_text) = '' THEN
        RAISE EXCEPTION 'Missing reviewText';
    END IF;

    -- Error handling: check rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5. Provided: %', p_rating;
    END IF;

    -- Check if a review by this member for this product already exists
    IF EXISTS (
        SELECT 1 FROM review
        WHERE member_id = p_member_id AND product_id = p_product_id
    ) THEN
        RAISE EXCEPTION 'You have already reviewed this product.';
    END IF;

    INSERT INTO review (member_id, product_id, rating, review_text)
    VALUES (p_member_id, p_product_id, p_rating, p_review_text);
END;
$$;


--
-- TOC entry 249 (class 1255 OID 16968)
-- Name: delete_comment(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_comment(IN p_comment_id integer, IN p_member_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only allow the owner to delete their comment
    IF NOT EXISTS (
        SELECT 1 FROM comment WHERE id = p_comment_id AND member_id = p_member_id
    ) THEN
        RAISE EXCEPTION 'Comment does not exist or you do not have permission to delete it.';
    END IF;

    DELETE FROM comment WHERE id = p_comment_id AND member_id = p_member_id;
END;
$$;


--
-- TOC entry 244 (class 1255 OID 16960)
-- Name: delete_review(integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_review(IN p_review_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM review WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 247 (class 1255 OID 16966)
-- Name: get_comments_by_review(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_comments_by_review(p_review_id integer) RETURNS TABLE(id integer, member_id integer, review_id integer, content text, parent_id integer, created_at timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.member_id,
        c.review_id,
        c.content,
        c.parent_id,
        c.created_at,
        m.username::TEXT  -- <-- CAST TO TEXT
    FROM comment c
    JOIN member m ON c.member_id = m.id
    WHERE c.review_id = p_review_id
    ORDER BY c.created_at ASC;
END;
$$;


--
-- TOC entry 246 (class 1255 OID 16965)
-- Name: get_review_by_member_and_product(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_review_by_member_and_product(p_member_id integer, p_product_id integer) RETURNS TABLE(review_id integer, member_id integer, product_id integer, rating integer, review_text text, last_updated_date timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.review_id,
        r.member_id,
        r.product_id,
        r.rating,
        r.review_text,
        r.last_updated_date
    FROM review r
    WHERE r.member_id = p_member_id AND r.product_id = p_product_id;
END;
$$;


--
-- TOC entry 242 (class 1255 OID 16950)
-- Name: get_reviews_by_member(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews_by_member(p_member_id integer) RETURNS TABLE(id integer, member_id integer, product_id integer, rating integer, review_text text, last_updated_date timestamp without time zone, product_name text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.review_id AS id,
        r.member_id,
        r.product_id,
        r.rating,
        r.review_text,
        r.last_updated_date,
        p.name::TEXT AS product_name   -- <-- CAST TO TEXT
    FROM review r
    JOIN product p ON r.product_id = p.id
    WHERE r.member_id = p_member_id;
END;
$$;


--
-- TOC entry 245 (class 1255 OID 16962)
-- Name: get_reviews_by_product(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews_by_product(p_product_id integer) RETURNS TABLE(review_id integer, member_id integer, product_id integer, rating integer, review_text text, last_updated_date timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.review_id,
        r.member_id,
        r.product_id,
        r.rating,
        r.review_text,
        r.last_updated_date,
        m.username::TEXT
    FROM review r
    JOIN member m ON r.member_id = m.id
    WHERE r.product_id = p_product_id;
END;
$$;


--
-- TOC entry 250 (class 1255 OID 16928)
-- Name: get_sale_order_summary(character varying, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_order_summary(p_gender character varying DEFAULT NULL::character varying, p_min_total_spending numeric DEFAULT NULL::numeric, p_min_member_total_spending numeric DEFAULT NULL::numeric) RETURNS TABLE(age_group text, total_spending numeric, num_of_members bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        CASE
            WHEN m.dob IS NOT NULL AND DATE_PART('year', AGE(m.dob)) BETWEEN 18 AND 29 THEN '18-29'
            WHEN m.dob IS NOT NULL AND DATE_PART('year', AGE(m.dob)) BETWEEN 30 AND 39 THEN '30-39'
            WHEN m.dob IS NOT NULL AND DATE_PART('year', AGE(m.dob)) BETWEEN 40 AND 49 THEN '40-49'
            ELSE '50+'
        END AS age_group,
        SUM(soi.quantity * p.unit_price) AS total_spending,
        COUNT(DISTINCT m.id) AS num_of_members
    FROM member m
    JOIN sale_order so ON m.id = so.member_id
    JOIN sale_order_item soi ON so.id = soi.sale_order_id
    JOIN product p ON soi.product_id = p.id
    WHERE (p_gender IS NULL OR m.gender = p_gender)
      AND (p_min_total_spending IS NULL OR (soi.quantity * p.unit_price) >= p_min_total_spending)
      AND (
            p_min_member_total_spending IS NULL
            OR (
                SELECT SUM(soi2.quantity * p2.unit_price)
                FROM sale_order so2
                JOIN sale_order_item soi2 ON so2.id = soi2.sale_order_id
                JOIN product p2 ON soi2.product_id = p2.id
                WHERE so2.member_id = m.id
            ) >= p_min_member_total_spending
      )
    GROUP BY age_group
    ORDER BY age_group;
END;
$$;


--
-- TOC entry 243 (class 1255 OID 16959)
-- Name: update_review(integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.update_review(IN p_review_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE review
    SET rating = p_rating, review_text = p_review_text, last_updated_date = NOW()
    WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 230 (class 1259 OID 16917)
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    id integer NOT NULL,
    review_id integer,
    member_id integer,
    content text NOT NULL,
    parent_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 229 (class 1259 OID 16916)
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4965 (class 0 OID 0)
-- Dependencies: 229
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- TOC entry 217 (class 1259 OID 16790)
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    dob date NOT NULL,
    password character varying(255) NOT NULL,
    role integer NOT NULL,
    gender character(1) NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 16793)
-- Name: member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4966 (class 0 OID 0)
-- Dependencies: 218
-- Name: member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_id_seq OWNED BY public.member.id;


--
-- TOC entry 219 (class 1259 OID 16794)
-- Name: member_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_role (
    id integer NOT NULL,
    name character varying(25)
);


--
-- TOC entry 220 (class 1259 OID 16797)
-- Name: member_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4967 (class 0 OID 0)
-- Dependencies: 220
-- Name: member_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_role_id_seq OWNED BY public.member_role.id;


--
-- TOC entry 221 (class 1259 OID 16798)
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id integer NOT NULL,
    name character varying(255),
    description text,
    unit_price numeric NOT NULL,
    stock_quantity numeric DEFAULT 0 NOT NULL,
    country character varying(100),
    product_type character varying(50),
    image_url character varying(255) DEFAULT '/images/product.png'::character varying,
    manufactured_on timestamp without time zone
);


--
-- TOC entry 222 (class 1259 OID 16805)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4968 (class 0 OID 0)
-- Dependencies: 222
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 228 (class 1259 OID 16866)
-- Name: review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    rating integer NOT NULL,
    review_text text NOT NULL,
    last_updated_date timestamp without time zone DEFAULT now()
);


--
-- TOC entry 227 (class 1259 OID 16865)
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4969 (class 0 OID 0)
-- Dependencies: 227
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- TOC entry 223 (class 1259 OID 16806)
-- Name: sale_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order (
    id integer NOT NULL,
    member_id integer,
    order_datetime timestamp without time zone NOT NULL,
    status character varying(10)
);


--
-- TOC entry 224 (class 1259 OID 16809)
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4970 (class 0 OID 0)
-- Dependencies: 224
-- Name: sale_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_id_seq OWNED BY public.sale_order.id;


--
-- TOC entry 225 (class 1259 OID 16810)
-- Name: sale_order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order_item (
    id integer NOT NULL,
    sale_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 16815)
-- Name: sale_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4971 (class 0 OID 0)
-- Dependencies: 226
-- Name: sale_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_item_id_seq OWNED BY public.sale_order_item.id;


--
-- TOC entry 4791 (class 2604 OID 16920)
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- TOC entry 4782 (class 2604 OID 16816)
-- Name: member id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN id SET DEFAULT nextval('public.member_id_seq'::regclass);


--
-- TOC entry 4783 (class 2604 OID 16817)
-- Name: member_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role ALTER COLUMN id SET DEFAULT nextval('public.member_role_id_seq'::regclass);


--
-- TOC entry 4784 (class 2604 OID 16818)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 4789 (class 2604 OID 16869)
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- TOC entry 4787 (class 2604 OID 16819)
-- Name: sale_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order ALTER COLUMN id SET DEFAULT nextval('public.sale_order_id_seq'::regclass);


--
-- TOC entry 4788 (class 2604 OID 16820)
-- Name: sale_order_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item ALTER COLUMN id SET DEFAULT nextval('public.sale_order_item_id_seq'::regclass);


--
-- TOC entry 4810 (class 2606 OID 16925)
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- TOC entry 4794 (class 2606 OID 16822)
-- Name: member member_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_email_key UNIQUE (email);


--
-- TOC entry 4796 (class 2606 OID 16824)
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- TOC entry 4800 (class 2606 OID 16826)
-- Name: member_role member_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role
    ADD CONSTRAINT member_role_pkey PRIMARY KEY (id);


--
-- TOC entry 4798 (class 2606 OID 16828)
-- Name: member member_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_username_key UNIQUE (username);


--
-- TOC entry 4802 (class 2606 OID 16830)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 4808 (class 2606 OID 16873)
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- TOC entry 4806 (class 2606 OID 16832)
-- Name: sale_order_item sale_order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT sale_order_item_pkey PRIMARY KEY (id);


--
-- TOC entry 4804 (class 2606 OID 16834)
-- Name: sale_order sale_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT sale_order_pkey PRIMARY KEY (id);


--
-- TOC entry 4811 (class 2606 OID 16835)
-- Name: member fk_member_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT fk_member_role_id FOREIGN KEY (role) REFERENCES public.member_role(id);


--
-- TOC entry 4813 (class 2606 OID 16840)
-- Name: sale_order_item fk_sale_order_item_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_product FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 4814 (class 2606 OID 16845)
-- Name: sale_order_item fk_sale_order_item_sale_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_sale_order FOREIGN KEY (sale_order_id) REFERENCES public.sale_order(id);


--
-- TOC entry 4812 (class 2606 OID 16850)
-- Name: sale_order fk_sale_order_member; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT fk_sale_order_member FOREIGN KEY (member_id) REFERENCES public.member(id);


-- Completed on 2025-07-04 02:43:56

--
-- PostgreSQL database dump complete
--

