-- CreateTable
CREATE TABLE "shipping_discount" (
    "id" SERIAL NOT NULL,
    "applicable_method" VARCHAR(20) NOT NULL,
    "discount_value" DOUBLE PRECISION NOT NULL,
    "discount_type" VARCHAR(20) NOT NULL,

    CONSTRAINT "shipping_discount_pkey" PRIMARY KEY ("id")
);
