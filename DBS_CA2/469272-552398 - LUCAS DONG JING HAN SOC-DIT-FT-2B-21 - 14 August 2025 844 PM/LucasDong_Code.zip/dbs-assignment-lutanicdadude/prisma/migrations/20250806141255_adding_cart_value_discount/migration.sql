-- CreateTable
CREATE TABLE "cart_value_discount" (
    "id" SERIAL NOT NULL,
    "discount_type" VARCHAR(20) NOT NULL,
    "discount_value" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "cart_value_discount_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "cart_value_discount_discount_type_key" ON "cart_value_discount"("discount_type");
