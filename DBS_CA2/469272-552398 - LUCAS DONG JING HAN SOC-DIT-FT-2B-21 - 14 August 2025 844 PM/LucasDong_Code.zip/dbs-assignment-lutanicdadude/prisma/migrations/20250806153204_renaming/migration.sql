/*
  Warnings:

  - You are about to drop the column `discount_type` on the `cart_value_discount` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[discount_code]` on the table `cart_value_discount` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `discount_code` to the `cart_value_discount` table without a default value. This is not possible if the table is not empty.

*/
-- DropIndex
DROP INDEX "cart_value_discount_discount_type_key";

-- AlterTable
ALTER TABLE "cart_value_discount" DROP COLUMN "discount_type",
ADD COLUMN     "discount_code" VARCHAR(20) NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "cart_value_discount_discount_code_key" ON "cart_value_discount"("discount_code");
