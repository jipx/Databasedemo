const jwt = require('jsonwebtoken');

module.exports.authMiddleware = (req, res, next) => {
    // Get the Authorization header from the incoming request
    const authHeader = req.headers['authorization'];
    // console.log("authheader: " + authHeader)

    // If there is no Authorization header, deny access with 401 status
    if (!authHeader) {
        return res.status(401).json({ message: 'No token provided' });
    }

    // Authorization header should start with 'Bearer ' followed by the token
    // If the format is incorrect, deny access
    if (!authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Invalid authorization format' });
    }

    // Extract the token part from the Authorization header
    // 'Bearer tokenstring' => split by space and take second part (index 1)
    const token = authHeader.split(' ')[1];

    // If token is missing after 'Bearer ', deny access
    if (!token) {
        return res.status(401).json({ message: 'Token missing' });
    }

    try {
        // Verify the token using your secret key
        // This throws an error if the token is invalid or expired
        const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

        // Save the decoded user/member ID in the request object for later middleware or routes
        req.member_Id = decoded.memberId;

        // Call next() to continue to the next middleware or route handler
        next();
    } catch (err) {
        // If token verification fails, respond with 403 Forbidden status
        return res.status(403).json({ message: 'Invalid token' });
    }
};
