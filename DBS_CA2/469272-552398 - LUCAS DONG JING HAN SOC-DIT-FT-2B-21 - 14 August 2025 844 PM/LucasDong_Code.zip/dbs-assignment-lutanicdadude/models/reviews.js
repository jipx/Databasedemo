const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

// check whether product_id exist in table by calling stored procedure
module.exports.checking_productID = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM CheckProductID($1)`;
    const VALUES = [parseInt(data.product_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

// add review to database using stored procedure
module.exports.creating_review = (callback, data) => {
    const SQLSTATEMENT = `CALL create_review(
                            $1::INT,
                            $2::INT,
                            $3::VARCHAR(255),
                            $4::INT,
                            $5::VARCHAR(255)
                            )
                        `;
    const VALUES = [parseInt(data.member_id, 10), parseInt(data.product_id, 10), data.review, parseInt(data.rating, 10), data.product_name];
    query(SQLSTATEMENT, VALUES, callback);
}

// get all reviews using stored procedure
module.exports.getting_Reviews = (callback) => {
    const SQLSTATEMENT = `SELECT * FROM GetReviews()`; // stored procedure returns all reviews
    query(SQLSTATEMENT, callback);
}

// check review existence using stored procedure
module.exports.checking_Reviews = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM CheckReview($1)`;
    const VALUES = [parseInt(data.review_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

// update review using stored procedure
module.exports.updating_Reviews = (callback, data) => {
    const SQLSTATEMENT = `CALL update_review(
                            $1::INT,
                            $2::VARCHAR(255),
                            $3::INT
                        )`;
    const VALUES = [parseInt(data.review_id, 10), data.review_text, data.rating];
    query(SQLSTATEMENT, VALUES, callback);
}

// delete review using stored procedure
module.exports.deleting_Reviews = (callback, data) => {
    const SQLSTATEMENT = `CALL delete_review($1)`;
    const VALUES = [parseInt(data.review_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

// // get username
// module.exports.getting_Reviews_By_ProductId = (callback, data) => {
//     const SQLSTATEMENT = `SELECT * FROM GetReviews() WHERE product_id = $1`;
//     const VALUES = [parseInt(data.product_id, 10)];
//     query(SQLSTATEMENT, VALUES, callback);
// }

// get all reviews under the product_id
module.exports.getting_Reviews_By_ProductId = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM GetReviewsForProduct($1)`;
    const VALUES = [parseInt(data.product_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}