const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

module.exports.addingComment = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM add_comment($1, $2, $3, $4, $5, $6)`;
    const VALUES = [
        parseInt(data.member_id, 10),
        parseInt(data.product_id, 10),
        data.comment,
        data.comment_date || new Date(),
        data.parent_comment_id !== null ? parseInt(data.parent_comment_id, 10) : null,
        data.review_id !== null ? parseInt(data.review_id, 10) : null];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.checkingCommentId = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM check_commentId($1)`;
    const VALUES = [parseInt(data.commentId, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.deletingComment = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM delete_comment($1)`;
    const VALUES = [parseInt(data.commentId, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.gettingComments = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM GetCommentsByReview($1)`;
    const VALUES = [parseInt(data.review_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}