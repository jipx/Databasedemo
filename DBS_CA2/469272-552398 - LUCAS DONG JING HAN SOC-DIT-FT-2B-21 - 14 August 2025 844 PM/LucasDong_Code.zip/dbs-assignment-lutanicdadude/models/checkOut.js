const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

module.exports.checking_promo_code = async (promo_code) => {
  // Call the stored function check_promo_discount(promo_code)
  const result = await prisma.$queryRaw`SELECT * FROM check_promo_discount(${promo_code})`;
  return result;
};

module.exports.checking_cart_for_order = async (memberId) => {
  // Call the stored function check_cart_for_order(memberId)
  const result = await prisma.$queryRaw`SELECT * FROM check_cart_for_order(${memberId}::integer)`;
  return result;
};

module.exports.submit_check_out = async (data) => {
  const { memberId, username, email, shippingAddress, paymentMethod } = data;
  // Call the stored procedure place_orders with parameters
  const result = await prisma.$executeRaw`
    CALL place_orders(
      ${memberId}::integer, 
      ${username}, 
      ${email}, 
      ${shippingAddress}, 
      ${paymentMethod}
    )
  `;
  return result;
};
