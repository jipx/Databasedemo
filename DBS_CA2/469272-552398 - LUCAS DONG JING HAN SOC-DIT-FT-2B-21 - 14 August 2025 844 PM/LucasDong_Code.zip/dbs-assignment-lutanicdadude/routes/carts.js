const express = require('express');
const cartController = require('../controllers/ORMcartsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);
router.post("/add_cart_item", cartController.checkProduct_id, authMiddleware.authMiddleware, cartController.check_cart_table, cartController.createCartItems);
router.get("/summary", authMiddleware.authMiddleware, cartController.getCartSummary);
router.get("/", authMiddleware.authMiddleware, cartController.retrieveCartItems);
router.put("/", authMiddleware.authMiddleware, cartController.checkProduct_id, cartController.updateCartItems);
router.delete("/", authMiddleware.authMiddleware, cartController.checkProduct_id, cartController.deleteCartItems);

module.exports = router;