// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const reviewsController = require('../controllers/reviewsController');
const authMiddleware = require('../middleware/authMiddleware');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);
router.post("/add_review", authMiddleware.authMiddleware, reviewsController.check_productID, reviewsController.create_review);
router.get("/reviews_all", reviewsController.get_reviews);
router.put("/update_review", reviewsController.check_ReviewsID, reviewsController.update_review);
router.delete("/delete_review", reviewsController.check_ReviewsID, reviewsController.delete_review);
router.get("/", reviewsController.get_Reviews_By_ProductId);

module.exports = router;