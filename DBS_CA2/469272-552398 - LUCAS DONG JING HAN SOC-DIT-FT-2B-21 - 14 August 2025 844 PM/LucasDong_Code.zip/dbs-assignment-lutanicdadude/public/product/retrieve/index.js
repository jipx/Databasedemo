// you can modify the code to suit your needs
const token = localStorage.getItem("token");
const payload = JSON.parse(atob(token.split('.')[1]));
function fetchProduct(productId) {
    const token = localStorage.getItem("token");

    return fetch(`/products/${productId}`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (body) {
            if (body.error) throw new Error(body.error);
            const product = body.product;
            const tbody = document.querySelector("#product-tbody");

            const row = document.createElement("tr");
            row.classList.add("product");
            const nameCell = document.createElement("td");
            const descriptionCell = document.createElement("td");
            const unitPriceCell = document.createElement("td");
            const countryCell = document.createElement("td");
            const productTypeCell = document.createElement("td");
            const imageUrlCell = document.createElement("td");
            const manufacturedOnCell = document.createElement("td");

            nameCell.textContent = product.name
            descriptionCell.textContent = product.description;
            unitPriceCell.textContent = product.unitPrice;
            countryCell.textContent = product.country;
            productTypeCell.textContent = product.productType;
            imageUrlCell.innerHTML = `<img src="${product.imageUrl}" alt="Product Image">`;
            manufacturedOnCell.textContent = new Date(product.manufacturedOn).toLocaleString();

            const addToCartContainer = document.getElementById('addToCartContainer');
            const addToCartButton = document.createElement("button");
            addToCartButton.textContent = "Add to Cart";
            addToCartButton.addEventListener('click', function () {
                localStorage.setItem("cartProductId", product.id);
                window.location.href = `/cart/create`;
            });
            addToCartContainer.appendChild(addToCartButton);

            row.appendChild(nameCell);
            row.appendChild(descriptionCell);
            row.appendChild(unitPriceCell);
            row.appendChild(countryCell);
            row.appendChild(productTypeCell);
            row.appendChild(imageUrlCell);
            row.appendChild(manufacturedOnCell);
            tbody.appendChild(row);

        })
        .catch(function (error) {
            console.error(error);
        });
}

function fetchProductReviews(productId) {
    const token = localStorage.getItem("token");

    let url = `/reviews?productId=${productId}`;

    return fetch(url, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (body) {
            if (body.error) throw new Error(body.error);
            const reviews = body.rows;
            console.log("reviews Arr: ", reviews)

            const reviewsContainer = document.querySelector('#reviews-container');

            reviews.forEach(function (review) {
                const reviewDiv = document.createElement('div');
                reviewDiv.classList.add('review-row');
                let ratingStars = '';
                for (let i = 0; i < review.rating; i++) {
                    ratingStars += '⭐';
                }

                reviewDiv.innerHTML += `            
                    <h3>Member Username: ${review.username}</h3>
                    <p>Rating: ${ratingStars}</p>
                    <p>Review Text: ${review.reviewText}</p>
                    <p>Last Updated: ${review.lastUpdate ? new Date(review.lastUpdate).toLocaleString() : ""} </p>
                `;

                // Comment form
                const commentForm = document.createElement('div');
                commentForm.classList.add("comment-form");

                const textArea = document.createElement("textarea");
                textArea.classList.add("new-comment-text");
                textArea.placeholder = "Leave a comment about this review...";

                const submitBtn = document.createElement("button");
                submitBtn.classList.add("submit-comment-btn");
                submitBtn.textContent = "Submit Comment";
                submitBtn.dataset.reviewId = review.reviewId;

                commentForm.appendChild(textArea);
                commentForm.appendChild(document.createElement("br"));
                commentForm.appendChild(submitBtn);

                // Comment section
                const commentsSection = document.createElement("div");
                commentsSection.classList.add("comments-section");
                commentsSection.id = `comments-section-${review.reviewId}`;

                // Append all
                reviewDiv.appendChild(commentForm);
                reviewDiv.appendChild(commentsSection);
                reviewsContainer.appendChild(reviewDiv);

                // Now fetch comments AFTER it's added
                fetchCommentsForReview(review.reviewId);

                // Add event listener
                submitBtn.addEventListener('click', async () => {
                    const commentText = textArea.value.trim();
                    if (!commentText) return;

                    try {
                        const response = await fetch('/comments/add_comments', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                Authorization: 'Bearer ' + localStorage.getItem("token")
                            },
                            body: JSON.stringify({
                                product_id: review.productId,
                                member_id: payload.memberId,
                                comment: commentText,
                                parent_comment_id: null,
                                review_id: review.reviewId
                            })
                        });

                        textArea.value = "";
                        const result = await response.json();
                        showCommentStatus(result.success, result.message);

                        document.getElementById('okBtn').addEventListener('click', closeModal);
                        window.addEventListener('click', function (e) {
                            if (e.target.id === 'reviewModal') {
                                closeModal();
                            }
                        });
                    } catch (err) {
                        console.error("Error submitting comment:", err);
                        alert("Error submitting comment.");
                    }
                });


            });

        })
        .catch(function (error) {
            console.error(error);
        });
}

document.addEventListener('DOMContentLoaded', function () {

    const productId = localStorage.getItem("productId");

    fetchProduct(productId)
        .then(function () {
            return fetchProductReviews(productId);
        })
        .then(function () {
            console.log('Product, reviews, and comments loaded.');
        })
        .catch(function (error) {
            console.error(error);
        });


});

//Fetch comments from the backend
async function fetchCommentsForReview(reviewId) {
    const res = await fetch(`/comments/comments?review_id=${reviewId}`, {
        headers: {
            Authorization: 'Bearer ' + localStorage.getItem("token")
        }
    });

    const comments = await res.json();

    console.log(`Rendering ${comments.length} comments for reviewId ${reviewId}`);
    renderComments(comments, null, reviewId);
}

function normalizeId(id) {
    if (typeof id === 'object' && id !== null) {
        if (id.value !== null && id.value !== undefined) {
            return id.value;
        } else {
            return null;
        }
    }
    return id;
}

// Render comments (and replies) recursively
function renderComments(comments, parentId, reviewId) {
    const container = document.getElementById(`comments-section-${reviewId}`);
    if (!container) {
        console.log(`No container found for reviewId ${reviewId}`);
        return;
    }

    comments
        // filter comments for other comments
        .filter(comment => {
            const a = normalizeId(comment.parentCommentId);
            const b = normalizeId(parentId);

            // check if a and b is correct
            // console.log(`Comparing comment ${comment.comment_id}:`, {
            //     commentParent: comment.parentCommentId,
            //     normalizedCommentParent: a,
            //     normalizedParentId: b,
            //     isEqual: a === b,
            //     types: [typeof a, typeof b]
            // });

            return a === b;
        })


        .forEach(comment => {
            const commentDiv = document.createElement("div");
            commentDiv.classList.add("comment");
            commentDiv.style.marginLeft = parentId ? "20px" : "0";

            let commentHTML = `
                <strong class="mt-5">${comment.username}</strong><br>
                <p>${comment.comment}</p>
                <button class="reply-btn" data-id="${comment.commentId}">Reply</button>
            `;

            // Only show delete button if user is the owner
            if (comment.memberId === payload.memberId) {
                commentHTML += `
                    <button class="delete-btn" data-comment-id="${comment.commentId}">Delete</button>
                `;
            }

            commentHTML += `
                <div class="reply-form" style="display: none;">
                    <textarea placeholder="Write your reply..."></textarea><br>
                    <button class="submit-reply" data-parent="${comment.commentId}">Submit</button>
                </div>
            `;

            commentDiv.innerHTML = commentHTML;

            container.appendChild(commentDiv);

            // Toggle reply form
            commentDiv.querySelector('.reply-btn').addEventListener('click', () => {
                const form = commentDiv.querySelector('.reply-form');
                form.style.display = form.style.display === 'none' ? 'block' : 'none';
            });

            // Submit reply
            commentDiv.querySelector('.submit-reply').addEventListener('click', async () => {
                const replyText = commentDiv.querySelector('textarea').value.trim();
                if (!replyText) {
                    return
                };

                // console.log(comment)
                // console.log("comment data: ", comment.productId)
                // console.log("comment data: ", comment.reviewId)
                // console.log("comment data: ", comment.commentId)

                await fetch('/comments/add_comments', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: 'Bearer ' + localStorage.getItem("token")
                    },
                    body: JSON.stringify({
                        member_id: payload.memberId,
                        comment: replyText,
                        product_id: comment.productId,
                        review_id: comment.reviewId,
                        parent_comment_id: comment.commentId
                    })
                });

                // Refresh comments
                container.innerHTML = '';
                location.reload();
            });

            // listener for delete, only if button exists
            const deleteBtn = commentDiv.querySelector('.delete-btn');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', () => {
                    const modal = document.getElementById('deleteConfirmModal');
                    modal.style.display = 'flex'; // show modal

                    // Buttons inside modal
                    const confirmBtn = document.getElementById('confirmDeleteBtn');
                    const cancelBtn = document.getElementById('cancelDeleteBtn');

                    // remove all old event listeners (to avoid stacking)
                    confirmBtn.replaceWith(confirmBtn.cloneNode(true));
                    cancelBtn.replaceWith(cancelBtn.cloneNode(true));

                    const newConfirmBtn = document.getElementById('confirmDeleteBtn');
                    const newCancelBtn = document.getElementById('cancelDeleteBtn');

                    // Confirm delete handler
                    newConfirmBtn.addEventListener('click', async () => {
                        modal.style.display = 'none';

                        const commentId = comment.commentId;

                        try {
                            const res = await fetch(`/comments/delete_comment?commentId=${commentId}`, {
                                method: 'DELETE',
                                headers: {
                                    Authorization: 'Bearer ' + localStorage.getItem("token")
                                }
                            });

                            if (!res.ok) throw new Error('Failed to delete comment.');
                            const result = await res.json();
                            console.log(result);

                            // Refresh comments
                            container.innerHTML = '';
                            fetchCommentsForReview(reviewId);
                        } catch (error) {
                            console.error('Error deleting comment:', error);
                            alert('Error deleting comment.');
                        }
                    });

                    // Cancel delete handler
                    newCancelBtn.addEventListener('click', () => {
                        modal.style.display = 'none';
                    });
                });
            }



            // Recursively render children
            renderComments(comments, comment.commentId, reviewId);
        });
}


// MODAL
function showCommentStatus(success, message) {
    const modal = document.getElementById('commentModal');
    const modalMessage = document.getElementById('modalMessage');

    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Comment added!" : "Comment unable to be added.");

    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('commentModal');
    location.reload();
    modal.style.display = 'none';
}