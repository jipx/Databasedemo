const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const commentsController = require('../models/comments');

module.exports.get_comments = (req, res, next) => {
    const data = {
        review_id: req.query.review_id
    }

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting comments:", error);
            return res.status(500).json("Error in getting comments: " + error);
        } else {
            // console.log(results);
            return res.status(200).json(results.rows);
        }
    }
    commentsController.gettingComments(callback, data);
}

module.exports.create_comment = (req, res, next) => {
    if (!req.body.comment) {
        return res.status(400).json({ success: false, message: "Please write a comment" });
    }

    const data = {
        member_id: req.body.member_id,
        product_id: req.body.product_id,
        comment: req.body.comment,
        parent_comment_id: req.body.parent_comment_id,
        review_id: req.body.review_id
    }
    console.log(data)

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting comments:", error);
            return res.status(500).send({ success: false, message: "Comment added unsuccessfully" });
        } else {
            // console.log(results);
            return res.status(200).send({ success: true, message: "Comment added successfully" });
        }
    }

    commentsController.addingComment(callback, data);
}

module.exports.checkCommentId = (req, res, next) => {
    const data = {
        commentId: req.query.commentId
    }
    console.log(data)

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting comments:", error);
            return res.status(500).send({ success: false, message: "Comment deleted unsuccessfully" });
        } else {
            // console.log(results);
            req.commentId = req.query.commentId;
            next();
        }
    }

    commentsController.checkingCommentId(callback, data);
}

module.exports.delete_comment = (req, res, next) => {
    const data = {
        commentId: req.commentId
    }
    console.log(data)

    const callback = (error, results) => {
        console.log(results)
        if (!results.rows[0].deleteComment) {
            console.log("Error in getting comments:", error);
            return res.status(500).send({ success: false, message: "Comment deleted unsuccessfully" });
        } else {
            // console.log(results);
            return res.status(200).send({ success: true, message: "Comment deleted successfully" });
        }
    }

    commentsController.deletingComment(callback, data);
}