# DBS
## 👤 Student Info
- **Name:** Lois Poh  
- **Student ID:** P2429478  
- **Class:** DIT/FT/2B/21  
- **GitHub Repo:** [dbs-assignment-crypt-soil](https://github.com/soc-DBS/dbs-assignment-crypt-soil)

---

## Setup

1. Clone this repository

2. Create a .env file with the following content

    ```
    DB_USER=
    DB_PASSWORD=
    DB_HOST=
    DB_DATABASE=
    DB_CONNECTION_LIMIT=1
    PORT=3000
    ```

3. Update the .env content with your own database credentials.

4. Install dependencies by running `npm install`

5. Start the app by running `npm start`. Alternatively to use hot reload, start the app by running `npm run dev`.

6. You should see `App listening on port 3000`

8. (Optional) install the plugins recommended in `.vscode/extensions.json`

## Instructions

Open the page, `http://localhost:3000`, replace the port number accordingly if you app is not listening to port 3000

---

## 📁 Final Project Folder Structure
.
├── .eslintrc.js
├── .gitignore
├── README.md
├── app.js
├── database.js
├── errors.js
├── functions_&_stored_procedures_final.sql
├── package-lock.json
├── package.json
├── server.js
├── controllers
│   ├── cartsController.js
│   ├── commentsController.js
│   ├── membersController.js
│   ├── productsController.js
│   ├── reviewsController.js
│   └── saleOrdersController.js
├── middleware
│   └── jwtMiddleware.js
├── models
│   ├── carts.js
│   ├── comments.js
│   ├── members.js
│   ├── products.js
│   ├── reviews.js
│   └── saleOrders.js
├── public
│   ├── admin
│   │   ├── authAdmin.js
│   │   ├── dashboard
│   │   │   ├── index.html
│   │   │   └── salesOrderSummary
│   │   │       ├── index.html
│   │   │       └── index.js
│   │   ├── headerAdmin.js
│   │   ├── home.html
│   │   ├── index.html
│   │   └── manufacturer
│   │       └── index.html
│   ├── auth.js
│   ├── cart
│   │   ├── create
│   │   │   ├── index.css
│   │   │   ├── index.html
│   │   │   └── index.js
│   │   └── retrieve
│   │       └── all
│   │           ├── index.css
│   │           ├── index.html
│   │           └── index.js
│   ├── checkout
│   │   └── index.html
│   ├── header.js
│   ├── home.html
│   ├── images
│   │   └── product.png
│   ├── index.css
│   ├── index.html
│   ├── login.html
│   ├── main.css
│   ├── product
│   │   ├── index.html
│   │   └── retrieve
│   │       ├── all
│   │       │   ├── index.css
│   │       │   ├── index.html
│   │       │   └── index.js
│   │       └── index
│   │           ├── index.css
│   │           ├── index.html
│   │           └── index.js
│   └── review
│       ├── create
│       │   ├── index.css
│       │   ├── index.html
│       │   └── index.js
│       ├── delete
│       │   ├── index.css
│       │   ├── index.html
│       │   └── index.js
│       ├── index.html
│       ├── retrieve
│       │   ├── all
│       │   │   ├── index.css
│       │   │   ├── index.html
│       │   │   └── index.js
│       │   └── index
│       │       ├── index.css
│       │       ├── index.html
│       │       └── index.js
│       └── update
│           ├── index.css
│           ├── index.html
│           └── index.js
└── routes
    ├── auth.js
    ├── carts.js
    ├── comments.js
    ├── dashboard.js
    ├── members.js
    ├── products.js
    ├── reviews.js
    └── saleOrders.js


## 🧩 Backend Structure

### Controllers
- `controllers/commentsController.js`: Handles add/delete/fetch comment operations
- `controllers/reviewsController.js`: Handles review CRUD operations

### Models
- `models/reviews.js`: Calls PostgreSQL stored procedures for review features
- `models/comments.js`: Calls PostgreSQL functions for comment features

### Routes
- `routes/reviews.js`: Review-related endpoints
- `routes/comments.js`: Comment-related endpoints

---

## 🌐 Frontend Features

### Review
- `review/create/index.js`: Submit new reviews
- `review/retrieve/all/index.js`: View all user reviews
- `review/update/index.js`: Update existing reviews
- `review/delete/index.js`: Delete a review

### Product + Comments
- `product/retrieve/index.js`:  
  - Fetch reviews for a product  
  - Display and submit nested comments

---


## 🗄 Database Structure

### Tables Created

```sql
CREATE TABLE review (
    review_id SERIAL PRIMARY KEY,
    member_id INT NOT NULL REFERENCES member(id),
    product_id INT NOT NULL REFERENCES product(id),
    rating INT CHECK(rating BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NULL
);

CREATE TABLE comment (
    comment_id SERIAL PRIMARY KEY,
    review_id INT NOT NULL REFERENCES review(review_id) ON DELETE CASCADE,
    member_id INT NOT NULL REFERENCES member(id),
    comment_text TEXT,
    parent_comment_id INT REFERENCES comment(comment_id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);