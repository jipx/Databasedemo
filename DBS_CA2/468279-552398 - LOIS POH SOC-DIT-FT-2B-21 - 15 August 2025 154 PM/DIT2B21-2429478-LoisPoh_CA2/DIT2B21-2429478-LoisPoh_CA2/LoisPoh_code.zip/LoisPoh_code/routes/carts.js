const express = require('express');
const cartsController = require('../controllers/cartsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);
router.post('/create', cartsController.createCartItems);
router.put('/', cartsController.updateCartItems);
router.delete('/', cartsController.deleteCartItems);
router.get('/', cartsController.retrieveCartItems);
router.get('/summary', cartsController.getCartSummary);
router.get('/checkout', cartsController.getCheckout);
router.post('/placeOrder', cartsController.placeOrder);
router.get('/orderStatus', cartsController.orderStatus);

module.exports = router;