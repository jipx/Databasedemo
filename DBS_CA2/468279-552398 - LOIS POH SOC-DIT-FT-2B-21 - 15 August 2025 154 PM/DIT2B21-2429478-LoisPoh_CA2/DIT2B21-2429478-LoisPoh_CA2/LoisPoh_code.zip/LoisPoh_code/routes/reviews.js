// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const reviewsController = require('../controllers/reviewsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);

// Create
router.post('/create', reviewsController.createReview);

// Retrieve All
router.get('/retrieve/all', reviewsController.getAllReviews);

// Update
router.put('/:review_id', reviewsController.updateReview);

// Delete
router.delete('/:review_id', reviewsController.deleteReview);

//Get reviews by product id
router.get('/product/:product_id', reviewsController.getByProduct);

module.exports = router;