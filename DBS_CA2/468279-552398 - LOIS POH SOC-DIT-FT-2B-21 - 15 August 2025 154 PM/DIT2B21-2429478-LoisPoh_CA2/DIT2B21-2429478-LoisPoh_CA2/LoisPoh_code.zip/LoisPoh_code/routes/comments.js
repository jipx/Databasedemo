// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const commentsController = require('../controllers/commentsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);

// Get all comments for a specific review
router.get('/review/:id', commentsController.getCommentsByReview);

// Add a new comment
router.post('/', commentsController.createComment);

// Delete a comment (only by owner)
router.delete('/:commentId', commentsController.removeComment);

module.exports = router;