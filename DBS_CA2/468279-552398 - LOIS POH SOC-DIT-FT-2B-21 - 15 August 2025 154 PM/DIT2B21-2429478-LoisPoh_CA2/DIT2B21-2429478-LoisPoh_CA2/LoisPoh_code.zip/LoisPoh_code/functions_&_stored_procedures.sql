--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

-- Started on 2025-07-04 15:53:12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 245 (class 1255 OID 25219)
-- Name: add_comment(integer, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_comment(p_review_id integer, p_member_id integer, p_comment_text text, p_parent_comment_id integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    review_author INT;
BEGIN
    SELECT member_id INTO review_author FROM review WHERE review_id = p_review_id;

    IF review_author IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
	ELSEIF
	p_parent_comment_id IS NULL AND review_author = p_member_id THEN
        RAISE EXCEPTION 'You cannot comment on your own review.';
    ELSE
        INSERT INTO comment (review_id, member_id, comment_text, parent_comment_id)
        VALUES (p_review_id, p_member_id, p_comment_text, p_parent_comment_id);
    END IF;
END;
$$;


--
-- TOC entry 246 (class 1255 OID 25369)
-- Name: create_comment(integer, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_comment(p_review_id integer, p_member_id integer, p_comment_text text, p_parent_comment_id integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    review_author INT;
BEGIN
    SELECT member_id INTO review_author FROM review WHERE review_id = p_review_id;

    IF review_author IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
	ELSEIF
	p_parent_comment_id IS NULL AND review_author = p_member_id THEN
        RAISE EXCEPTION 'You cannot comment on your own review.';
    ELSE
        INSERT INTO comment (review_id, member_id, comment_text, parent_comment_id)
        VALUES (p_review_id, p_member_id, p_comment_text, p_parent_comment_id);
    END IF;
END;
$$;


--
-- TOC entry 242 (class 1255 OID 25161)
-- Name: create_review(integer, integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_review(IN p_member_id integer, IN p_product_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Enforce: must have ordered this product in a COMPLETED order
    IF NOT EXISTS (
        SELECT 1
        FROM sale_order o
        JOIN sale_order_item oi ON o.id = oi.sale_order_id
        WHERE o.member_id = p_member_id
          AND o.status = 'COMPLETED'
          AND oi.product_id = p_product_id
    ) THEN
        RAISE EXCEPTION 'You can only review products you have ordered and completed.';
    END IF;

    -- If check passes, insert the review
    INSERT INTO review(member_id, product_id, rating, review_text)
    VALUES (p_member_id, p_product_id, p_rating, p_review_text);
END;
$$;


--
-- TOC entry 244 (class 1255 OID 25220)
-- Name: delete_comment(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_comment(p_comment_id integer, p_member_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    SELECT member_id INTO owner_id FROM comment WHERE comment_id = p_comment_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Comment does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only delete your own comment.';
    ELSE
        DELETE FROM comment WHERE comment_id = p_comment_id;
    END IF;
END;
$$;


--
-- TOC entry 229 (class 1255 OID 25163)
-- Name: delete_review(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_review(IN p_review_id integer, IN p_member_id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    -- Check if review exists and get owner
    SELECT member_id INTO owner_id FROM review WHERE review_id = p_review_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only delete your own review.';
    ELSE
        DELETE FROM review WHERE review_id = p_review_id;
    END IF;
END;
$$;


--
-- TOC entry 248 (class 1255 OID 25372)
-- Name: get_comments(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_comments(in_review_id integer) RETURNS TABLE("commentId" integer, "reviewId" integer, "memberId" integer, "commentText" text, "parentCommentId" integer, "createdAt" timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        c.comment_id AS "commentId",
        c.review_id AS "reviewId",
        c.member_id AS "memberId",
        c.comment_text AS "commentText",
        c.parent_comment_id AS "parentCommentId",
        c.created_at AS "createdAt",
        m.username::text AS "username"
    FROM comment c
    JOIN member m ON c.member_id = m.id
    WHERE c.review_id = in_review_id
    ORDER BY c.created_at ASC;
END;
$$;


--
-- TOC entry 247 (class 1255 OID 25348)
-- Name: get_comments_by_review(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_comments_by_review(in_review_id integer) RETURNS TABLE("commentId" integer, "reviewId" integer, "memberId" integer, "commentText" text, "parentCommentId" integer, "createdAt" timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        c.comment_id AS "commentId",
        c.review_id AS "reviewId",
        c.member_id AS "memberId",
        c.comment_text AS "commentText",
        c.parent_comment_id AS "parentCommentId",
        c.created_at AS "createdAt",
        m.username::text AS "username"
    FROM comment c
    JOIN member m ON c.member_id = m.id
    WHERE c.review_id = in_review_id
    ORDER BY c.created_at ASC;
END;
$$;


--
-- TOC entry 249 (class 1255 OID 25387)
-- Name: get_reviews(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews(p_member_id integer) RETURNS TABLE(review_id integer, product_id integer, product_name character varying, rating integer, review_text text, created_at timestamp without time zone, updated_at timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        r.review_id,
        r.product_id,
        p.name AS product_name,
        r.rating,
        r.review_text,
        r.created_at,
        r.updated_at
    FROM review r
    JOIN product p ON r.product_id = p.id
    WHERE r.member_id = p_member_id;
END;
$$;


--
-- TOC entry 241 (class 1255 OID 25171)
-- Name: get_reviews_for_product(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews_for_product(p_product_id integer) RETURNS TABLE(review_id integer, username character varying, rating integer, review_text text, updated_at timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        r.review_id,
        m.username,
        r.rating,
        r.review_text,
        r.updated_at
    FROM review r
    JOIN member m ON r.member_id = m.id
    WHERE r.product_id = p_product_id
    ORDER BY r.updated_at DESC;
END;
$$;


--
-- TOC entry 250 (class 1255 OID 25388)
-- Name: get_sale_order_summary(text, text, character); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_order_summary(product_type_filter text DEFAULT NULL::text, sort_option text DEFAULT 'product_id'::text, gender_filter character DEFAULT NULL::bpchar) RETURNS TABLE(product_id integer, product_name character varying, product_type character varying, total_quantity_sold numeric, total_sales numeric, unit_price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Case 1: No gender filter applied
    IF gender_filter IS NULL THEN 
        RETURN QUERY
        SELECT 
            p.id AS product_id,
            p.name AS product_name, 
            p.product_type, 
            SUM(soi.quantity) AS total_quantity_sold, 
            SUM(soi.quantity * p.unit_price) AS total_sales,
            p.unit_price 
        FROM 
            sale_order_item soi
        JOIN 
            sale_order so ON soi.sale_order_id = so.id
        JOIN 
            product p ON soi.product_id = p.id
        WHERE 
            product_type_filter IS NULL OR p.product_type = product_type_filter
        GROUP BY 
            p.id, p.name, p.product_type, p.unit_price
        ORDER BY
            -- Only one of these will evaluate to non-null and influence the sort
            CASE WHEN sort_option = 'top_selling' THEN SUM(soi.quantity) END DESC, -- high quantity first
            CASE WHEN sort_option = 'most_expensive' THEN p.unit_price END DESC, -- high price first
            CASE WHEN sort_option = 'least_expensive' THEN p.unit_price END ASC, -- low price first
            CASE WHEN sort_option = 'category' THEN p.product_type END ASC, -- alphabetical
            p.id; -- fallback: sort by ID
    ELSE
        -- Case 2: Gender filter is applied
        RETURN QUERY
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            p.product_type,
            SUM(soi.quantity) AS total_quantity_sold,
            SUM(soi.quantity * p.unit_price) AS total_sales,
            p.unit_price
        FROM 
            sale_order_item soi
        JOIN 
            sale_order so ON soi.sale_order_id = so.id
        JOIN 
            product p ON soi.product_id = p.id
        JOIN 
            member m ON so.member_id = m.id
        WHERE 
            (product_type_filter IS NULL OR p.product_type = product_type_filter)
            AND m.gender = gender_filter
        GROUP BY 
            p.id, p.name, p.product_type, p.unit_price
        ORDER BY
            CASE WHEN sort_option = 'top_selling' THEN SUM(soi.quantity) END DESC,
            CASE WHEN sort_option = 'most_expensive' THEN p.unit_price END DESC,
            CASE WHEN sort_option = 'least_expensive' THEN p.unit_price END ASC,
            CASE WHEN sort_option = 'category' THEN p.product_type END ASC,
            p.id;
    END IF;
END;
$$;


--
-- TOC entry 243 (class 1255 OID 25162)
-- Name: update_review(integer, integer, integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.update_review(IN p_review_id integer, IN p_member_id integer, IN p_product_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    -- Check if review exists and get owner
    SELECT member_id INTO owner_id FROM review WHERE review_id = p_review_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only update your own review.';
    ELSE
        UPDATE review
        SET rating = p_rating,
            review_text = p_review_text,
            updated_at = CURRENT_TIMESTAMP
        WHERE review_id = p_review_id;
    END IF;
END;
$$;


--
-- TOC entry 228 (class 1259 OID 25246)
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    comment_id integer NOT NULL,
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    comment_text text,
    parent_comment_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 227 (class 1259 OID 25245)
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4963 (class 0 OID 0)
-- Dependencies: 227
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comment_comment_id_seq OWNED BY public.comment.comment_id;


--
-- TOC entry 215 (class 1259 OID 24975)
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    dob date NOT NULL,
    password character varying(255) NOT NULL,
    role integer NOT NULL,
    gender character(1) NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 24978)
-- Name: member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4964 (class 0 OID 0)
-- Dependencies: 216
-- Name: member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_id_seq OWNED BY public.member.id;


--
-- TOC entry 217 (class 1259 OID 24979)
-- Name: member_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_role (
    id integer NOT NULL,
    name character varying(25)
);


--
-- TOC entry 218 (class 1259 OID 24982)
-- Name: member_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4965 (class 0 OID 0)
-- Dependencies: 218
-- Name: member_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_role_id_seq OWNED BY public.member_role.id;


--
-- TOC entry 219 (class 1259 OID 24983)
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id integer NOT NULL,
    name character varying(255),
    description text,
    unit_price numeric NOT NULL,
    stock_quantity numeric DEFAULT 0 NOT NULL,
    country character varying(100),
    product_type character varying(50),
    image_url character varying(255) DEFAULT '/images/product.png'::character varying,
    manufactured_on timestamp without time zone
);


--
-- TOC entry 220 (class 1259 OID 24990)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4966 (class 0 OID 0)
-- Dependencies: 220
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 226 (class 1259 OID 25225)
-- Name: review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    rating integer,
    review_text text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    CONSTRAINT review_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 225 (class 1259 OID 25224)
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4967 (class 0 OID 0)
-- Dependencies: 225
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- TOC entry 221 (class 1259 OID 24991)
-- Name: sale_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order (
    id integer NOT NULL,
    member_id integer,
    order_datetime timestamp without time zone NOT NULL,
    status character varying(10)
);


--
-- TOC entry 222 (class 1259 OID 24994)
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4968 (class 0 OID 0)
-- Dependencies: 222
-- Name: sale_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_id_seq OWNED BY public.sale_order.id;


--
-- TOC entry 223 (class 1259 OID 24995)
-- Name: sale_order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order_item (
    id integer NOT NULL,
    sale_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 25000)
-- Name: sale_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4969 (class 0 OID 0)
-- Dependencies: 224
-- Name: sale_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_item_id_seq OWNED BY public.sale_order_item.id;


--
-- TOC entry 4785 (class 2604 OID 25249)
-- Name: comment comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment ALTER COLUMN comment_id SET DEFAULT nextval('public.comment_comment_id_seq'::regclass);


--
-- TOC entry 4776 (class 2604 OID 25001)
-- Name: member id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN id SET DEFAULT nextval('public.member_id_seq'::regclass);


--
-- TOC entry 4777 (class 2604 OID 25002)
-- Name: member_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role ALTER COLUMN id SET DEFAULT nextval('public.member_role_id_seq'::regclass);


--
-- TOC entry 4778 (class 2604 OID 25003)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 4783 (class 2604 OID 25228)
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- TOC entry 4781 (class 2604 OID 25004)
-- Name: sale_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order ALTER COLUMN id SET DEFAULT nextval('public.sale_order_id_seq'::regclass);


--
-- TOC entry 4782 (class 2604 OID 25005)
-- Name: sale_order_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item ALTER COLUMN id SET DEFAULT nextval('public.sale_order_item_id_seq'::regclass);


--
-- TOC entry 4805 (class 2606 OID 25254)
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (comment_id);


--
-- TOC entry 4789 (class 2606 OID 25007)
-- Name: member member_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_email_key UNIQUE (email);


--
-- TOC entry 4791 (class 2606 OID 25009)
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- TOC entry 4795 (class 2606 OID 25011)
-- Name: member_role member_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role
    ADD CONSTRAINT member_role_pkey PRIMARY KEY (id);


--
-- TOC entry 4793 (class 2606 OID 25013)
-- Name: member member_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_username_key UNIQUE (username);


--
-- TOC entry 4797 (class 2606 OID 25015)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 4803 (class 2606 OID 25234)
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- TOC entry 4801 (class 2606 OID 25017)
-- Name: sale_order_item sale_order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT sale_order_item_pkey PRIMARY KEY (id);


--
-- TOC entry 4799 (class 2606 OID 25019)
-- Name: sale_order sale_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT sale_order_pkey PRIMARY KEY (id);


--
-- TOC entry 4812 (class 2606 OID 25260)
-- Name: comment comment_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4813 (class 2606 OID 25265)
-- Name: comment comment_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.comment(comment_id) ON DELETE CASCADE;


--
-- TOC entry 4814 (class 2606 OID 25255)
-- Name: comment comment_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.review(review_id) ON DELETE CASCADE;


--
-- TOC entry 4806 (class 2606 OID 25020)
-- Name: member fk_member_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT fk_member_role_id FOREIGN KEY (role) REFERENCES public.member_role(id);


--
-- TOC entry 4808 (class 2606 OID 25025)
-- Name: sale_order_item fk_sale_order_item_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_product FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 4809 (class 2606 OID 25030)
-- Name: sale_order_item fk_sale_order_item_sale_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_sale_order FOREIGN KEY (sale_order_id) REFERENCES public.sale_order(id);


--
-- TOC entry 4807 (class 2606 OID 25035)
-- Name: sale_order fk_sale_order_member; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT fk_sale_order_member FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4810 (class 2606 OID 25235)
-- Name: review review_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4811 (class 2606 OID 25240)
-- Name: review review_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


-- Completed on 2025-07-04 15:53:12

--
-- PostgreSQL database dump complete
--

