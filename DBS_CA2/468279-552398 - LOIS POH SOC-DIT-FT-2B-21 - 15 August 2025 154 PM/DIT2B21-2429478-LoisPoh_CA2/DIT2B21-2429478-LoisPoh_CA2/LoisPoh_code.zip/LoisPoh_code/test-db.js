const { Client } = require('pg');

async function test() {
  const client = new Client({
    user: 'postgres',
    host: '127.0.0.1',
    database: 'prisma_shadow',
    password: 'loisishungry17',
    port: 5432,
  });

  try {
    await client.connect();
    console.log('Connected to prisma_shadow database!');
  } catch (err) {
    console.error('Connection error:', err);
  } finally {
    await client.end();
  }
}

test();
