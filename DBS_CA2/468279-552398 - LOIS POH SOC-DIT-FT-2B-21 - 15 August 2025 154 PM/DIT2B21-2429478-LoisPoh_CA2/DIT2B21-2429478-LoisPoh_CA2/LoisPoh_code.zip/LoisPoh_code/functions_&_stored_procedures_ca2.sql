--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

-- Started on 2025-08-15 11:35:46

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 16552)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 249 (class 1255 OID 17033)
-- Name: add_comment(integer, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_comment(p_review_id integer, p_member_id integer, p_comment_text text, p_parent_comment_id integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    review_author INT;
BEGIN
    SELECT member_id INTO review_author FROM review WHERE review_id = p_review_id;

    IF review_author IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
	ELSEIF
	p_parent_comment_id IS NULL AND review_author = p_member_id THEN
        RAISE EXCEPTION 'You cannot comment on your own review.';
    ELSE
        INSERT INTO comment (review_id, member_id, comment_text, parent_comment_id)
        VALUES (p_review_id, p_member_id, p_comment_text, p_parent_comment_id);
    END IF;
END;
$$;


--
-- TOC entry 250 (class 1255 OID 17034)
-- Name: create_comment(integer, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_comment(p_review_id integer, p_member_id integer, p_comment_text text, p_parent_comment_id integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    review_author INT;
BEGIN
    SELECT member_id INTO review_author FROM review WHERE review_id = p_review_id;

    IF review_author IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
	ELSEIF
	p_parent_comment_id IS NULL AND review_author = p_member_id THEN
        RAISE EXCEPTION 'You cannot comment on your own review.';
    ELSE
        INSERT INTO comment (review_id, member_id, comment_text, parent_comment_id)
        VALUES (p_review_id, p_member_id, p_comment_text, p_parent_comment_id);
    END IF;
END;
$$;


--
-- TOC entry 251 (class 1255 OID 17035)
-- Name: create_review(integer, integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_review(IN p_member_id integer, IN p_product_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Enforce: must have ordered this product in a COMPLETED order
    IF NOT EXISTS (
        SELECT 1
        FROM sale_order o
        JOIN sale_order_item oi ON o.id = oi.sale_order_id
        WHERE o.member_id = p_member_id
          AND o.status = 'COMPLETED'
          AND oi.product_id = p_product_id
    ) THEN
        RAISE EXCEPTION 'You can only review products you have ordered and completed.';
    END IF;

    -- If check passes, insert the review
    INSERT INTO review(member_id, product_id, rating, review_text)
    VALUES (p_member_id, p_product_id, p_rating, p_review_text);
END;
$$;


--
-- TOC entry 252 (class 1255 OID 17036)
-- Name: delete_comment(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_comment(p_comment_id integer, p_member_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    SELECT member_id INTO owner_id FROM comment WHERE comment_id = p_comment_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Comment does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only delete your own comment.';
    ELSE
        DELETE FROM comment WHERE comment_id = p_comment_id;
    END IF;
END;
$$;


--
-- TOC entry 253 (class 1255 OID 17037)
-- Name: delete_review(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_review(IN p_review_id integer, IN p_member_id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    -- Check if review exists and get owner
    SELECT member_id INTO owner_id FROM review WHERE review_id = p_review_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only delete your own review.';
    ELSE
        DELETE FROM review WHERE review_id = p_review_id;
    END IF;
END;
$$;


--
-- TOC entry 254 (class 1255 OID 17038)
-- Name: get_comments(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_comments(in_review_id integer) RETURNS TABLE("commentId" integer, "reviewId" integer, "memberId" integer, "commentText" text, "parentCommentId" integer, "createdAt" timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        c.comment_id AS "commentId",
        c.review_id AS "reviewId",
        c.member_id AS "memberId",
        c.comment_text AS "commentText",
        c.parent_comment_id AS "parentCommentId",
        c.created_at AS "createdAt",
        m.username::text AS "username"
    FROM comment c
    JOIN member m ON c.member_id = m.id
    WHERE c.review_id = in_review_id
    ORDER BY c.created_at ASC;
END;
$$;


--
-- TOC entry 255 (class 1255 OID 17039)
-- Name: get_comments_by_review(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_comments_by_review(in_review_id integer) RETURNS TABLE("commentId" integer, "reviewId" integer, "memberId" integer, "commentText" text, "parentCommentId" integer, "createdAt" timestamp without time zone, username text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        c.comment_id AS "commentId",
        c.review_id AS "reviewId",
        c.member_id AS "memberId",
        c.comment_text AS "commentText",
        c.parent_comment_id AS "parentCommentId",
        c.created_at AS "createdAt",
        m.username::text AS "username"
    FROM comment c
    JOIN member m ON c.member_id = m.id
    WHERE c.review_id = in_review_id
    ORDER BY c.created_at ASC;
END;
$$;


--
-- TOC entry 236 (class 1255 OID 17040)
-- Name: get_reviews(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews(p_member_id integer) RETURNS TABLE(review_id integer, product_id integer, product_name character varying, rating integer, review_text text, created_at timestamp without time zone, updated_at timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        r.review_id,
        r.product_id,
        p.name AS product_name,
        r.rating,
        r.review_text,
        r.created_at,
        r.updated_at
    FROM review r
    JOIN product p ON r.product_id = p.id
    WHERE r.member_id = p_member_id;
END;
$$;


--
-- TOC entry 237 (class 1255 OID 17041)
-- Name: get_reviews_for_product(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_reviews_for_product(p_product_id integer) RETURNS TABLE(review_id integer, username character varying, rating integer, review_text text, updated_at timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        r.review_id,
        m.username,
        r.rating,
        r.review_text,
        r.updated_at
    FROM review r
    JOIN member m ON r.member_id = m.id
    WHERE r.product_id = p_product_id
    ORDER BY r.updated_at DESC;
END;
$$;


--
-- TOC entry 256 (class 1255 OID 17042)
-- Name: get_sale_order_summary(text, text, character); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_order_summary(product_type_filter text DEFAULT NULL::text, sort_option text DEFAULT 'product_id'::text, gender_filter character DEFAULT NULL::bpchar) RETURNS TABLE(product_id integer, product_name character varying, product_type character varying, total_quantity_sold numeric, total_sales numeric, unit_price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Case 1: No gender filter applied
    IF gender_filter IS NULL THEN 
        RETURN QUERY
        SELECT 
            p.id AS product_id,
            p.name AS product_name, 
            p.product_type, 
            SUM(soi.quantity) AS total_quantity_sold, 
            SUM(soi.quantity * p.unit_price) AS total_sales,
            p.unit_price 
        FROM 
            sale_order_item soi
        JOIN 
            sale_order so ON soi.sale_order_id = so.id
        JOIN 
            product p ON soi.product_id = p.id
        WHERE 
            product_type_filter IS NULL OR p.product_type = product_type_filter
        GROUP BY 
            p.id, p.name, p.product_type, p.unit_price
        ORDER BY
            -- Only one of these will evaluate to non-null and influence the sort
            CASE WHEN sort_option = 'top_selling' THEN SUM(soi.quantity) END DESC, -- high quantity first
            CASE WHEN sort_option = 'most_expensive' THEN p.unit_price END DESC, -- high price first
            CASE WHEN sort_option = 'least_expensive' THEN p.unit_price END ASC, -- low price first
            CASE WHEN sort_option = 'category' THEN p.product_type END ASC, -- alphabetical
            p.id; -- fallback: sort by ID
    ELSE
        -- Case 2: Gender filter is applied
        RETURN QUERY
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            p.product_type,
            SUM(soi.quantity) AS total_quantity_sold,
            SUM(soi.quantity * p.unit_price) AS total_sales,
            p.unit_price
        FROM 
            sale_order_item soi
        JOIN 
            sale_order so ON soi.sale_order_id = so.id
        JOIN 
            product p ON soi.product_id = p.id
        JOIN 
            member m ON so.member_id = m.id
        WHERE 
            (product_type_filter IS NULL OR p.product_type = product_type_filter)
            AND m.gender = gender_filter
        GROUP BY 
            p.id, p.name, p.product_type, p.unit_price
        ORDER BY
            CASE WHEN sort_option = 'top_selling' THEN SUM(soi.quantity) END DESC,
            CASE WHEN sort_option = 'most_expensive' THEN p.unit_price END DESC,
            CASE WHEN sort_option = 'least_expensive' THEN p.unit_price END ASC,
            CASE WHEN sort_option = 'category' THEN p.product_type END ASC,
            p.id;
    END IF;
END;
$$;


--
-- TOC entry 258 (class 1255 OID 25560)
-- Name: place_orders(integer, boolean); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.place_orders(IN p_member_id integer, IN p_preview boolean DEFAULT false)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_order_id INT;
    v_cart_item RECORD;
    v_subtotal NUMERIC(12,2);
    v_discount NUMERIC(12,2);
    v_line_total NUMERIC(12,2);
    v_grand_total NUMERIC(12,2) := 0;
    v_preview_data JSONB := '[]'::jsonb;
    v_result JSONB;
BEGIN
    -- If NOT preview, create the order
    IF NOT p_preview THEN
        INSERT INTO sale_order (member_id, order_datetime, status)
        VALUES (p_member_id, NOW(), 'PACKING')
        RETURNING id INTO v_order_id;
    END IF;

    FOR v_cart_item IN
        SELECT ci.id AS cart_item_id, ci.product_id, ci.quantity,
               p.name AS product_name, p.unit_price, p.stock_quantity,
               d.discount_type, d.value, d.min_quantity
        FROM cart_item ci
        JOIN cart c ON ci.cart_id = c.id
        JOIN product p ON ci.product_id = p.id
        LEFT JOIN product_discount d
            ON d.product_id = p.id
           AND d.is_active = TRUE
           AND NOW() BETWEEN d.start_date AND COALESCE(d.end_date, '2999-12-31')
           AND (d.min_quantity IS NULL OR ci.quantity >= d.min_quantity)
        WHERE c.member_id = p_member_id
    LOOP
        v_subtotal := v_cart_item.unit_price * v_cart_item.quantity;
        v_discount := 0;

        IF v_cart_item.discount_type IS NOT NULL THEN
            IF v_cart_item.discount_type = 'percentage' THEN
                v_discount := v_subtotal * (v_cart_item.value / 100);
            ELSIF v_cart_item.discount_type = 'fixed' THEN
                v_discount := v_cart_item.value;
            END IF;
        END IF;

        v_line_total := v_subtotal - v_discount;

        v_preview_data := v_preview_data || jsonb_build_object(
            'productName', v_cart_item.product_name,
            'quantity', v_cart_item.quantity,
            'unitPrice', v_cart_item.unit_price,
            'discount', v_discount,
            'lineTotal', v_line_total
        );

        IF v_cart_item.stock_quantity >= v_cart_item.quantity THEN
            v_grand_total := v_grand_total + v_line_total;

            IF NOT p_preview THEN
                UPDATE product
                SET stock_quantity = stock_quantity - v_cart_item.quantity
                WHERE id = v_cart_item.product_id;

                INSERT INTO sale_order_item (sale_order_id, product_id, quantity)
                VALUES (v_order_id, v_cart_item.product_id, v_cart_item.quantity);

                DELETE FROM cart_item WHERE id = v_cart_item.cart_item_id;
            END IF;
        END IF;
    END LOOP;

    -- Build final JSON result
    v_result := jsonb_build_object(
        'items', v_preview_data,
        'subtotal', (
            SELECT SUM((value->>'unitPrice')::numeric * (value->>'quantity')::int)
            FROM jsonb_array_elements(v_preview_data) AS value
        ),
        'totalDiscount', (
            SELECT SUM((value->>'discount')::numeric)
            FROM jsonb_array_elements(v_preview_data) AS value
        ),
        'grandTotal', v_grand_total
    );

    -- Just output it to logs for debugging (optional)
    RAISE NOTICE 'Order result: %', v_result;
END;
$$;


--
-- TOC entry 257 (class 1255 OID 17043)
-- Name: update_review(integer, integer, integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.update_review(IN p_review_id integer, IN p_member_id integer, IN p_product_id integer, IN p_rating integer, IN p_review_text text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    owner_id INT;
BEGIN
    -- Check if review exists and get owner
    SELECT member_id INTO owner_id FROM review WHERE review_id = p_review_id;

    IF owner_id IS NULL THEN
        RAISE EXCEPTION 'Review does not exist.';
    ELSIF owner_id != p_member_id THEN
        RAISE EXCEPTION 'You can only update your own review.';
    ELSE
        UPDATE review
        SET rating = p_rating,
            review_text = p_review_text,
            updated_at = CURRENT_TIMESTAMP
        WHERE review_id = p_review_id;
    END IF;
END;
$$;


--
-- TOC entry 215 (class 1259 OID 16553)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16627)
-- Name: cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart (
    id integer NOT NULL,
    member_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 16626)
-- Name: cart_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5002 (class 0 OID 0)
-- Dependencies: 230
-- Name: cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_id_seq OWNED BY public.cart.id;


--
-- TOC entry 233 (class 1259 OID 16635)
-- Name: cart_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_item (
    id integer NOT NULL,
    cart_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 16634)
-- Name: cart_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5003 (class 0 OID 0)
-- Dependencies: 232
-- Name: cart_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_item_id_seq OWNED BY public.cart_item.id;


--
-- TOC entry 217 (class 1259 OID 16566)
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    comment_id integer NOT NULL,
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    comment_text text,
    parent_comment_id integer,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 216 (class 1259 OID 16565)
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5004 (class 0 OID 0)
-- Dependencies: 216
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comment_comment_id_seq OWNED BY public.comment.comment_id;


--
-- TOC entry 219 (class 1259 OID 16576)
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    dob date NOT NULL,
    password character varying(255) NOT NULL,
    role integer NOT NULL,
    gender character(1) NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 16575)
-- Name: member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5005 (class 0 OID 0)
-- Dependencies: 218
-- Name: member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_id_seq OWNED BY public.member.id;


--
-- TOC entry 221 (class 1259 OID 16583)
-- Name: member_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_role (
    id integer NOT NULL,
    name character varying(25)
);


--
-- TOC entry 220 (class 1259 OID 16582)
-- Name: member_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5006 (class 0 OID 0)
-- Dependencies: 220
-- Name: member_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_role_id_seq OWNED BY public.member_role.id;


--
-- TOC entry 223 (class 1259 OID 16590)
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id integer NOT NULL,
    name character varying(255),
    description text,
    unit_price numeric NOT NULL,
    stock_quantity integer DEFAULT 0 NOT NULL,
    country character varying(100),
    product_type character varying(50),
    image_url character varying(255) DEFAULT '/images/product.png'::character varying,
    manufactured_on timestamp(6) without time zone
);


--
-- TOC entry 235 (class 1259 OID 16642)
-- Name: product_discount; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_discount (
    id integer NOT NULL,
    product_id integer NOT NULL,
    discount_type text NOT NULL,
    value numeric(5,2) NOT NULL,
    min_quantity integer,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16641)
-- Name: product_discount_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_discount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5007 (class 0 OID 0)
-- Dependencies: 234
-- Name: product_discount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_discount_id_seq OWNED BY public.product_discount.id;


--
-- TOC entry 222 (class 1259 OID 16589)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5008 (class 0 OID 0)
-- Dependencies: 222
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 225 (class 1259 OID 16601)
-- Name: review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    rating integer,
    review_text text,
    created_at timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp(6) without time zone
);


--
-- TOC entry 224 (class 1259 OID 16600)
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5009 (class 0 OID 0)
-- Dependencies: 224
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- TOC entry 227 (class 1259 OID 16611)
-- Name: sale_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order (
    id integer NOT NULL,
    member_id integer,
    order_datetime timestamp(6) without time zone NOT NULL,
    status character varying(10)
);


--
-- TOC entry 226 (class 1259 OID 16610)
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5010 (class 0 OID 0)
-- Dependencies: 226
-- Name: sale_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_id_seq OWNED BY public.sale_order.id;


--
-- TOC entry 229 (class 1259 OID 16618)
-- Name: sale_order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order_item (
    id integer NOT NULL,
    sale_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 16617)
-- Name: sale_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5011 (class 0 OID 0)
-- Dependencies: 228
-- Name: sale_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_item_id_seq OWNED BY public.sale_order_item.id;


--
-- TOC entry 4809 (class 2604 OID 16630)
-- Name: cart id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart ALTER COLUMN id SET DEFAULT nextval('public.cart_id_seq'::regclass);


--
-- TOC entry 4811 (class 2604 OID 16638)
-- Name: cart_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_item ALTER COLUMN id SET DEFAULT nextval('public.cart_item_id_seq'::regclass);


--
-- TOC entry 4798 (class 2604 OID 17044)
-- Name: comment comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment ALTER COLUMN comment_id SET DEFAULT nextval('public.comment_comment_id_seq'::regclass);


--
-- TOC entry 4800 (class 2604 OID 17045)
-- Name: member id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN id SET DEFAULT nextval('public.member_id_seq'::regclass);


--
-- TOC entry 4801 (class 2604 OID 17046)
-- Name: member_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role ALTER COLUMN id SET DEFAULT nextval('public.member_role_id_seq'::regclass);


--
-- TOC entry 4802 (class 2604 OID 17047)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 4812 (class 2604 OID 16645)
-- Name: product_discount id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_discount ALTER COLUMN id SET DEFAULT nextval('public.product_discount_id_seq'::regclass);


--
-- TOC entry 4805 (class 2604 OID 17048)
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- TOC entry 4807 (class 2604 OID 17049)
-- Name: sale_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order ALTER COLUMN id SET DEFAULT nextval('public.sale_order_id_seq'::regclass);


--
-- TOC entry 4808 (class 2604 OID 17050)
-- Name: sale_order_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item ALTER COLUMN id SET DEFAULT nextval('public.sale_order_item_id_seq'::regclass);


--
-- TOC entry 4815 (class 2606 OID 16561)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4837 (class 2606 OID 16640)
-- Name: cart_item cart_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_item
    ADD CONSTRAINT cart_item_pkey PRIMARY KEY (id);


--
-- TOC entry 4834 (class 2606 OID 16633)
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- TOC entry 4817 (class 2606 OID 16574)
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (comment_id);


--
-- TOC entry 4820 (class 2606 OID 16581)
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- TOC entry 4823 (class 2606 OID 16588)
-- Name: member_role member_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role
    ADD CONSTRAINT member_role_pkey PRIMARY KEY (id);


--
-- TOC entry 4839 (class 2606 OID 16650)
-- Name: product_discount product_discount_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_discount
    ADD CONSTRAINT product_discount_pkey PRIMARY KEY (id);


--
-- TOC entry 4825 (class 2606 OID 16599)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 4827 (class 2606 OID 16609)
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- TOC entry 4831 (class 2606 OID 16625)
-- Name: sale_order_item sale_order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT sale_order_item_pkey PRIMARY KEY (id);


--
-- TOC entry 4829 (class 2606 OID 16616)
-- Name: sale_order sale_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT sale_order_pkey PRIMARY KEY (id);


--
-- TOC entry 4835 (class 1259 OID 16654)
-- Name: cart_item_cart_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cart_item_cart_id_product_id_key ON public.cart_item USING btree (cart_id, product_id);


--
-- TOC entry 4832 (class 1259 OID 16653)
-- Name: cart_member_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cart_member_id_key ON public.cart USING btree (member_id);


--
-- TOC entry 4818 (class 1259 OID 16652)
-- Name: member_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX member_email_key ON public.member USING btree (email);


--
-- TOC entry 4821 (class 1259 OID 16651)
-- Name: member_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX member_username_key ON public.member USING btree (username);


--
-- TOC entry 4840 (class 1259 OID 25552)
-- Name: product_discount_product_id_is_active_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_discount_product_id_is_active_start_date_end_date_idx ON public.product_discount USING btree (product_id, is_active, start_date, end_date);


--
-- TOC entry 4851 (class 2606 OID 16705)
-- Name: cart_item cart_item_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_item
    ADD CONSTRAINT cart_item_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4852 (class 2606 OID 16710)
-- Name: cart_item cart_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_item
    ADD CONSTRAINT cart_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4850 (class 2606 OID 16700)
-- Name: cart cart_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4841 (class 2606 OID 16655)
-- Name: comment comment_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4842 (class 2606 OID 16660)
-- Name: comment comment_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.comment(comment_id) ON DELETE CASCADE;


--
-- TOC entry 4843 (class 2606 OID 16665)
-- Name: comment comment_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.review(review_id) ON DELETE CASCADE;


--
-- TOC entry 4844 (class 2606 OID 16670)
-- Name: member fk_member_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT fk_member_role_id FOREIGN KEY (role) REFERENCES public.member_role(id);


--
-- TOC entry 4848 (class 2606 OID 16690)
-- Name: sale_order_item fk_sale_order_item_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_product FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 4849 (class 2606 OID 16695)
-- Name: sale_order_item fk_sale_order_item_sale_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_sale_order FOREIGN KEY (sale_order_id) REFERENCES public.sale_order(id);


--
-- TOC entry 4847 (class 2606 OID 16685)
-- Name: sale_order fk_sale_order_member; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT fk_sale_order_member FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4853 (class 2606 OID 16715)
-- Name: product_discount product_discount_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_discount
    ADD CONSTRAINT product_discount_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4845 (class 2606 OID 16675)
-- Name: review review_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id);


--
-- TOC entry 4846 (class 2606 OID 16680)
-- Name: review review_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


-- Completed on 2025-08-15 11:35:47

--
-- PostgreSQL database dump complete
--

