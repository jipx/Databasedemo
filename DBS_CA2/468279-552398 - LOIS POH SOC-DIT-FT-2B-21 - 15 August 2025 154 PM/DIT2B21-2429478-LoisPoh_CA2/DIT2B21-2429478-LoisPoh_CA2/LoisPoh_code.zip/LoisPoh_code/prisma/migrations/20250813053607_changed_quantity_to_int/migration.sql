/*
  Warnings:

  - You are about to alter the column `quantity` on the `cart_item` table. The data in that column could be lost. The data in that column will be cast from `Decimal(10,2)` to `Integer`.
  - You are about to alter the column `stock_quantity` on the `product` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Integer`.

*/
-- AlterTable
ALTER TABLE "public"."cart_item" ALTER COLUMN "quantity" SET DATA TYPE INTEGER;

-- AlterTable
ALTER TABLE "public"."product" ALTER COLUMN "stock_quantity" SET DEFAULT 0,
ALTER COLUMN "stock_quantity" SET DATA TYPE INTEGER;

-- CreateIndex
CREATE INDEX "product_discount_product_id_is_active_start_date_end_date_idx" ON "public"."product_discount"("product_id", "is_active", "start_date", "end_date");
