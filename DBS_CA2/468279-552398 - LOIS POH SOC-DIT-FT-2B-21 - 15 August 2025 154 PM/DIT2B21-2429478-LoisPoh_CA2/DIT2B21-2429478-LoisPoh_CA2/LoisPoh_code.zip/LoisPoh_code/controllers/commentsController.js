const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const commentsModel = require('../models/comments');

// GET /comments/review/:id
module.exports.getCommentsByReview = async function(req, res) {
    try {
        const comments = await commentsModel.getByReviewId(parseInt(req.params.id));
        res.json(comments);
    } catch (err) {
          console.error("getCommentsByReview failed:", err); 
        res.status(500).json({ error: err.message });
    }
}

// POST /comments
module.exports.createComment = async function(req, res)  {
    // console.log(req.user);
    const { review_id, comment_text, parent_comment_id } = req.body;
    const member_id = req.user.memberId;
     console.log('Received body:', req.body);
    try {
        await commentsModel.addComment({
            review_id,
            member_id,
            comment_text,
            parent_comment_id: parent_comment_id || null  // ensure null if undefined
        });
        res.status(201).json({ message: 'Comment added' });
    } catch (err) {
        console.error('Create comment error:', err);
        res.status(400).json({ error: err.message });
    }
}

// DELETE /comments/:commentId
module.exports.removeComment = async function(req, res) {
    const comment_id = req.params.commentId;
    const member_id = req.user.memberId;

    try {
        await commentsModel.deleteComment({ comment_id, member_id });
        res.json({ message: 'Comment deleted (if you owned it)' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
}


