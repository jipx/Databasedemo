const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const reviewsModel = require('../models/reviews');

const reviewsController = {
    async createReview(req, res) {
        console.log('req.user:', req.user); 
        const { memberId } = req.user;
        const product_id = parseInt(req.body.product_id);
        const rating = parseInt(req.body.rating);
        const review_text = req.body.review_text;

        try {
            await reviewsModel.create(memberId, product_id, rating, review_text);
            res.status(201).json({ message: 'Review created successfully' });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    },

    async updateReview(req, res) {
        const { memberId } = req.user; 
        const { review_id } = req.params;
        const { product_id, rating, review_text } = req.body;

        try {
            await reviewsModel.update(review_id, memberId, product_id, rating, review_text);
            res.status(200).json({ message: 'Review updated successfully' });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    },

    async deleteReview(req, res) {
        const { memberId } = req.user; 
        const { review_id } = req.params;

        try {
            await reviewsModel.delete(review_id, memberId);
            res.status(200).json({ message: 'Review deleted successfully' });
        } catch (err) {
            res.status(400).json({ error: err.message });
        }
    },

    async getAllReviews(req, res) {
        const { memberId } = req.user;
        console.log("Fetching reviews for member:", memberId);
        try {
            const reviews = await reviewsModel.getAllByMember(memberId);
            console.log("Reviews returned from DB:", reviews);
            res.status(200).json({ reviews });
        } catch (err) {
            if (err.message === EMPTY_RESULT_ERROR) { //if empty result
                res.status(200).json({ reviews: [], message: 'No reviews yet.' });
            } else {
                res.status(400).json({ error: err.message });
            }
        }
    },
    
    async getByProduct(req, res) {
    const productId = parseInt(req.params.product_id);
    if (isNaN(productId)) {
      return res.status(400).json({ error: 'Invalid product ID' });
    }

    try {
      const reviews = await reviewsModel.getByProduct(productId);
      res.status(200).json(reviews);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};

module.exports = reviewsController;
