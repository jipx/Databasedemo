// you can modify the code below to suit your needs
const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR } = require('../errors');
const cartsModel = require('../models/carts');
const productModel = require('../models/products');

module.exports.createCartItems = async function (req, res) {
    try {
        const memberId = req.user.memberId;   
        const {productId, quantity } = req.body;
        if (!memberId || !productId || !quantity) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        if (quantity <= 0) {
            return res.status(400).json({ error: 'Quantity must be positive' });
        }
        //check product stock 
        const product = await productModel.getProductById(productId);
        // console.log(product);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        if (product.stockQuantity <= 0) {
            return res.status(400).json({ error: 'Product is out of stock' });
        }
        if (quantity > product.stockQuantity) {
            return res.status(400).json({ error: `Only ${product.stockQuantity} units available` });
        }
        const item = await cartsModel.createCartItem(memberId, productId, quantity);
        res.status(201).json(item);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

module.exports.updateCartItems = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        const { productId, quantity } = req.body;

        // Validate input
        if (!productId || typeof quantity !== 'number' || quantity <= 0) {
            return res.status(400).json({ error: 'Valid productId and quantity are required' });
        }

        // Update in DB
        const updatedItem = await cartsModel.updateCartItem(memberId, productId, quantity);

        return res.json({
            message: 'Cart item updated successfully',
            updatedItem
        });
    } catch (err) {
        console.error('Error updating cart item:', err);
        return res.status(500).json({ error: 'Failed to update cart item' });
    }
}

module.exports.retrieveCartItems = async function (req, res) {
    try {
        console.log("Decoded user from token:", req.user);
        const memberId = req.user.memberId;
        const items = await cartsModel.getCartItems(memberId);
        res.status(200).json({ cartItems: items });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


module.exports.deleteCartItems = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        const { productId } = req.body;
        if (!memberId || !productId) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const deletedItem = await cartsModel.deleteCartItem(memberId, productId);
        res.status(200).json(deletedItem);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

//get cart summary
module.exports.getCartSummary = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        const summary = await cartsModel.getCartSummary(memberId);
        res.status(200).json({ cartSummary: summary });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// GET /checkout
module.exports.getCheckout = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        if (!memberId) {
            return res.status(400).json({ success: false, error: 'memberId required' });
        }

        const data = await cartsModel.getCheckoutData(memberId);
        res.status(200).json({ success: true, data });
    } catch (err) {
        console.error('Error in getCheckout:', err);
        res.status(500).json({ success: false, error: 'Failed to load checkout data' });
    }
};

// POST /checkout/placeOrder
module.exports.placeOrder = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        if (!memberId) return res.status(400).json({ error: 'memberId required' });
        // Check if cart is empty
        const cart = await cartsModel.getCartItems(memberId);
        if (!cart || cart.length === 0) {
            return res.status(400).json({ error: 'Your cart is empty. Please add items before placing an order.' });
        }

        const result = await cartsModel.placeOrder(memberId);
        res.status(200).json(result);
    } catch (err) {
        console.error('Error in placeOrder:', err);
        res.status(500).json({ error: 'Failed to place order' });
    }
};

module.exports.orderStatus = async function (req, res) {
    try {
        const memberId = req.user.memberId;
        const orderId = req.params.orderId || req.query.orderId;
        if (!orderId) {
            return res.status(400).json({ error: "orderId required" })
        }
        const result = await cartsModel.getOrderStatus(memberId, orderId);
        res.status(200).json(result);

    } catch (error) {
        console.error('Error in placeOrder:', error);
        res.status(500).json({ error: 'Failed to place order' });
    }

}