const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

module.exports.retrieveById = function retrieveById(productId) {
    const sql = `SELECT * FROM product WHERE id= $1`;
    return query(sql, [productId]).then(function (result) {
        const rows = result.rows;

        if (rows.length === 0) {
            throw new EMPTY_RESULT_ERROR(`Product ${productId} not found!`); //if result is empty error is thrown
        }

        return rows[0];
    });
};

module.exports.retrieveAll = function retrieveAll() {
    const sql = `SELECT * FROM product`;
    return query(sql).then(function (result) {
        return result.rows;
    });
};


module.exports.getProductById = function (productId) {
    return prisma.product.findUnique({
        where: { id: Number(productId) }
    });
}
