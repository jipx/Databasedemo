const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');


const reviewsModel = {
  async create(memberId, productId, rating, reviewText) {
    const sql = 'CALL create_review($1, $2, $3, $4)';
    try {
      await query(sql, [memberId, productId, rating, reviewText]);
    } catch (err) {
      throw err; 
    }
  },

  async update(reviewId, memberId, productId, rating, reviewText) {
    const sql = 'CALL update_review($1, $2, $3, $4, $5)';
    try {
      await query(sql, [reviewId, memberId, productId, rating, reviewText]);
    } catch (err) {
      throw err;
    }
  },

  async delete(reviewId, memberId) {
    const sql = 'CALL delete_review($1, $2)';
    try {
      await query(sql, [reviewId, memberId]);
    } catch (err) {
      throw err;
    }
  },

  async getAllByMember(memberId) {
    const sql = 'SELECT * FROM get_reviews($1)';
    try {
      console.log("Running get_reviews with memberId =", memberId); 
      const result = await query(sql, [memberId]);
      console.log("result object:", result);                        
      console.log("result.rows:", result.rows);                     

      if (result.rows.length === 0) throw new Error(EMPTY_RESULT_ERROR);
      return result.rows;
    } catch (err) {
      console.error("ERROR in getAllByMember:", err.message);    
      throw err;
    }
  },

    async getByProduct(productId) {
    const sql = 'SELECT * FROM get_reviews_for_product($1)';
    try {
      const result = await query(sql, [productId]);
      return result.rows;
    } catch (err) {
      throw err;
    }
  }

};

module.exports = reviewsModel;
