const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

// Get all comments for a review
module.exports.getByReviewId = async function (reviewId) {
    const result = await query(
        `SELECT * FROM get_comments($1);`,
        [reviewId]
    );

    return result.rows;
}


// Add a new comment
module.exports.addComment= async function({ review_id, member_id, comment_text, parent_comment_id }) {
    await query(
        `SELECT create_comment($1, $2, $3, $4)`,
        [review_id, member_id, comment_text, parent_comment_id || null]
    );
}

// Delete a comment (only if it's the member's own)
module.exports.deleteComment = async function ({ comment_id, member_id }) {
    await query(
        `SELECT delete_comment($1, $2)`,
        [comment_id, member_id]
    );
}

