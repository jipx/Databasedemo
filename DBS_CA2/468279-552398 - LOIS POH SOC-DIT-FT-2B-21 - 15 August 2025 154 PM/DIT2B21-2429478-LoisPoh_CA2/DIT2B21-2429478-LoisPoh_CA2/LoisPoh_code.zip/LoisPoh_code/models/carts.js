const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Get cart by member
module.exports.getCartByMemberId = async function (memberId) {
    const cart = await prisma.cart.findUnique({
        where: { memberId: memberId } 
    });
    return cart || null;
};

// Create new cart for each member
module.exports.createCartByMemberId = async function (memberId) {
    const cart = await prisma.cart.create({
        data: {
            memberId: memberId
        }
    });
    return cart;
};

// Get all items in member's cart
module.exports.getCartItems = async function (memberId) {
    const cart = await prisma.cart.findUnique({
        where: { memberId: memberId },
        include: {
            items: {
                include: {
                    product: true // fetch all product fields
                }
            }
        }
    });

    if (!cart) return []; // No cart found
    // console.log("cartitems",cart.items);
    return cart.items.map(item => ({
        id: item.id,
        quantity: item.quantity,
        productId: item.product.id,
        description: item.product.description,
        country: item.product.country,
        unitPrice: item.product.unitPrice
    }));
};


// Add a new item to cart
module.exports.createCartItem = async function (memberId, productId, quantity) {
    let cart = await prisma.cart.findUnique({
        where: { memberId: memberId }
    });

    if (!cart) {
        cart = await prisma.cart.create({
            data: {
                memberId: memberId,
                created_at: new Date(),
                updated_at: new Date()
            }
        });
    }

    // Add or update the item in the cart
    const result = await prisma.cartItem.upsert({
        where: {
            cartId_productId: {  
                cartId: cart.id,
                productId: productId
            }
        },
        update: {
            quantity: { increment: quantity } // adds to existing quantity
        },
        create: {
            cartId: cart.id,
            productId: productId,
            quantity: quantity
        }
    });

    return result;
};


// Update a cart item quantity
module.exports.updateCartItem = async function (memberId, productId, quantity) {
    const cart = await prisma.cart.findUnique({
        where: { memberId: memberId }
    });

    if (!cart) throw new Error('Cart not found');

    const result = await prisma.cartItem.updateMany({
        where: {
            cartId: cart.id,
            productId: productId
        },
        data: {
            quantity: quantity
        }
    });

    if (result.count === 0) throw new Error('Cart item not found');

    return await prisma.cartItem.findFirst({
        where: {
            cartId: cart.id,
            productId: productId
        }
    });
};

// Delete a cart item
module.exports.deleteCartItem = async function (memberId, productId) {
    const cart = await prisma.cart.findUnique({
        where: { memberId: memberId }
    });

    if (!cart) throw new Error('Cart not found');

    const deletedItem = await prisma.cartItem.findFirst({
        where: {
            cartId: cart.id,
            productId: productId
        }
    });

    if (!deletedItem) throw new Error('Cart item not found');

    await prisma.cartItem.delete({
        where: { id: deletedItem.id }
    });

    return deletedItem;
};

module.exports.getCartSummary = async function (memberId) {
    const cart = await prisma.cart.findUnique({
        where: { memberId: memberId },
        include: {
            items: {
                include: {
                    product: true
                }
            }
        }
    });

    if (!cart) return { total_quantity: 0, total_price: 0 };

    let totalQuantity = 0;
    let totalPrice = 0;

    for (const item of cart.items) {
        const qty = parseFloat(item.quantity);
        const pricePerUnit = parseFloat(item.product.unitPrice); // no discount applied
        totalQuantity += qty;
        totalPrice += pricePerUnit * qty;
    }

    return {
        total_quantity: totalQuantity,
        total_price: parseFloat(totalPrice.toFixed(2))
    };
};

module.exports.getCheckoutData = async function (memberId) {
    // const now = new Date();

    const cart = await prisma.cart.findUnique({
        where: { memberId },
        include: {
            items: {
                include: {
                    product: {
                        include: {
                            discounts: true
                        }
                    }
                }
            }
        }
    });
    if (!cart || cart.items.length === 0) {
        return { items: [], subtotal: 0, totalDiscount: 0, grandTotal: 0 };
    }

    let subtotal = 0;
    let totalDiscount = 0;
    const itemsData = [];

    const calcDiscount = (lineSubtotal, discounts, qty) => {

        if (!discounts || discounts.length === 0) return 0;
        // Find the first discount where minQuantity is null or satisfied
        const d = discounts.find(d => !d.minQuantity || qty >= d.minQuantity);
        if (!d) return 0;
        const val = Number(d.value);
        if (d.discountType === 'percentage') {
            return lineSubtotal * (val / 100);
        } else if (d.discountType === 'fixed') {
            return val;
        }
        return 0;
    };

    for (const item of cart.items) {
        const unitPrice = Number(item.product.unitPrice);
        const qty = item.quantity;
        const lineSubtotal = unitPrice * qty;
        console.log(item);
        const discountAmount = calcDiscount(lineSubtotal, item.product.discounts, qty);
        const lineTotal = lineSubtotal - discountAmount;

        subtotal += lineSubtotal;
        totalDiscount += discountAmount;

        itemsData.push({
            productName: item.product.name,
            quantity: qty,
            unitPrice,
            discount: discountAmount,
            lineTotal
        });
    }

    const grandTotal = subtotal - totalDiscount;
    return { items: itemsData, subtotal, totalDiscount, grandTotal };
};




module.exports.placeOrder = async function (memberId) {
    // Call existing commit procedure
    await prisma.$executeRaw`CALL public.place_orders(${memberId}::int)`;


    const latestOrder = await prisma.saleOrder.findFirst({
        where: { memberId },
        orderBy: { orderDatetime: 'desc' },
        include: { saleOrderItem: true }
    });

    return {
        orderId: latestOrder?.id || null,
        message: 'Order placed successfully'
    };
};

module.exports.getOrderStatus = async function (memberId, orderId) {
    const order = await prisma.saleOrder.findFirst({
        where: {
            id: Number(orderId),
            memberId: (memberId) // ensure the order belongs to the logged-in member
        },
        select: { status: true }
    });

    if (!order) {
        const err = new Error('Order not found');
        err.status = 404;
        throw err;
    };

    return { status: order.status };

}

