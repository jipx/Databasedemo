window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");
    const cartProductId = localStorage.getItem("cartProductId");
    const memberId = localStorage.getItem("memberId"); //logged-in user id

    const productIdInput = document.querySelector("input[name='productId']");
    const quantityInput = document.querySelector("input[name='quantity']");
    const messageDiv = document.querySelector("#message");

    //prefill product id
    productIdInput.value = cartProductId;

    //handle form submit
    document.querySelector("form").addEventListener("submit", async function (e) {
        e.preventDefault();

        const productId = parseInt(productIdInput.value);
        const quantity = parseInt(quantityInput.value);

        if (!memberId || !productId || !quantity || quantity <= 0) {
            messageDiv.textContent = "Please enter valid product ID and quantity.";
            messageDiv.style.color = "red";
            return;
        }

        try {
            const res = await fetch("/carts/create", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}` 
                },
                body: JSON.stringify({ memberId: parseInt(memberId), productId, quantity })
            });

            if (!res.ok) {
                const errorData = await res.json();
                throw new Error(errorData.error || "Failed to add item");
            }

            messageDiv.textContent = `Added ${quantity} of Product ${productId} to cart.`;
            messageDiv.style.color = "green";

            quantityInput.value = ""; //clear quantity field
        } catch (err) {
            messageDiv.textContent = err.message;
            messageDiv.style.color = "red";
        }
    });


});
