window.addEventListener('DOMContentLoaded', function () {
  const token = localStorage.getItem("token");
  const form = document.getElementById("productSalesForm");
  const resetBtn = document.getElementById("resetSort");
  const tbody = document.querySelector("#salesSummaryTable tbody");

  function fetchSalesOrderSummary(queryParams) {  
    queryParams = queryParams || "";//query params default to empty string, prevent undefined to be passed in the URL
    fetch(`/dashboard/salesOrderSummary?${queryParams}`, { //containing all the parameters passed
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(response => response.json())
      .then(body => {
        console.log(body.data);

        if (body.error) throw new Error(body.error);

        // Clear existing table rows
        tbody.innerHTML = "";

        // Insert new rows from data
        body.data.forEach(row => {
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <td>${row.productId}</td>
            <td>${row.productName}</td>
            <td>${row.productType}</td>
            <td>${row.totalQuantitySold}</td>
            <td>${row.unitPrice}</td>
          `;
          tbody.appendChild(tr);
        });
      })
      .catch(error => {
        console.error("Error fetching sales summary:", error);
        tbody.innerHTML = `<tr><td colspan="5">Failed to load data.</td></tr>`; //Show this message on the front end when error occurs
      });
  }

  // On form submit, prevent reload, fetch with filters
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const formData = new FormData(form);
    const productType = formData.get("productType") || "";
    const sortOption = formData.get("sortOption") || "name";
    const gender = form.querySelector('input[name="gender"]:checked').value || ""; //finds the checked radio value that has the name "gender"

    const params = new URLSearchParams();
    if (productType) params.append("productType", productType);
    if (sortOption) params.append("sortOption", sortOption);
    if (gender) params.append("gender", gender);
    fetchSalesOrderSummary(params.toString());
  });

  // On reset button click, reset form and reload default data
  resetBtn.addEventListener("click", function () {
    form.reset();
    fetchSalesOrderSummary(); // fetch default data with no filters
  });

  // Initial fetch of default data on page load
  fetchSalesOrderSummary();
});
