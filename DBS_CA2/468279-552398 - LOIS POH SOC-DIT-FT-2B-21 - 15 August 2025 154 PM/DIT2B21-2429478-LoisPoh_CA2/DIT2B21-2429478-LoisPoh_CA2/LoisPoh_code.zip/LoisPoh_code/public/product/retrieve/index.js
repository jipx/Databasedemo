function nestComments(comments) { //create a tree structure for the nested comments 
    const map = {};
    const roots = [];

    comments.forEach(c => {
        console.log("comment_id check:", c);
        c.children = []; //for each comment, create an array to store all the children comments 
        map[c.commentId] = c; //store comment id to comment
    });

    comments.forEach(c => {
        if (c.parentCommentId) { //if comment has a parent
            if (map[c.parentCommentId]) {  //if parent exists
                map[c.parentCommentId].children.push(c); //add comment as a child to parent
            } else {
                roots.push(c); //parent doesn't exist/missing, treat as a root comment
            }
        } else {
            roots.push(c); //no parent: root comment 
        }
    });

    /* Example:
   Input: [
     {commentId: 1, parentCommentId: null, text: "Root"},
     {commentId: 2, parentCommentId: 1, text: "Reply to Root"},
     {commentId: 3, parentCommentId: 2, text: "Reply to Reply"}
   ]
   Output:
   [
     {commentId: 1, children: [
       {commentId: 2, children: [
         {commentId: 3, children: []}
       ]}
     ]}
   ]
*/
    console.log("nested tree:", JSON.stringify(roots, null, 2));
    return roots; //return the nested tree array [parentComment[childComment[childComment]]];
}

//fetch comments for a reviewId
async function fetchCommentsForReview(reviewId) { 
    const token = localStorage.getItem("token");

    const res = await fetch(`/comments/review/${reviewId}`, {
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load comments');

    const comments = await res.json();
    console.log(comments);
    return nestComments(comments);
}

// render nested comments visually 
function renderCommentTree(commentNodes, container, depth, reviewId) { 
// params: (object containing the comment, the DOM element containing the comments, how deep is the comment nested (0 for root comments, +1 for each reply, reviewId))
    commentNodes.forEach(c => {  //for each comment
        const div = document.createElement('div'); 
        console.log('depth:', depth, 'comment_id:', c.commentId); 
        div.classList.add('comment');

        div.innerHTML = `
        <div class="comment-body" style="padding-left: ${depth * 20 + 10}px;">
            <strong>${c.username}</strong>: ${c.commentText}
            <button class="reply-btn" data-comment-id="${c.commentId}" data-review-id="${reviewId}">Reply</button>
            ${c.memberId === currentUserId ? `<button class="delete-btn" data-comment-id="${c.commentId}">Delete</button>` : ''} 
        </div> 
        `; //if comment.memberId = current member id, add a delete button


        container.appendChild(div); //add the newly created comment in the container element

        if (c.children.length > 0) {
            renderCommentTree(c.children, container, depth + 1, reviewId);  
            //if the comment has any replies, call the same function and store in the container and increase the depth by 1 so comment appears indented
        }
    });
}


function fetchProduct(productId) {
    const token = localStorage.getItem("token");

    return fetch(`/products/${productId}`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(body => {
            if (body.error) throw new Error(body.error);
            const product = body.product;
            const tbody = document.querySelector("#product-tbody");

            const row = document.createElement("tr");
            row.classList.add("product");
            const nameCell = document.createElement("td");
            const descriptionCell = document.createElement("td");
            const unitPriceCell = document.createElement("td");
            const countryCell = document.createElement("td");
            const productTypeCell = document.createElement("td");
            const imageUrlCell = document.createElement("td");
            const manufacturedOnCell = document.createElement("td");

            nameCell.textContent = product.name;
            descriptionCell.textContent = product.description;
            unitPriceCell.textContent = product.unitPrice;
            countryCell.textContent = product.country;
            productTypeCell.textContent = product.productType;
            imageUrlCell.innerHTML = `<img src="${product.imageUrl}" alt="Product Image">`;
            manufacturedOnCell.textContent = new Date(product.manufacturedOn).toLocaleString();

            row.appendChild(nameCell);
            row.appendChild(descriptionCell);
            row.appendChild(unitPriceCell);
            row.appendChild(countryCell);
            row.appendChild(productTypeCell);
            row.appendChild(imageUrlCell);
            row.appendChild(manufacturedOnCell);
            tbody.appendChild(row);
        })
        .catch(error => {
            console.error(error);
        });
}

// Extract current logged-in user ID from JWT token
const currentUserId = (() => {
    try {
        const token = localStorage.getItem("token");
        if (!token) return null;
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.memberId || payload.id || null;
    } catch {
        return null;
    }
})();

// Fetch reviews + their nested comments and render everything
async function fetchProductReviews(productId) {
    const token = localStorage.getItem("token");

    const res = await fetch(`/reviews/product/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load reviews');
    const reviews = await res.json();

    const reviewsContainer = document.querySelector('#reviews-container');
    reviewsContainer.innerHTML = ''; // clear previous

    if (!Array.isArray(reviews) || reviews.length === 0) {
        const noReviewMsg = document.createElement("p");
        noReviewMsg.textContent = "There are currently no reviews for this product";
        noReviewMsg.style.fontStyle = "italic";
        noReviewMsg.style.color = "gray";
        reviewsContainer.appendChild(noReviewMsg);
        return;
    }

    for (const review of reviews) {
        const reviewDiv = document.createElement('div');
        reviewDiv.classList.add('review-row');

        let ratingStars = '';
        for (let i = 0; i < review.rating; i++) {
            ratingStars += '⭐';
        }

        reviewDiv.innerHTML = `
        <h3>Member Username: ${review.username}</h3>
        <p>Rating: ${ratingStars}</p>
        <p>Review Text: ${review.reviewText}</p>
        <p>Last Updated: ${review.updatedAt ? new Date(review.updatedAt).toLocaleString() : ""}</p>
    `;

        try {
            const comments = await fetchCommentsForReview(review.reviewId);

            const commentsDiv = document.createElement('div');
            commentsDiv.classList.add('comments-container');
            commentsDiv.style.marginTop = '15px';

            // Comment header
            const commentHeader = document.createElement('div');
            commentHeader.style.display = 'flex';
            commentHeader.style.justifyContent = 'space-between';
            commentHeader.style.alignItems = 'center';
            commentHeader.style.marginBottom = '10px';

            const headerTitle = document.createElement('h4');
            headerTitle.textContent = 'Comments';

            const commentCount = document.createElement('span');
            commentCount.textContent = `${comments.length} comment${comments.length !== 1 ? 's' : ''}`;
            commentCount.style.fontWeight = 'normal';
            commentCount.style.fontSize = '0.9rem';

            commentHeader.appendChild(headerTitle);
            commentHeader.appendChild(commentCount);
            commentsDiv.appendChild(commentHeader);

            if (comments.length > 0) {
                renderCommentTree(comments, commentsDiv, 0, review.reviewId);
            } else {
                // If no comments, show a No comments yet message
                const noCommentsMsg = document.createElement('p');
                noCommentsMsg.textContent = 'No comments yet.';
                noCommentsMsg.style.fontStyle = 'italic';
                noCommentsMsg.style.color = 'gray';
                commentsDiv.appendChild(noCommentsMsg);
            }

            // Always add "Add Comment" button below comments
            const addCommentBtn = document.createElement('button');
            addCommentBtn.textContent = 'Add Comment';
            addCommentBtn.classList.add('add-comment-btn');
            addCommentBtn.dataset.reviewId = review.reviewId;
            addCommentBtn.style.marginTop = '10px';
            commentsDiv.appendChild(addCommentBtn);

            reviewDiv.appendChild(commentsDiv);
        } catch (err) {
            console.error('Failed to load comments for review', review.id, err);
        }

        reviewsContainer.appendChild(reviewDiv);
    }


}

// reply and delete buttons 
document.addEventListener('click', async (event) => {
    if (event.target.classList.contains('reply-btn')) {
        const commentId = event.target.dataset.commentId;
        const reviewId = event.target.dataset.reviewId;

        console.log(event.target.dataset);

        // Check if a reply form already exists under the comment to avoid duplicates
        if (document.querySelector(`#reply-form-${commentId}`)) return;

        // Create a form element
        const form = document.createElement('form');
        form.id = `reply-form-${commentId}`;
        form.style.marginTop = '8px';

        form.innerHTML = `
        <textarea rows="3" cols="50" placeholder="Write your reply..." required></textarea><br>
        <button type="submit">Submit Reply</button>
        <button type="button" class="cancel-reply-btn">Cancel</button>
    `;

        // Insert the form right after the comment div
        event.target.parentElement.appendChild(form);

        // Handle submit add comment form submission
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const replyText = form.querySelector('textarea').value.trim();
            if (!replyText) return alert('Reply cannot be empty.');

            try {
                console.log(reviewId);
                const token = localStorage.getItem("token");
                const res = await fetch('/comments', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        review_id: reviewId,
                        comment_text: replyText,
                        parent_comment_id: parseInt(commentId)
                    })
                });
                if (!res.ok) throw new Error('Failed to add reply');
                alert('Reply added!');
                const productId = localStorage.getItem("productId");
                fetchProductReviews(productId); // refresh reviews and comments
            } catch (err) {
                alert(err.message);
            }
        });

        // handle cancel button to remove the form
        form.querySelector('.cancel-reply-btn').addEventListener('click', () => {
            form.remove();
        });
    }


    if (event.target.classList.contains('delete-btn')) {
        const commentId = event.target.dataset.commentId;
        if (confirm('Are you sure you want to delete this comment?')) {
            const token = localStorage.getItem("token");
            try {
                const res = await fetch(`/comments/${commentId}`, {
                    method: 'DELETE',
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                if (!res.ok) throw new Error('Failed to delete comment');
                alert('Comment deleted');
                // refresh page
                const productId = localStorage.getItem("productId");
                fetchProductReviews(productId);
            } catch (err) {
                alert(err.message);
            }
        }
    }
    //add comment button
    if (event.target.classList.contains('add-comment-btn')) {
        const reviewId = event.target.dataset.reviewId;

        // Check if form already exists
        if (document.querySelector(`#comment-form-${reviewId}`)) return;

        // Create form elements
        const form = document.createElement('form');
        form.id = `comment-form-${reviewId}`;
        form.innerHTML = `
    <textarea rows="3" cols="50" placeholder="Write your comment..." required></textarea><br>
    <button type="submit">Submit Comment</button>
  `;

        event.target.insertAdjacentElement('afterend', form);

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const commentText = form.querySelector('textarea').value.trim();
            if (!commentText) return alert('Comment cannot be empty.');

            try {
                const token = localStorage.getItem("token");
                const reviewId = event.target.dataset.reviewId;
                console.log(reviewId);
                const res = await fetch('/comments', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        review_id: parseInt(reviewId),
                        comment_text: commentText
                    })
                });

                const data = await res.json();
                if (!res.ok) {
                    if (data.error === "You cannot comment on your own review.") {
                        alert("You cannot comment on your own review. Please reply to another comment instead.");
                    } else {
                        alert("Failed to add comment: " + data.error);
                    }
                    return;
                }
                alert('Comment added!');
                const productId = localStorage.getItem("productId");
                fetchProductReviews(productId); // refresh comments
            } catch (err) {
                alert(err.message);
            }
        });
    }

});

document.addEventListener('DOMContentLoaded', function () {
    const productId = localStorage.getItem("productId");

    fetchProduct(productId)
        .then(() => fetchProductReviews(productId))
        .catch(console.error);
});
