document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "/login";
    return;
  }

  await loadCheckoutData(token);

  const btn = document.getElementById("place-order-btn");
  if (btn) {
    btn.addEventListener("click", async () => {
      await placeOrder(token);
    });
  } else {
    console.warn("#place-order-btn not found");
  }
});

function money(n) {
  return Number(n || 0).toFixed(2);
}

async function loadCheckoutData(token) {
  try {
    const res = await fetch("/carts/checkout", {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const body = await res.json();
    console.log("checkout body:", body);

    if (!res.ok || body.error || body.success === false) {
      const msg = body.error || `HTTP ${res.status}`;
      alert(`Failed to load checkout: ${msg}`);
      throw new Error(msg);
    }

    // Support both shapes: {success:true,data:{...}} or plain {...}
    const data = body.data ?? body;

    const tbody = document.getElementById("checkout-items");
    if (!tbody) throw new Error("#checkout-items not found in DOM");

    tbody.innerHTML = "";
    (data.items ?? []).forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>$${money(item.unitPrice)}</td>
        <td>$${money(item.discount)}</td>
        <td>$${money(item.lineTotal)}</td>
      `;
      tbody.appendChild(tr);
    });

    document.getElementById("subtotal").textContent = money(data.subtotal);
    document.getElementById("total-discount").textContent = money(data.totalDiscount);
    document.getElementById("grand-total").textContent = money(data.grandTotal);

    // alert("Checkout data loaded successfully!");
  } catch (err) {
    console.error("Error loading checkout data:", err);
    alert("An unexpected error occurred while loading checkout data.");
  }
}

async function placeOrder(token) {
  try {
    const rows = document.querySelectorAll("#checkout-items tr");
    if (!rows.length) {
      alert("Your cart is empty. Please add items before placing an order.");
      return;
    }
    const res = await fetch("/carts/placeOrder", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` }
    });
    const result = await res.json();
    console.log("placeOrder result:", result);

    if (!res.ok || result.error || result.success === false) {
      const msg = result.error || `HTTP ${res.status}`;
      alert(msg); 
      throw new Error(msg);
    }

    const payload = result;
    console.log("payload", result)

    alert(`Checkout successful!${payload.orderId ? ` Order #${payload.orderId}.` : ""}`);

    const output = document.getElementById("order-result");
    if (output) {
      output.style.display = "block";
      output.innerHTML = `
        <h3>Order Placed!</h3>
        ${payload.orderId ? `<p>Order ID: ${payload.orderId}</p>` : ""}
         <p><strong>Status:</strong> <span id="order-status-text">Checking…</span></p>

      `;
    }

    if (payload.orderId) {
      await fetchOrderStatus(payload.orderId, token); 
    }

    //Refresh the checkout table & totals so it reflects the new state
    await loadCheckoutData(token);

  } catch (err) {
    console.error("Error placing order:", err);
    alert("An unexpected error occurred while placing your order.");
  }
}

async function fetchOrderStatus(orderId, token) {
  const statusEl = document.getElementById("order-status-text");
  if (statusEl) statusEl.textContent = "Checking…";

  try {
    const res = await fetch(`/carts/orderStatus?orderId=${encodeURIComponent(orderId)}`, {
      method: "GET",
      headers: { "Authorization": `Bearer ${token}` }
    });
    const body = await res.json();
    console.log("orderStatus result:", body);

    if (!res.ok || body.error) {
      throw new Error(body.error || `HTTP ${res.status}`);
    }

    // Supports { status: "PACKING" } or { data: { status: "PACKING" } }
    const status = (body.status).toString();

    if (statusEl) statusEl.textContent = status;
    return status;
  } catch (err) {
    console.error("Error fetching order status:", err);
    if (statusEl) statusEl.textContent = "Unavailable";
  }
}
