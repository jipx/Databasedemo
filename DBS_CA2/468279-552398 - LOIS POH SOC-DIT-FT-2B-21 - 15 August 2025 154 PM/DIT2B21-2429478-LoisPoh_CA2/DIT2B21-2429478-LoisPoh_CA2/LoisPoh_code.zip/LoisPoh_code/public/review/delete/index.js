window.addEventListener('DOMContentLoaded', function () {
  console.log('Token on page load:', localStorage.getItem('token'));

  const token = localStorage.getItem('token');
  const storedReviewId = localStorage.getItem('reviewId');

  const form = document.querySelector('form');
  const reviewIdInput = form.querySelector('input[name=reviewId]');

  if (reviewIdInput && storedReviewId) {
    reviewIdInput.value = storedReviewId;
  }

  form.addEventListener('submit', async function (event) {
    event.preventDefault();

    if (!token) {
      alert('You must be logged in to delete a review.');
      window.location.href = '/login';
      return;
    }

    const reviewId = reviewIdInput.value.trim();
    if (!reviewId) {
      alert('Review ID is required to delete a review.');
      return;
    }

    try {
      //handle delete form submission
      const response = await fetch(`/reviews/${reviewId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        alert('Review deleted successfully.');
        window.location.href = '/review/retrieve/all/index.html'; // redirect to review list
      } else {
        const errorData = await response.json();
        alert('Failed to delete review: ' + (errorData.error || response.statusText));
      }
    } catch (error) {
      alert('Error occurred: ' + error.message);
    }
  });
});
