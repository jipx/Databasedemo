window.addEventListener('DOMContentLoaded', function () {
  console.log('Token on page load:', localStorage.getItem('token'));

  const token = localStorage.getItem('token');
  const reviewId = localStorage.getItem('reviewId');

  const form = document.querySelector('form');
  form.querySelector('input[name=reviewId]').value = reviewId; //get reviewId from the saved attribute reviewId

  form.addEventListener('submit', async function (event) {
    event.preventDefault();

    if (!token) {
      alert('You must be logged in to update a review.');
      window.location.href = '/login';
      return;
    }

    const rating = form.querySelector('select[name=rating]').value;
    const reviewText = form.querySelector('textarea[name=reviewText]').value;

    if (!rating || !reviewText.trim()) {
      alert('Please provide a rating and review text.');
      return;
    }

    try {
      const response = await fetch(`/reviews/${reviewId}`, {
        method: 'PUT', 
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rating: parseInt(rating),
          review_text: reviewText
        }),
      });

      if (response.ok) {
        alert('Review updated successfully.');
        window.location.href = '/review/retrieve/all/index.html'; // Redirect to review list
      } else {
        const errorData = await response.json();
        alert('Failed to update review: ' + (errorData.error || response.statusText));
      }
    } catch (error) {
      alert('Error occurred: ' + error.message);
    }
  });
});