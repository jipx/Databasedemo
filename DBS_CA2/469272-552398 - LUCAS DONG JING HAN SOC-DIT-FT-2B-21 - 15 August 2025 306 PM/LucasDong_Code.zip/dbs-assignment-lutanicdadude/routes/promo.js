const express = require('express');
const promoController = require('../controllers/promoController');

const router = express.Router();

router.post("/submitCode", promoController.submit_promo_code);

module.exports = router;