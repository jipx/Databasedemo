const express = require('express');
const checkOutController = require('../controllers/checkOutController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

router.use(jwtMiddleware.verifyToken);
router.post("/checkPromo", checkOutController.checkPromoCode);
router.post("/submitCart", checkOutController.checkCartForOrder, checkOutController.submitCheckOut);

module.exports = router;