// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const commentsController = require('../controllers/commentsController');
const authMiddleware = require('../middleware/authMiddleware');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// All routes in this file will use the jwtMiddleware to verify the token
// Here the jwtMiddleware is applied at the router level to apply to all routes in this file eg. router.use(...)

router.use(jwtMiddleware.verifyToken);
router.get("/comments", authMiddleware.authMiddleware, commentsController.get_comments);
router.post("/add_comments", authMiddleware.authMiddleware, commentsController.create_comment);
router.delete("/delete_comment", commentsController.checkCommentId, commentsController.delete_comment);

module.exports = router;