-- CreateTable
CREATE TABLE "review" (
    "review_id" SERIAL NOT NULL,
    "member_id" INTEGER NOT NULL,
    "product_id" INTEGER NOT NULL,
    "rating" INTEGER NOT NULL,
    "review_text" TEXT,
    "last_update" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "product_name" VARCHAR(75) NOT NULL,

    CONSTRAINT "review_pkey" PRIMARY KEY ("review_id")
);
