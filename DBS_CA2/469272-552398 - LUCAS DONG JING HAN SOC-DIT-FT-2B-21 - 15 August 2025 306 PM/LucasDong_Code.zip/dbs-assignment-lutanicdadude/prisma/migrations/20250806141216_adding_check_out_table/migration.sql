-- CreateTable
CREATE TABLE "check_out_table" (
    "id" SERIAL NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "email" VARCHAR(50) NOT NULL,
    "shipping_addr" VARCHAR(50) NOT NULL,
    "payment_method" VARCHAR(14) NOT NULL,
    "member_id" INTEGER NOT NULL,

    CONSTRAINT "check_out_table_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "check_out_table_username_key" ON "check_out_table"("username");

-- CreateIndex
CREATE UNIQUE INDEX "check_out_table_email_key" ON "check_out_table"("email");

-- AddForeignKey
ALTER TABLE "check_out_table" ADD CONSTRAINT "check_out_table_member_id_fkey" FOREIGN KEY ("member_id") REFERENCES "member"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
