-- AlterTable
ALTER TABLE "sale_order" ADD COLUMN     "payment_method" VARCHAR(50),
ADD COLUMN     "shipping_address" VARCHAR(255);
