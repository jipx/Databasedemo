const { query } = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

module.exports.creating_cart = (callback, data) => {
    const SQLSTATEMENT = `CALL create_cart(
                            $1::INT,
                            $2::INT,
                            $3::INT
                            )
                        `;
    const VALUES = [parseInt(data.member_id, 10), parseInt(data.product_id, 10), parseInt(data.quantity, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.getting_cart = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM get_cart_summary_by_member($1)`;
    const VALUES = [data.member_id];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.retrieving_cart_items = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM get_cart_details_by_member($1)`;
    const VALUES = [data.member_id];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.checking_product_id = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM CheckProductID($1)`;
    const VALUES = [parseInt(data.product_id, 10)];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.updating_cart_items = (callback, data) => {
    const SQLSTATEMENT = `CALL update_cart(
                            $1::INT,
                            $2::INT,
                            $3::INT
                        )`;
    const VALUES = [data.member_id, data.product_id, data.quantity];
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.deleting_cart_items = (callback, data) => {
    const SQLSTATEMENT = `CALL delete_cart_item($1, $2)`;
    const VALUES = [parseInt(data.member_id, 10), parseInt(data.product_id, 10)]
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.checking_cart_table = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM CheckCart($1, $2)`;
    const VALUES = [parseInt(data.member_id, 10), parseInt(data.product_id, 10)]
    query(SQLSTATEMENT, VALUES, callback);
}

module.exports.checking_quantity = (callback, data) => {
    const SQLSTATEMENT = `SELECT * FROM check_Quantity($1, $2)`;
    const VALUES = [parseInt(data.product_id, 10), parseInt(data.quantity, 10)]
    query(SQLSTATEMENT, VALUES, callback);
}