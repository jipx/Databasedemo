const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

module.exports = {
    // Create cart item
    createCartItem: async ({ member_id, product_id, quantity }) => {
        return await prisma.cart.create({
            data: {
                member_id,
                product_id,
                quantity,
            },
        });
    },

    // Get cart items for a member
    getCartItemsByMember: async (member_id) => {
        return await prisma.cart.findMany({
            where: { member_id },
            include: {
                product: {
                    select: {
                        description: true,
                        country: true,
                        unit_price: true,
                        name: true,
                        stock_quantity: true,
                    },
                },
            },
        });
    },

    // Find product by id
    findProductById: async (id) => {
        return await prisma.product.findUnique({
            where: { id },
        });
    },

    // Find cart item by member_id and product_id
    findCartItem: async (member_id, product_id) => {
        return await prisma.cart.findFirst({
            where: {
                member_id,
                product_id,
            },
        });
    },

    // Update cart quantity by cart_id
    updateCartQuantity: async (cart_id, quantity) => {
        return await prisma.cart.update({
            where: { cart_id },
            data: { quantity },
        });
    },

    // Delete cart item by cart_id
    deleteCartItemById: async (cart_id) => {
        return await prisma.cart.delete({
            where: { cart_id },
        });
    },
};
