const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.submit_promo_code = async (req, res, next) => {
    try {
        const { code, discount } = req.body;

        if (!/^\d+(\.\d+)?$/.test(discount)) {
            return res.status(400).send({
                success: false,
                error: "Discount value must be a positive number."
            });
        } else if (discount <= 0 || discount > 100) {
            return res.status(400).send({
                success: false,
                error: 'Discount value must be between 1 to 100.'
            });
        }

        // Check if code already exists
        const existingPromo = await prisma.cart_value_discount.findFirst({
            where: { discount_code: code }
        });

        if (existingPromo) {
            return res.status(400).json({
                success: false,
                error: "Promo code already exists"
            });
        }

        // Create new promo code
        const newPromo = await prisma.cart_value_discount.create({
            data: {
                discount_code: code,
                discount_value: discount
            }
        });

        res.status(200).json({
            success: true,
            message: "Promo code added successfully",
            data: newPromo
        });

    } catch (error) {
        console.error("Error adding promo code:", error);
        res.status(500).json({
            success: false,
            error: "Error adding promo code"
        });
    }
};
