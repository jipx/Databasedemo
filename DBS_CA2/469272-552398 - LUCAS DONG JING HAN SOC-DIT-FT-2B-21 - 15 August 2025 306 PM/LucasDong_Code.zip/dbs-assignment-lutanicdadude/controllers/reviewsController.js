const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const reviewsModel = require('../models/reviews');

// add review to database
module.exports.create_review = (req, res, next) => {
    if (!req.body.product_id || !req.body.review || !req.body.rating) {
        return res.status(400).send("product_id, review or rating is missing.");
    }

    const data = {
        member_id: req.member_Id,
        product_id: req.body.product_id,
        review: req.body.review,
        rating: req.body.rating,
        product_name: req.product_name
    };

    const callback = (error, results) => {
        if (error) {
            // console.error("Error in creating review:", error);
            // Send the PostgreSQL error message
            return res.status(500).json({ success: false, message: error.message });
        } else {
            return res.status(200).json({ success: true, message: "Review added successfully" });
        }
    };

    reviewsModel.creating_review(callback, data);
}

// check whether product_id exist in table
module.exports.check_productID = (req, res, next) => {
    if (!req.body.product_id) {
        return res.status(400).send("product_id missing.");
    }

    const data = {
        product_id: req.body.product_id
    };

    const callback = (error, results) => {
        if (error) {
            console.log("Error in checking productID:", error);
            return res.status(500).json({ success: false, message: error.message });
        } else {
            if (results.rowCount === 0) {
                return res.status(400).send({ success: false, message: "Product does not exist" });
            }
            // console.log("result: ", results)
            req.product_name = results.rows[0].name;
            next();
        }
    }
    reviewsModel.checking_productID(callback, data);
}

// retrieve all reviews
module.exports.get_reviews = (req, res, next) => {

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting reivews:", error);
            return res.status(500).json("Error in getting reivews: " + error);
        } else {
            // console.log(results.rows);
            return res.status(200).json(results.rows);
        }
    }
    reviewsModel.getting_Reviews(callback);
}

// update review
module.exports.update_review = (req, res, next) => {
    if (!req.body.rating || !req.body.review_text) {
        return res.status(400).json("rating or review text is missing.");
    }

    const data = {
        review_id: req.review_id,
        rating: req.body.rating,
        review_text: req.body.review_text
    }

    const callback = (error, results) => {
        if (error) {
            console.log("Error in updating review:", error);
            return res.status(500).json({ success: false, message: "Failed to update review" });
        } else {
            console.log("review updated successfully");
            return res.status(200).json({ success: true, message: "Review updated successfully" });
        }
    }
    reviewsModel.updating_Reviews(callback, data);
}

// delete review
module.exports.delete_review = (req, res, next) => {

    const data = {
        review_id: req.review_id
    }

    const callback = (error, results) => {
        if (error) {
            console.log("Error in deleting review:", error);
            return res.status(500).json({ success: false, message: "Failed to delete review" });
        } else {
            console.log("review deleted successfully");
            return res.status(200).json({ success: true, message: "Review deleted successfully" });
        }
    }
    reviewsModel.deleting_Reviews(callback, data);
}

// check if review exist
module.exports.check_ReviewsID = (req, res, next) => {
    if (!req.body.review_id) {
        return res.status(400).json("review_id is missing.");
    }

    const data = {
        review_id: parseInt(req.body.review_id, 10)
    };

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting reviews:", error);
            return res.status(500).json({ success: false, message: error.message });
        }
        if (results.rowCount === 0) {
            return res.status(400).json({ success: false, message: "Review does not exist" });
        }
        req.review_id = data.review_id;  // use the parsed integer here
        next();
    };
    reviewsModel.checking_Reviews(callback, data);
};

module.exports.get_Reviews_By_ProductId = async (req, res) => {
    if (!req.query.productId) {
        return res.status(400).json({ error: 'Missing product_id in URL' });
    }

    const data = {
        product_id: req.query.productId
    }

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting reviews:", error);
            return res.status(500).json({ success: false, message: error.message });
        }
        if (results.rowCount === 0) {
            return res.status(400).json({ success: false, message: "Review does not exist" });
        }
        // console.log("result: ", results);
        return res.status(200).json(results);
    };
    reviewsModel.getting_Reviews_By_ProductId(callback, data);
};