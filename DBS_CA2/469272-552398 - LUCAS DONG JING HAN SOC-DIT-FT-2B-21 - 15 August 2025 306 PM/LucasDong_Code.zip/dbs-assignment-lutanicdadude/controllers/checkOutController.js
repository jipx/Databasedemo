const checkOutModel = require('../models/checkOut');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

module.exports.checkPromoCode = async (req, res, next) => {
    try {
        const promoCode = req.body.promoCode;
        const results = await prisma.cart_value_discount.findMany({
            where: { discount_code: promoCode }
        });

        if (results.length === 0) {
            return res.status(400).send("Promotional Code is invalid");
        }
        return res.status(200).json({ data: results });
    } catch (error) {
        console.error("Error in checking promo Code:", error);
        return res.status(400).send("Promotional code is invalid");
    }
};

module.exports.checkCartForOrder = async (req, res, next) => {
    try {
        const memberId = req.body.memberId;
        const results = await prisma.cart.findMany({
            where: { member_id: memberId }
        });

        if (!results || results.length === 0) {
            return res.status(400).send("There is no order ready.");
        }
        next();
    } catch (error) {
        console.error("Error in checking order in cart:", error);
        return res.status(400).send("There is no order ready.");
    }
};

module.exports.submitCheckOut = async (req, res, next) => {
    const { memberId, username, email, shippingAddress, paymentMethod } = req.body;

    if (!username || !email || !shippingAddress || !paymentMethod) {
        return res.status(400).send("Please fill out all credentials.");
    }

    try {
        await checkOutModel.submit_check_out({
            memberId,
            username,
            email,
            shippingAddress,
            paymentMethod
        });
        return res.status(200).json({ message: "Order has been sent!" });
    } catch (error) {
        console.error("Error in submitting Check Out request:", error);
        return res.status(400).json({ error: "Error in submitting Check Out request." });
    }
};