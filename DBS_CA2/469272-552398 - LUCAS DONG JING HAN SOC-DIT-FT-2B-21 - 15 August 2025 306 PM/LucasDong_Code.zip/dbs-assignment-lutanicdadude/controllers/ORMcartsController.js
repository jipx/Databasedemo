const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.createCartItems = async (req, res) => {
    if (!req.body.quantity) {
        return res.status(400).send("quantity is missing.");
    }

    const quantity = parseInt(req.body.quantity, 10);
    const productId = parseInt(req.body.product_id, 10);

    try {
        const product = await prisma.product.findUnique({
            where: { id: productId }
        });

        if (!product) {
            return res.status(404).json({ success: false, message: "Product not found." });
        }

        if (quantity > product.stock_quantity) {
            return res.status(400).json({
                success: false,
                message: `Not enough stock. (Stock left = ${product.stock_quantity})`
            });
        }

        await prisma.cart.create({
            data: {
                member_id: parseInt(req.member_Id, 10),
                product_id: productId,
                quantity: quantity
            }
        });

        res.status(200).json({ success: true, message: "Item added successfully to cart" });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ success: false, message: "Error in creating cart" });
    }
};

exports.updateCartItems = async (req, res) => {
    try {
        const memberId = parseInt(req.member_Id, 10);
        const productId = parseInt(req.body.product_id, 10);
        const quantity = parseInt(req.body.quantity, 10);

        const product = await prisma.product.findUnique({
            where: { id: productId }
        });

        if (!product) {
            return res.status(404).json({ success: false, message: "Product not found." });
        }

        if (quantity > product.stock_quantity) {
            return res.status(400).json({
                success: false,
                message: `Not enough stock. (Stock left = ${product.stock_quantity})`
            });
        }

        const cartItem = await prisma.cart.findFirst({
            where: { member_id: memberId, product_id: productId }
        });

        if (!cartItem) {
            return res.status(404).json({ success: false, message: "Cart item not found." });
        }

        await prisma.cart.update({
            where: { cart_id: cartItem.cart_id },
            data: { quantity: quantity }
        });

        res.status(200).json({ success: true, message: "Item updated successfully in cart" });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ success: false, message: "Error in updating cart" });
    }
};

exports.retrieveCartItems = async (req, res) => {
    try {
        const memberId = parseInt(req.member_Id, 10);

        const items = await prisma.cart.findMany({
            where: { member_id: memberId },
            select: {
                member_id: true,
                product_id: true,
                quantity: true,
                product: {
                    select: {
                        description: true,
                        country: true,
                        unit_price: true,
                        name: true
                    }
                }
            }
        });

        res.status(200).json(items);
    } catch (error) {
        console.log("Error in getting cart:", error);
        res.status(500).json("Error in getting cart: " + error);
    }
};

exports.deleteCartItems = async (req, res) => {
    try {
        const memberId = parseInt(req.member_Id, 10);
        const productId = parseInt(req.body.product_id, 10);

        const cartItem = await prisma.cart.findFirst({
            where: { member_id: memberId, product_id: productId }
        });

        if (!cartItem) {
            return res.status(404).json({ success: false, message: "Cart item not found." });
        }

        await prisma.cart.delete({
            where: { cart_id: cartItem.cart_id }
        });

        res.status(200).json({ success: true, message: "Item deleted successfully in cart" });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ success: false, message: "Error in deleting items in cart" });
    }
};

exports.getCartSummary = async (req, res) => {
    try {
        const memberId = parseInt(req.member_Id, 10);

        const items = await prisma.cart.findMany({
            where: { member_id: memberId },
            select: {
                cart_id: true,
                member_id: true,
                product_id: true,
                quantity: true,
                product: {
                    select: { unit_price: true }
                }
            }
        });

        res.status(200).json(items);
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json("Error in getting cart: " + error);
    }
};

exports.checkProduct_id = async (req, res, next) => {
    if (!req.body.product_id) {
        return res.status(400).send("product_id missing.");
    }

    try {
        const productId = parseInt(req.body.product_id, 10);

        const product = await prisma.product.findUnique({
            where: { id: productId }
        });

        if (!product) {
            return res.status(400).json({ success: false, message: "Product does not exist" });
        }

        req.product_id = productId;
        next();
    } catch (error) {
        console.log("Error:", error);
        return res.status(500).json({ success: false, message: "Product check failed" });
    }
};

exports.check_cart_table = async (req, res, next) => {
    try {
        const memberId = parseInt(req.member_Id, 10);
        const productId = parseInt(req.body.product_id, 10);

        const cartItem = await prisma.cart.findFirst({
            where: { member_id: memberId, product_id: productId }
        });

        if (!cartItem) {
            next();
        } else {
            return res.status(400).json({ success: false, message: "Product already in cart" });
        }
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ success: false, message: "Error checking cart" });
    }
};
