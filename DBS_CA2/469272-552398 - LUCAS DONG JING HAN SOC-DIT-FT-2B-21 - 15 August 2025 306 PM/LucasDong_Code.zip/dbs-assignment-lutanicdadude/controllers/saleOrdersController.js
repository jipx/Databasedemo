const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const saleOrdersModel = require('../models/saleOrders');
const membersModel = require('../models/members');

module.exports.retrieveAll = function (req, res) {
    let memberId = req.user.memberId;

    membersModel
        .isAdmin(memberId)
        .then(function (isAdmin) {
            if (isAdmin) {
                memberId = null;
            }

            return saleOrdersModel.retrieveAll(memberId);
        })
        .then(function (saleOrders) {
            return res.json({ saleOrders: saleOrders });
        })
        .catch(function (error) {
            console.error(error);
            if (error instanceof EMPTY_RESULT_ERROR) {
                return res.status(404).json({ error: error.message });
            }
            return res.status(500).json({ error: error.message });
        });

}

module.exports.getAllSaleOrderTable = function (req, res) {
    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting sale order table:", error);
            return res.status(500).json("Error in getting sale order table");
        } else if (results.rows === 0) {
            return res.status(400).json("Unable to find any data");
        }
        console.log("result: ", results.rows);
        return res.status(200).json(results.rows);
    };
    saleOrdersModel.gettingAllSaleOrderTable(callback);
}

module.exports.getLargestNumberOfOrders = function (req, res) {
    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting sale order table:", error);
            return res.status(500).json("Error in getting sale order table");
        } else if (results.rows === 0) {
            return res.status(400).json("Unable to find any data");
        }
        console.log("result: ", results.rows);
        return res.status(200).json(results.rows);
    };
    saleOrdersModel.gettingLargestNumberOfOrders(callback);
}

module.exports.getSaleOrderTable = function (req, res) {

    if (!req.body.gender || !req.body.totalSpending || !req.body.memberTotalSpending || !req.body.age) {
        return res.status(400).json("Missing gender, totalSpending, memberTotalSpending or age");
    }

    const data = {
        gender: req.body.gender,
        totalSpending: req.body.totalSpending,
        memberTotalSpending: req.body.memberTotalSpending,
        age: req.body.age,
        productType: req.body.productType
    }

    const callback = (error, results) => {
        if (error) {
            console.log("Error in getting sale order table:", error);
            return res.status(500).json("Error in getting sale order table");
        } else if (results.rows === 0) {
            return res.status(400).json("Unable to find any data");
        }
        console.log("result: ", results.rows);
        return res.status(200).json(results.rows);
    };
    saleOrdersModel.gettingSaleOrderTable(callback, data);
};
