// SUBMISSION
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem("token");
    const cartProductId = localStorage.getItem("cartProductId");

    const productIdInput = document.querySelector("input[name='productId']");
    productIdInput.value = cartProductId;

    // Add an event listener to the form with ID 'cartForm' to handle its submission
    document.getElementById('cartForm').addEventListener('submit', async function (e) {
        // Prevent the form from submitting the traditional way (which reloads the page)
        e.preventDefault();

        // Get the values entered by the user in the form fields
        const product_id = productIdInput.value;
        const quantity = document.getElementById('quantity').value;
        console.log(typeof (cartProductId));

        try {
            // Send a POST request to the backend API to add the review
            const response = await fetch('/carts/add_cart_item', {
                method: 'POST', // Use the POST HTTP method
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json' // Send data in JSON format
                },
                body: JSON.stringify({ product_id, quantity }) // Convert data to JSON string
            });

            // Wait for the server's response and parse it as JSON
            const result = await response.json();
            // console.log("wanted error: ", result);
            // result should have success and message properties
            showCartStatus(result.success, result.message);

            document.getElementById('okBtn').addEventListener('click', closeModal);
            // add click listener and when you click the function will run
            window.addEventListener('click', function (e) {
                // check if the user clicked on the background overlay of the model
                if (e.target.id === 'cartModal') {
                    closeModal()
                };
            });


        } catch (err) {
            // Log any network or runtime errors in the browser console
            console.error('Error submitting item to cart:', err);
        }
    });

});

// MODAL
function showCartStatus(success, message) {
    const modal = document.getElementById('cartModal');
    const modalMessage = document.getElementById('modalMessage');

    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Item added!" : "Item unable to be added.");

    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('cartModal');
    modal.style.display = 'none';
}