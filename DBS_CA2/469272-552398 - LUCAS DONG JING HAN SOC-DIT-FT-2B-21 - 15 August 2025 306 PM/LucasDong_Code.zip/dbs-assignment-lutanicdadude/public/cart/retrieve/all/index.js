window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");

    const checkoutButton = document.getElementById("checkout-button");
    checkoutButton.addEventListener("click", function () {
        window.location.href = "/checkout";
    });

    fetchCartItems(token)
        .then(function () {
            return fetchCartSummary(token);
        });
});

function fetchCartItems(token) {
    return fetch('/carts', {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (body) {
            if (body.error) throw new Error(body.error);
            const cartItems = body;
            console.log("cartItems: ", cartItems);
            const tbody = document.querySelector("#cart-items-tbody");
            cartItems.forEach(function (cartItem) {
                const row = document.createElement("tr");
                row.classList.add("product");
                const descriptionCell = document.createElement("td");
                const countryCell = document.createElement("td");
                const quantityCell = document.createElement("td");
                const unitPriceCell = document.createElement("td");
                const subTotalCell = document.createElement("td");
                const updateButtonCell = document.createElement("td");
                const deleteButtonCell = document.createElement("td");
                const updateButton = document.createElement("button");
                const deleteButton = document.createElement("button");

                descriptionCell.textContent = cartItem.product.description;
                countryCell.textContent = cartItem.product.country;
                unitPriceCell.textContent = cartItem.product.unit_price;
                updateButtonCell.appendChild(updateButton);
                deleteButtonCell.appendChild(deleteButton);

                // Make quantityCell an editable input field
                const quantityInput = document.createElement("input");
                quantityInput.type = "number";
                quantityInput.value = cartItem.quantity;
                quantityInput.addEventListener("input", function () {
                    // Only allow numeric values
                    this.value = this.value.replace(/[^1-9]/g, "");
                });
                quantityCell.appendChild(quantityInput);
                subTotalCell.textContent = cartItem.product.unit_price * cartItem.quantity;

                updateButton.textContent = "Update";
                deleteButton.textContent = "Delete";

                // Add event listener to updateButton
                updateButton.addEventListener("click", function () {
                    let updatedQuantity = parseInt(quantityInput.value);
                    const updatedCartItem = {
                        quantity: Number(updatedQuantity),
                        product_id: cartItem.product_id
                    };

                    fetch('/carts', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            Authorization: `Bearer ${token}`
                        },
                        body: JSON.stringify(updatedCartItem)
                    })
                        .then(function (response) {
                            return response.json();
                        })
                        .then(function (result) {
                            // console.log("wanted error: ", result);
                            // result should have success and message properties
                            showReviewStatus(result.success, result.message);

                            document.getElementById('okBtn').addEventListener('click', closeModal);
                            // add click listener and when you click the function will run
                            window.addEventListener('click', function (e) {
                                // check if the user clicked on the background overlay of the model
                                if (e.target.id === 'cartModal') {
                                    closeModal();
                                };
                                location.reload();
                            });
                        })
                        .catch(function (error) {
                            console.error(error);
                        });

                    document.getElementById('okBtn').addEventListener('click', closeModal);
                });

                // Add event listener to deleteButton
                deleteButton.addEventListener("click", function () {
                    const deleteCartItem = {
                        product_id: cartItem.product_id // Add the missing value for 'productId'
                    };

                    fetch('/carts', {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            Authorization: `Bearer ${token}`
                        },
                        body: JSON.stringify(deleteCartItem)
                    })
                        .then(function (response) {
                            return response.json();
                        })
                        .then(function (result) {
                            // console.log("wanted error: ", result);
                            // result should have success and message properties
                            showReviewStatus(result.success, result.message);

                            document.getElementById('okBtn').addEventListener('click', closeModal);
                            // add click listener and when you click the function will run
                            window.addEventListener('click', function (e) {
                                // check if the user clicked on the background overlay of the model
                                if (e.target.id === 'cartModal') {
                                    closeModal();
                                };
                                location.reload();
                            });
                        })
                        .catch(function (error) {
                            console.error(error);
                        });
                });

                row.appendChild(descriptionCell);
                row.appendChild(countryCell);
                row.appendChild(subTotalCell);
                row.appendChild(unitPriceCell);
                row.appendChild(quantityCell);
                row.appendChild(updateButtonCell);
                row.appendChild(deleteButtonCell);

                tbody.appendChild(row);
            });
        })
        .catch(function (error) {
            console.error(error);
        });
}

function fetchCartSummary(token) {
    return fetch('/carts/summary', {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (body) {
            if (body.error) throw new Error(body.error);
            const cartSummary = body;

            let totalquantity = 0;
            let totalprice = 0;

            cartSummary.forEach(cartItem => {
                totalquantity += cartItem.quantity;
                totalprice += (cartItem.quantity * cartItem.product.unit_price);
            })

            const cartSummaryDiv = document.querySelector("#cart-summary");
            const cartSummaryLabel1 = document.createElement("label");
            cartSummaryLabel1.textContent = "Total Quantity: ";
            cartSummaryLabel1.classList.add("label");
            const cartSummaryValue1 = document.createElement("span");
            cartSummaryValue1.textContent = totalquantity;
            cartSummaryValue1.classList.add("value");
            const cartSummaryLabel2 = document.createElement("label");
            cartSummaryLabel2.textContent = "Total Checkout Price: ";
            cartSummaryLabel2.classList.add("label");
            const cartSummaryValue2 = document.createElement("span");
            cartSummaryValue2.textContent = totalprice;
            cartSummaryValue2.classList.add("value");

            cartSummaryDiv.appendChild(cartSummaryLabel1);
            cartSummaryDiv.appendChild(cartSummaryValue1);
            cartSummaryDiv.appendChild(document.createElement("br"));
            cartSummaryDiv.appendChild(cartSummaryLabel2);
            cartSummaryDiv.appendChild(cartSummaryValue2);
        })
        .catch(function (error) {
            console.error(error);
        });
}


document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('discount-modal');
    const btn = document.getElementById('discount-button');
    const closeBtn = modal.querySelector('.close');

    // Open modal
    btn.addEventListener('click', () => {
        modal.style.display = 'block';
    });

    // Close modal when clicking X
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Close modal when clicking outside the content
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
});

// MODAL
function showReviewStatus(success, message) {
    const modal = document.getElementById('cartModal');
    const modalMessage = document.getElementById('modalMessage');

    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Cart item deleted or updated!" : "Cart unable to be deleted or updated.");

    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('cartModal');
    modal.style.display = 'none';
}