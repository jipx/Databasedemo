// you can modify the code 
// you will need to add code to handle the form submission

document.addEventListener('DOMContentLoaded', () => {
    // === Step 1: Pre-fill form with stored reviewId ===
    const token = localStorage.getItem('token');
    const reviewId = localStorage.getItem('reviewId');

    const form = document.getElementById('updateForm');
    form.querySelector('input[name=reviewId]').value = reviewId;

    // === Step 2: Handle form submission ===
    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const review_id = document.getElementById('reviewId').value;
        const rating = parseInt(document.getElementById('rating').value);
        const review_text = document.getElementById('reviewText').value;

        try {
            const response = await fetch('/reviews/update_review', {
                method: 'PUT',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ review_id, rating, review_text })
            });

            const result = await response.json();
            showReviewStatus(result.success, result.message);

            document.getElementById('okBtn').addEventListener('click', closeModal);
            window.addEventListener('click', function (e) {
                if (e.target.id === 'reviewModal') {
                    closeModal();
                }
            });

        } catch (err) {
            console.error('Error submitting review:', err);
        }
    });
});

// MODAL
function showReviewStatus(success, message) {
    const modal = document.getElementById('reviewModal');
    const modalMessage = document.getElementById('modalMessage');

    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Review updated!" : "Review unable to be updated.");

    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('reviewModal');
    modal.style.display = 'none';
}
