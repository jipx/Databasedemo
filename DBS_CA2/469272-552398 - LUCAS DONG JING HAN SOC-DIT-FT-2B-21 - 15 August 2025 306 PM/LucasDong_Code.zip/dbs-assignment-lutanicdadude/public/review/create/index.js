// you can modify the code 
// you will need to add code to handle the form submission
const token = localStorage.getItem("token");
window.addEventListener('DOMContentLoaded', function () {

    fetch('/saleOrders', {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (body) {
            if (body.error) throw new Error(body.error);
            const saleOrders = body.saleOrders;
            const tbody = document.querySelector("#product-tbody");
            saleOrders.forEach(function (saleOrder) {
                const row = document.createElement("tr");
                row.classList.add("product");
                const nameCell = document.createElement("td");
                const descriptionCell = document.createElement("td");
                const unitPriceCell = document.createElement("td");
                const quantityCell = document.createElement("td");
                const countryCell = document.createElement("td");
                const imageUrlCell = document.createElement("td");
                const orderId = document.createElement("td");
                const orderDatetimeCell = document.createElement("td");
                const statusCell = document.createElement("td");
                const createReviewCell = document.createElement("td");

                nameCell.textContent = saleOrder.name;
                descriptionCell.textContent = saleOrder.description;
                unitPriceCell.textContent = saleOrder.unitPrice;
                quantityCell.textContent = saleOrder.quantity;
                countryCell.textContent = saleOrder.country;
                imageUrlCell.innerHTML = `<img src="${saleOrder.imageUrl}" alt="Product Image">`;
                orderId.textContent = saleOrder.saleOrderId;
                orderDatetimeCell.textContent = new Date(saleOrder.orderDatetime).toLocaleString();
                statusCell.textContent = saleOrder.status;
                const viewProductButton = document.createElement("button");
                viewProductButton.textContent = "Create Review";
                viewProductButton.addEventListener('click', function () {
                    const reviewProductSpan = document.querySelector("#review-product-id");
                    reviewProductSpan.innerHTML = saleOrder.name;
                    const productIdInput = document.querySelector("input[name='productId']");
                    productIdInput.value = saleOrder.productId;
                });
                createReviewCell.appendChild(viewProductButton);

                row.appendChild(nameCell);
                row.appendChild(descriptionCell);
                row.appendChild(imageUrlCell);
                row.appendChild(unitPriceCell);
                row.appendChild(quantityCell);
                row.appendChild(countryCell);
                row.appendChild(orderId);
                row.appendChild(orderDatetimeCell);
                row.appendChild(statusCell);
                row.appendChild(createReviewCell);
                tbody.appendChild(row);
            });
        })
        .catch(function (error) {
            console.error(error);
        });
});


// SUBMISSION
document.addEventListener('DOMContentLoaded', () => {
    // Add an event listener to the form with ID 'reviewForm' to handle its submission
    document.getElementById('reviewForm').addEventListener('submit', async function (e) {
        // Prevent the form from submitting the traditional way (which reloads the page)
        e.preventDefault();

        // Get the values entered by the user in the form fields
        const product_id = document.getElementById('productId').value;
        const rating = parseInt(document.getElementById('rating').value); // Convert rating to an integer
        const review = document.getElementById('reviewText').value;
        // console.log(product_id, rating, review);

        try {
            // Send a POST request to the backend API to add the review
            const response = await fetch('/reviews/add_review', {
                method: 'POST', // Use the POST HTTP method
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json' // Send data in JSON format
                },
                body: JSON.stringify({ product_id, rating, review }) // Convert data to JSON string
            });

            // Wait for the server's response and parse it as JSON
            const result = await response.json();
            // console.log("wanted error: ", result);
            // result should have success and message properties
            showReviewStatus(result.success, result.message);

            document.getElementById('okBtn').addEventListener('click', closeModal);
            // add click listener and when you click the function will run
            window.addEventListener('click', function (e) {
                // check if the user clicked on the background overlay of the model
                if (e.target.id === 'reviewModal') {
                    closeModal()
                };
            });


        } catch (err) {
            // Log any network or runtime errors in the browser console
            console.error('Error submitting review:', err);
        }
    });

});

// MODAL
function showReviewStatus(success, message) {
    const modal = document.getElementById('reviewModal');
    const modalMessage = document.getElementById('modalMessage');

    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Review added!" : "Review unable to be added.");

    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('reviewModal');
    modal.style.display = 'none';
}