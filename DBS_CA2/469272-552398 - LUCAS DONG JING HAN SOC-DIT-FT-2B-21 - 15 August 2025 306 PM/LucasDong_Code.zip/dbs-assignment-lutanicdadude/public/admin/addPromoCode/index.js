const form = document.getElementById('addPromoForm');
const formMessage = document.getElementById('formMessage');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    let discountValue = parseFloat(document.getElementById('discount').value) / 100

    const promoData = {
        code: document.getElementById('promoCode').value.trim(),
        discount: discountValue
    };

    try {
        const res = await fetch('/promo/submitCode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(promoData)
        });

        const result = await res.json();

        if (res.ok) {
            formMessage.textContent = "Promo code added successfully!";
            formMessage.classList.remove('error-message');
            formMessage.classList.add('success-message');
            form.reset();
        } else {
            formMessage.textContent = `Error: ${result.error}`;
            formMessage.classList.remove('success-message');
            formMessage.classList.add('error-message');
        }


    } catch (err) {
        formMessage.textContent = `Error: ${err.message}`;
        formMessage.classList.remove('success-message');
        formMessage.classList.add('error-message');
    }

});
