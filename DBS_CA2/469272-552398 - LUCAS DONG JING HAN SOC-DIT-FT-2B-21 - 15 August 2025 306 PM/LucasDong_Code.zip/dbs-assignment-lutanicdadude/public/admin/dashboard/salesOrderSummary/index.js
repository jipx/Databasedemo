window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");
    const form = document.querySelector("form");
    const highestBtn = document.getElementById("highestTotalSpendingBtn");
    const largestNumberOfOrders = document.getElementById("largestNumberOfOrders");

    form.addEventListener("submit", handleFormSubmission);
    highestBtn.addEventListener("click", fetchHighestTotalSpender);
    largestNumberOfOrders.addEventListener("click", fetchLargestNumberOfOrders);

    function fetchHighestTotalSpender() {
        fetch(`/saleOrders/getAllSaleOrderTable`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        })
            .then(res => res.json())
            .then(body => {
                if (!Array.isArray(body)) throw new Error("Unexpected response");

                const tableBody = document.querySelector("#returnTable tbody");
                tableBody.innerHTML = ""; // Clear previous data

                body.forEach(data => {
                    const row = document.createElement("tr");
                    row.innerHTML = `
                    <td>${data.ageGroup}</td>
                    <td>${data.totalSpending}</td>
                    <td>1</td>
                `;
                    tableBody.appendChild(row);
                });
            })
            .catch(err => {
                console.error("Failed to fetch highest spender:", err);
            });
    }

    function fetchLargestNumberOfOrders() {
        fetch('/saleOrders/getLargestNumberOfOrders', {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        })
            .then(res => res.json())
            .then(body => {
                if (!Array.isArray(body)) throw new Error("Unexpected response");

                const tableBody = document.querySelector("#returnTable tbody");
                tableBody.innerHTML = ""; // Clear previous data

                // Create a new table header row with desired columns
                const tableHead = document.querySelector("#returnTable thead");
                tableHead.innerHTML = `
            <tr>
                <th>Sale Order ID</th>
                <th>Product Name</th>
                <th>Total Quantity</th>
            </tr>
        `;

                // Fill rows with fetched data
                body.forEach(data => {
                    const row = document.createElement("tr");
                    row.innerHTML = `
                <td>${data.saleOrderId}</td>
                <td>${data.productName}</td>
                <td>${data.totalQuantity}</td>
            `;
                    tableBody.appendChild(row);
                });
            })
            .catch(err => {
                console.error("Failed to fetch largest number of orders:", err);
            });
    }


    function fetchSalesOrderSummary(userInput) {
        fetch(`/saleOrders/getSaleOrderTable`, {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(userInput)
        })
            .then(response => response.json())
            .then(body => {
                if (body.error) throw new Error(body.error);
                const tableBody = document.querySelector("#returnTable tbody");
                tableBody.innerHTML = "";

                const ageGroupMap = {
                    18: "Less than 18",
                    29: "18-29",
                    39: "30-39",
                    49: "40-49",
                    59: "50-59",
                    60: "More than 60"
                };
                const ageGroupLabel = ageGroupMap[userInput.age] || "Unknown";

                const row = document.createElement("tr");
                row.innerHTML = `
                <td>${ageGroupLabel}</td>
                <td>${getTotal(body)}</td>
                <td>${body.length}</td>
            `;
                tableBody.appendChild(row);
            })
            .catch(error => {
                console.error(error);
            });
    }

    function handleFormSubmission(event) {
        event.preventDefault();

        const gender = document.querySelector("input[name='gender']:checked").value;
        const minTotal = document.getElementById("minTotal").value;
        const minMemberTotal = document.getElementById("minMemberTotal").value;
        const ageGroup = document.getElementById("ageGroup").value;
        const productType = document.getElementById("productType").value;

        const inputFromUser = {
            gender,
            totalSpending: parseInt(minTotal),
            memberTotalSpending: parseInt(minMemberTotal),
            age: parseInt(ageGroup),
            productType
        };

        fetchSalesOrderSummary(inputFromUser);
    }

    function getTotal(arr) {
        return arr.reduce((sum, obj) => sum + parseFloat(obj.totalSpending), 0);
    }
});
