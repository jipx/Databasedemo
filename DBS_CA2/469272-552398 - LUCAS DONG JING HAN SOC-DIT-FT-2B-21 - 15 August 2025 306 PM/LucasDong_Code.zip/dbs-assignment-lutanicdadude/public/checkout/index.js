document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    let products = [];
    let totalPrice = 0;
    let quantityDiscount = 0;
    let summaryEl;

    const decoded = decodeToken(token);
    const memberId = decoded.memberId;
    const username = decoded.username;
    document.getElementById('fullname').value = username;

    // Promo code button handler
    document.getElementById('checkPromoCode').onclick = async () => {
        const promoCode = document.getElementById("promoCode").value;
        try {
            const response = await fetch('/checkout/checkPromo', {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ promoCode })
            });

            if (!response.ok) {
                const errorText = await response.text();
                showPromoStatus(false, errorText || 'Check failed.'); // use promo modal
            } else {
                closePromoModal(); // close promo modal if open
                const result = await response.json();
                const promoDiscount = totalPrice * result.data[0].discount_value; // promo code discount

                // Add promo discount on top of quantity discount
                summaryEl.discount = quantityDiscount + promoDiscount;
                summaryEl.render();

                showPromoStatus(true, `Promo applied: -$${promoDiscount.toFixed(2)}`); // feedback

            }
        } catch (err) {
            console.log(err);
            showPromoStatus(false, err.message || 'An unexpected error occurred.');
        }
    };

    async function retrieveCart() {
        let totalQuantity = 0;
        try {
            const response = await fetch('/carts/', {
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            const result = await response.json();
            result.forEach(item => {
                const price = item.product.unit_price * item.quantity;
                products.push({
                    name: item.product.name,
                    amount: item.quantity,
                    price: price
                });
                totalPrice += price;
                totalQuantity += item.quantity;
            });

            quantityDiscount = getQuantityDiscount(totalQuantity, totalPrice);
            class CheckoutSummary extends HTMLElement {
                constructor() {
                    super();
                    this.attachShadow({ mode: 'open' });
                    this.products = [];
                    this.shipping = 0;
                    this.discount = 0;
                }

                render() {
                    const style = `
                        .checkout-summary {
                            font-family: sans-serif;
                            padding: 1rem;
                            border: 1px solid #ccc;
                            border-radius: 10px;
                            width: 965px;
                            background-color: #fafafa;
                        }
                        .summary-item, .total {
                            display: flex;
                            justify-content: space-between;
                            margin: 8px 0;
                        }
                        .product-row {
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                        }
                        .product-name {
                            flex: 1;
                            font-weight: 500;
                        }
                        .product-qty {
                            flex: 0 0 80px;
                            text-align: center;
                            color: #555;
                        }
                        .product-price {
                            flex: 0 0 100px;
                            text-align: right;
                            font-weight: 500;
                        }
                        .total {
                            font-weight: bold;
                            font-size: 1.2em;
                            border-top: 1px solid #ccc;
                            padding-top: 10px;
                        }
                        .checkout-btn {
                            margin-top: 10px;
                            width: 100%;
                            padding: 10px;
                            background-color: #007bff;
                            color: white;
                            border: none;
                            border-radius: 6px;
                            cursor: pointer;
                        }
                    `;

                    console.log("this.discount: ", this.discount)
                    const discountLine = this.discount > 0
                        ? `<div class="summary-item">
                                <span>Discount</span>
                                <span>–$${this.discount.toFixed(2)}</span>
                           </div>`
                        : '';

                    const productHTML = this.products.map(
                        (p) => `
                            <div class="summary-item product-row">
                                <span class="product-name">${p.name}</span>
                                <span class="product-qty">Qty: ${p.amount}</span>
                                <span class="product-price">$${p.price.toFixed(2)}</span>
                            </div>
                        `
                    ).join('');

                    this.shadowRoot.innerHTML = `
                        <style>${style}</style>
                        <div class="checkout-summary">
                            <h2>Order Summary</h2>
                            <h3>Products Ordered</h3>
                            ${productHTML}
                            <div class="summary-item">
                                <span>Shipping</span>
                                <span>$${this.shipping.toFixed(2)}</span>
                            </div>
                            ${discountLine}
                            <div class="total">
                                <span>Total</span>
                                <span>$${(totalPrice + this.shipping - this.discount).toFixed(2)}</span>
                            </div>
                            <button class="checkout-btn">Complete Purchase</button>
                        </div>
                    `;

                    this.shadowRoot.querySelector('.checkout-btn').onclick = async () => {
                        const email = document.getElementById("email").value;
                        const shippingAddress = document.getElementById("address").value;
                        const paymentMethod = document.getElementById("payment").value;

                        try {
                            const response = await fetch('/checkOut/submitCart', {
                                method: 'POST',
                                headers: {
                                    Authorization: `Bearer ${token}`,
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ memberId, username, email, shippingAddress, paymentMethod })
                            });

                            if (!response.ok) {
                                const errorText = await response.text();
                                showOrderStatus(false, errorText || 'Checkout failed.');
                            } else {
                                await response.json();
                                showOrderStatus(true, 'Checkout Successful.');
                            }
                        } catch (err) {
                            showOrderStatus(false, err.message || 'An unexpected error occurred.');
                        }
                    };
                }
            }

            if (!customElements.get('checkout-summary')) {
                customElements.define('checkout-summary', CheckoutSummary);
            }

            summaryEl = document.querySelector('checkout-summary');
            summaryEl.products = products;
            summaryEl.shipping = 5.00;
            summaryEl.discount = quantityDiscount;
            summaryEl.render();
        } catch (err) {
            console.error('Error retrieving cart:', err);
        }
    }

    retrieveCart();
});

function decodeToken(token) {
    if (!token) return null;
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        return JSON.parse(atob(base64));
    } catch (e) {
        console.error('Invalid token:', e);
        return null;
    }
}

// Separate modal functions
function showOrderStatus(success, message) {
    const modal = document.getElementById('checkout-container');
    const modalMessage = document.getElementById('modalMessage');
    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message || (success ? "Order Sent!" : "Order unable to be sent.");
    modal.style.display = 'block';
}

function showPromoStatus(success, message) {
    const modal = document.getElementById('promo-modal');
    const modalMessage = document.getElementById('promo-modal-message');
    modalMessage.classList.remove('success', 'error');
    modalMessage.classList.add(success ? 'success' : 'error');
    modalMessage.textContent = message;
    modal.style.display = 'block';
}

function closePromoModal() {
    const modal = document.getElementById('promo-modal');
    if (modal) modal.style.display = 'none';
}

function closeModal() {
    const modal = document.getElementById('checkout-container');
    if (modal) modal.style.display = 'none';
}

function getQuantityDiscount(totalQuantity, totalPrice) {
    let discountPercent = 0;

    if (totalQuantity >= 5) {
        discountPercent = 0.15; // 15% off for 5 or more items
    } else if (totalQuantity >= 3) {
        discountPercent = 0.10; // 10% off for 3 or more items
    }

    return totalPrice * discountPercent;
}
