# DBS

# Prerequisite

Before running this project, make sure you have the following installed and set up:

1. **Visual Studio Code (VSCode)** – For editing and running the project files.
2. **PostgreSQL** – The database system used. Make sure it is installed and running.
3. **pgAdmin** – For managing the PostgreSQL database through a GUI (optional but helpful).
4. **Node.js and npm** – Required to run the backend server and install dependencies.
6. **PostgreSQL Database Setup:**
   - Create a database (e.g., `shopping_db`).
   - Set up tables using the provided SQL schema (`shopping_backup.sql` or migration files).

## Setup

1. Clone this repository

2. Create a .env file with the following content

    ```
    DB_USER=
    DB_PASSWORD=
    DB_HOST=
    DB_DATABASE=
    DB_CONNECTION_LIMIT=1
    PORT=3000
    ```

3. Update the .env content with your own database credentials.

4. Install dependencies by running `npm install`

5. Start the app by running `npm start`. Alternatively to use hot reload, start the app by running `npm run dev`.

6. You should see `App listening on port 3000`

8. (Optional) install the plugins recommended in `.vscode/extensions.json`

## Instructions

Open the page, `http://localhost:3000`, replace the port number accordingly if you app is not listening to port 3000

