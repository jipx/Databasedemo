--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-07-03 11:45:21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 268 (class 1255 OID 41390)
-- Name: add_comment(integer, integer, text, timestamp without time zone, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_comment(p_member_id integer, p_product_id integer, p_comment text, p_comment_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP, p_parent_comment_id integer DEFAULT NULL::integer, p_review_id integer DEFAULT NULL::integer) RETURNS TABLE(comment_id integer, member_id integer, product_id integer, comment text, parent_comment_id integer, review_id integer, comment_date timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
	-- Check if member exists
    IF NOT EXISTS (SELECT 1 FROM member WHERE id = p_member_id) THEN
        RAISE EXCEPTION 'Member ID % does not exist', p_member_id;
    END IF;

    RETURN QUERY
    INSERT INTO comments (member_id, product_id, comment, comment_date, parent_comment_id, review_id)
    VALUES (p_member_id, p_product_id, p_comment, p_comment_date, p_parent_comment_id, p_review_id)
    RETURNING comments.comment_id, comments.member_id, comments.product_id, comments.comment, 
	comments.parent_comment_id, comments.review_id, comments.comment_date;
END;
$$;


--
-- TOC entry 270 (class 1255 OID 41431)
-- Name: check_commentid(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_commentid(p_comment_id integer) RETURNS TABLE(comment_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.comment_id
    FROM comments c
    WHERE c.comment_id = p_comment_id;
END;
$$;


--
-- TOC entry 263 (class 1255 OID 41274)
-- Name: checkcart(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.checkcart(p_member_id integer, p_product_id integer) RETURNS TABLE(id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    dummy INT;  -- This declares the variable properly
BEGIN
    RAISE NOTICE 'Checking product with ID: %', p_product_id;

    -- First: Existence check 
    SELECT 1 INTO dummy
    FROM public.cart c
    WHERE c.product_id = p_product_id
      AND c.member_id = p_member_id;

    -- Then return the actual result
    RETURN QUERY
    SELECT c.product_id
    FROM public.cart c
    WHERE c.product_id = p_product_id
      AND c.member_id = p_member_id;
END;
$$;


--
-- TOC entry 236 (class 1255 OID 41094)
-- Name: checkproductid(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.checkproductid(p_product_id integer) RETURNS TABLE(id integer, name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Checking product with ID: %', p_product_id;

    RETURN QUERY
    SELECT p.id, p.name
    FROM public.product p
    WHERE p.id = p_product_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Product with ID % does not exist.', p_product_id;
    END IF;
END;
$$;


--
-- TOC entry 250 (class 1255 OID 41104)
-- Name: checkreview(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.checkreview(p_review_id integer) RETURNS TABLE(review_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Store the query result before returning
    RETURN QUERY
    SELECT r.review_id
    FROM review r
    WHERE r.review_id = p_review_id;

    -- This works *only if* RETURN QUERY does NOT exit early
    IF NOT FOUND THEN
        RAISE EXCEPTION 'No reviews found for review ID %', p_review_id;
    END IF;
END;
$$;


--
-- TOC entry 253 (class 1255 OID 41133)
-- Name: create_cart(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_cart(IN p_product_id integer, IN p_quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

    -- Insert review
    INSERT INTO cart (product_id, quantity)
    VALUES (p_product_id, p_quantity);
END;
$$;


--
-- TOC entry 258 (class 1255 OID 41146)
-- Name: create_cart(integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_cart(IN p_member_id integer, IN p_product_id integer, IN p_quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

	    -- Validate rating range
    IF p_quantity <= 0 THEN
        RAISE EXCEPTION 'Quantity must be more than 1.';
    END IF;

    -- Insert review
    INSERT INTO cart (member_id, product_id, quantity)
    VALUES (p_member_id, p_product_id, p_quantity);
END;
$$;


--
-- TOC entry 278 (class 1255 OID 41484)
-- Name: create_comment(integer, character varying, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_comment(p_product_id integer, p_comment character varying, p_comment_date timestamp without time zone) RETURNS TABLE(product_id integer, comment character varying, comment_date timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

    -- Insert the new comment
    INSERT INTO comment (product_id, comment, comment_date)
    VALUES (p_product_id, p_comment, p_comment_date);

    -- Return the inserted row
    RETURN QUERY
    SELECT p_product_id, p_comment, p_comment_date;
END;
$$;


--
-- TOC entry 279 (class 1255 OID 41490)
-- Name: create_comment(integer, integer, character varying, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_comment(p_member_id integer, p_product_id integer, p_comment character varying, p_comment_date timestamp without time zone) RETURNS TABLE(member_id integer, product_id integer, comment character varying, comment_date timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

    -- Validate member_id exists
    IF NOT EXISTS (SELECT 1 FROM member WHERE id = p_member_id) THEN
        RAISE EXCEPTION 'Invalid member_id: Member does not exist.';
    END IF;

    -- Insert the new comment
    INSERT INTO comments (member_id, product_id, comment, comment_date)
    VALUES (p_member_id, p_product_id, p_comment, p_comment_date);

    -- Return the inserted row
    RETURN QUERY
    SELECT p_member_id, p_product_id, p_comment, p_comment_date;
END;
$$;


--
-- TOC entry 277 (class 1255 OID 41480)
-- Name: create_review(integer, integer, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_review(IN p_member_id integer, IN p_product_id integer, IN p_review character varying, IN p_rating integer, IN p_product_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

	-- Validate member_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM member WHERE id = p_member_id) THEN
        RAISE EXCEPTION 'Invalid member_id: Member does not exist.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Insert review
    INSERT INTO review (member_id, product_id, review_text, rating, last_update, product_name)
    VALUES (p_member_id, p_product_id, p_review, p_rating, CURRENT_TIMESTAMP, p_product_name);
END;
$$;


--
-- TOC entry 252 (class 1255 OID 41124)
-- Name: create_sale_order_item(integer, integer, numeric); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_sale_order_item(IN p_sale_order_id integer, IN p_product_id integer, IN p_quantity numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

    -- Insert review
    INSERT INTO sale_order_item (sale_order_id, product_id, quantity)
    VALUES (p_sale_order_id, p_product_id, p_quantity);
END;
$$;


--
-- TOC entry 254 (class 1255 OID 41091)
-- Name: createreview(integer, integer, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.createreview(IN p_member_id integer, IN p_product_id integer, IN p_review character varying, IN p_rating integer, IN p_product_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Validate product_id exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM product WHERE id = p_product_id) THEN
        RAISE EXCEPTION 'Invalid product_id: Product does not exist.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Insert review
    INSERT INTO review (member_id, product_id, review_text, rating, last_update, product_name)
    VALUES (p_member_id, p_product_id, p_review, p_rating, CURRENT_TIMESTAMP, p_product_name);
END;
$$;


--
-- TOC entry 262 (class 1255 OID 41267)
-- Name: delete_cart_item(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_cart_item(IN p_member_id integer, IN p_product_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if the cart item exists
    IF NOT EXISTS (
        SELECT 1
        FROM cart
        WHERE member_id = p_member_id
        AND product_id = p_product_id
    ) THEN
        RAISE EXCEPTION 'Cart item not found.';
    END IF;

    -- Delete the cart item
    DELETE FROM cart
    WHERE member_id = p_member_id
    AND product_id = p_product_id;
END;
$$;


--
-- TOC entry 269 (class 1255 OID 41430)
-- Name: delete_comment(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_comment(p_comment_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM comments WHERE comment_id = p_comment_id) THEN
        DELETE FROM comments WHERE comment_id = p_comment_id;
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;

    RETURN FALSE;  -- just in case
END;
$$;


--
-- TOC entry 256 (class 1255 OID 41111)
-- Name: delete_review(integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.delete_review(IN p_review_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
    IF NOT EXISTS (SELECT 1 FROM review WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Delete the review
    DELETE FROM review WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 251 (class 1255 OID 41071)
-- Name: deletereview(integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.deletereview(IN p_review_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
    IF NOT EXISTS (SELECT 1 FROM review WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Delete the review
    DELETE FROM review WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 272 (class 1255 OID 41451)
-- Name: get_all_sale_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_all_sale_order() RETURNS TABLE(member_id integer, gender character, total_spending numeric, age numeric, age_group text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id AS member_id,
        m.gender,
        SUM(soi.quantity * p.unit_price)::NUMERIC AS total_spending,
        EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) AS age,
        CASE 
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) < 18 THEN 'Less than 18'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 18 AND 29 THEN '18-29'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 30 AND 39 THEN '30-39'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 40 AND 49 THEN '40-49'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 50 AND 59 THEN '50-59'
            ELSE '60 and above'
        END AS age_group
    FROM product p 
    JOIN sale_order_item soi ON p.id = soi.product_id 
    JOIN sale_order so ON soi.sale_order_id = so.id
    JOIN member m ON so.member_id = m.id
    GROUP BY m.id, m.gender, EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)
	ORDER BY total_spending DESC;
END;
$$;


--
-- TOC entry 259 (class 1255 OID 41150)
-- Name: get_cart_details_by_member(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_cart_details_by_member(p_member_id integer) RETURNS TABLE(member_id integer, product_id integer, quantity integer, description text, country character varying, unit_price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.member_id,
        c.product_id,
        c.quantity,
        p.description,
        p.country,
        p.unit_price
    FROM cart c
    JOIN product p ON c.product_id = p.id
    WHERE c.member_id = p_member_id;
END;
$$;


--
-- TOC entry 275 (class 1255 OID 41475)
-- Name: get_cart_summary_by_member(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_cart_summary_by_member(p_member_id integer) RETURNS TABLE(totalquantity bigint, totalprice numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
-- Check if the member exists
    IF NOT EXISTS (SELECT 1 FROM member WHERE id = p_member_id) THEN
        RAISE EXCEPTION 'Member ID % does not exist.', p_member_id;
    END IF;
    RETURN QUERY
    SELECT 
        SUM(c.quantity) AS totalQuantity,
        SUM(c.quantity * p.unit_price) AS totalPrice
    FROM cart c
    JOIN product p ON c.product_id = p.id
    WHERE c.member_id = p_member_id;
END;
$$;


--
-- TOC entry 273 (class 1255 OID 41460)
-- Name: get_largest_number_of_orders(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_largest_number_of_orders() RETURNS TABLE(sale_order_id integer, product_name character varying, total_quantity numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
    p.id AS product_id,
    p.name AS product_name,
    SUM(soi.quantity) AS total_quantity
	FROM sale_order_item soi
	JOIN product p ON soi.product_id = p.id
	GROUP BY p.id, p.name
	ORDER BY total_quantity DESC;
END;
$$;


--
-- TOC entry 271 (class 1255 OID 41447)
-- Name: get_sale_order_table(character, numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_order_table(p_gender character, p_totalspending numeric, p_member_totalspending numeric, p_age numeric) RETURNS TABLE(member_id integer, gender character, total_spending numeric, age numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id AS member_id,
        m.gender,
        SUM(soi.quantity * p.unit_price)::NUMERIC AS total_spending,
        EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) AS age
    FROM product p 
    JOIN sale_order_item soi ON p.id = soi.product_id 
    JOIN sale_order so ON soi.sale_order_id = so.id
    JOIN member m ON so.member_id = m.id
    WHERE m.gender = p_gender
      AND (
          (p_age = 18 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) < 18) OR
          (p_age = 29 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) BETWEEN 18 AND 29) OR
          (p_age = 39 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) BETWEEN 30 AND 39) OR
          (p_age = 49 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) BETWEEN 40 AND 49) OR
          (p_age = 59 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) BETWEEN 50 AND 59) OR
          (p_age = 60 AND (EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)) >= 60)
      )
    GROUP BY m.id, m.gender, EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)
    HAVING SUM(soi.quantity * p.unit_price) >= p_member_totalSpending;
END;
$$;


--
-- TOC entry 276 (class 1255 OID 41478)
-- Name: get_sale_order_table(character, double precision, double precision, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_order_table(p_gender character, p_totalspending double precision, p_member_totalspending double precision, p_age integer, p_product_type text DEFAULT NULL::text) RETURNS TABLE(member_id integer, gender character, total_spending numeric, age numeric, age_group text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id AS member_id,
        m.gender,
        SUM(soi.quantity * p.unit_price)::NUMERIC AS total_spending,
        EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) AS age,
        CASE 
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) < 18 THEN 'Less than 18'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 18 AND 29 THEN '18-29'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 30 AND 39 THEN '30-39'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 40 AND 49 THEN '40-49'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 50 AND 59 THEN '50-59'
            ELSE '60 and above'
        END AS age_group
    FROM product p 
    JOIN sale_order_item soi ON p.id = soi.product_id 
    JOIN sale_order so ON soi.sale_order_id = so.id
    JOIN member m ON so.member_id = m.id
    WHERE m.gender = p_gender
      AND (p_product_type IS NULL OR p_product_type = '' OR p.product_type = p_product_type)
    GROUP BY m.id, m.gender, EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)
    HAVING SUM(soi.quantity * p.unit_price) >= p_totalSpending
    ORDER BY total_spending DESC;
END;
$$;


--
-- TOC entry 274 (class 1255 OID 41463)
-- Name: get_sale_orders_by_type(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sale_orders_by_type(p_product_type text) RETURNS TABLE(member_id integer, gender character, total_spending numeric, age numeric, age_group text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id AS member_id,
        m.gender,
        SUM(soi.quantity * p.unit_price)::NUMERIC AS total_spending,
        EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) AS age,
        CASE 
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) < 18 THEN 'Less than 18'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 18 AND 29 THEN '18-29'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 30 AND 39 THEN '30-39'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 40 AND 49 THEN '40-49'
            WHEN EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob) BETWEEN 50 AND 59 THEN '50-59'
            ELSE '60 and above'
        END AS age_group
    FROM product p 
    JOIN sale_order_item soi ON p.id = soi.product_id 
    JOIN sale_order so ON soi.sale_order_id = so.id
    JOIN member m ON so.member_id = m.id
    WHERE p.product_type = p_product_type
    GROUP BY m.id, m.gender, EXTRACT(YEAR FROM NOW()) - EXTRACT(YEAR FROM m.dob)
    ORDER BY total_spending DESC;
END;
$$;


--
-- TOC entry 234 (class 1255 OID 41148)
-- Name: getcart(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcart() RETURNS TABLE(cart_id integer, member_id integer, product_id integer, quantity integer)
    LANGUAGE sql
    AS $$
    SELECT cart_id, member_id, product_id, quantity FROM cart;
$$;


--
-- TOC entry 264 (class 1255 OID 41392)
-- Name: getcomments(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcomments() RETURNS TABLE(comment_id integer, member_id integer, product_id integer, comment text, parent_comment_id integer, review_id integer, comment_date timestamp without time zone)
    LANGUAGE sql
    AS $$
    SELECT comment_id, member_id, product_id, comment, parent_comment_id, review_id, comment_date FROM public.comments;
$$;


--
-- TOC entry 260 (class 1255 OID 41265)
-- Name: getcomments(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcomments(p_product_id integer) RETURNS TABLE(comment_id integer, member_id integer, product_id integer, parent_comment_id integer, comment text, comment_date timestamp without time zone)
    LANGUAGE sql
    AS $$
    SELECT c.comment_id, c.member_id, c.product_id, c.parent_comment_id, c.comment, c.comment_date 
	FROM public.comment c 
	WHERE c.product_id = p_product_id;
$$;


--
-- TOC entry 235 (class 1255 OID 41276)
-- Name: getcommentsbyproduct(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcommentsbyproduct() RETURNS TABLE(comment_id integer, member_id integer, product_id integer, parent_comment_id integer, comment text, comment_date timestamp without time zone)
    LANGUAGE sql
    AS $$
    SELECT comment_id, member_id, product_id, parent_comment_id, comment, comment_date FROM public.comment;
$$;


--
-- TOC entry 265 (class 1255 OID 41396)
-- Name: getcommentsbyproduct(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcommentsbyproduct(p_product_id integer) RETURNS TABLE(comment_id integer, member_id integer, product_id integer, parent_comment_id integer, comment text, comment_date timestamp without time zone, review_id integer, username character varying)
    LANGUAGE sql
    AS $$
    SELECT c.comment_id, c.member_id, c.product_id, c.parent_comment_id, c.comment, c.comment_date, c.review_id, m.username FROM public.comments c
	JOIN member m ON m.id = c.member_id
	WHERE p_product_id = product_id;
$$;


--
-- TOC entry 266 (class 1255 OID 41402)
-- Name: getcommentsbyreview(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getcommentsbyreview(p_review_id integer) RETURNS TABLE(comment_id integer, member_id integer, product_id integer, parent_comment_id integer, comment text, comment_date timestamp without time zone, review_id integer, username character varying)
    LANGUAGE sql
    AS $$
    SELECT c.comment_id, c.member_id, c.product_id, c.parent_comment_id, c.comment, c.comment_date, c.review_id, m.username FROM comments c
	JOIN member m
	ON c.member_id = m.id
	WHERE p_review_id = review_id;
$$;


--
-- TOC entry 257 (class 1255 OID 41121)
-- Name: getreviews(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getreviews() RETURNS TABLE(member_id integer, review_id integer, product_id integer, rating integer, review_text text, last_update timestamp without time zone, product_name text)
    LANGUAGE sql
    AS $$
    SELECT member_id, review_id, product_id, rating, review_text, last_update, product_name FROM public.review;
$$;


--
-- TOC entry 267 (class 1255 OID 41426)
-- Name: getreviewsforproduct(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.getreviewsforproduct(p_product_id integer) RETURNS TABLE(member_id integer, review_id integer, product_id integer, rating integer, review_text text, last_update timestamp without time zone, product_name text, username character varying)
    LANGUAGE sql
    AS $$
    SELECT r.member_id, r.review_id, r.product_id, r.rating, r.review_text, r.last_update, r.product_name, m.username  
	FROM review r 
	JOIN member m 
	ON r.member_id = m.id 
	WHERE r.product_id = p_product_id;
$$;


--
-- TOC entry 261 (class 1255 OID 41266)
-- Name: update_cart(integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.update_cart(IN p_member_id integer, IN p_product_id integer, IN p_quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if cart exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM cart WHERE member_id = p_member_id) THEN
        RAISE EXCEPTION 'Cart item not found.';
    END IF;

    -- Update the cart
    UPDATE cart
	SET quantity = p_quantity
    WHERE member_id = p_member_id
	AND product_id = p_product_id;
END;
$$;


--
-- TOC entry 255 (class 1255 OID 41110)
-- Name: update_review(integer, character varying, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.update_review(IN p_review_id integer, IN p_review character varying, IN p_rating integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM review WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Update the review
    UPDATE review
	SET rating = p_rating,
        review_text = p_review,
        last_update = CURRENT_TIMESTAMP
    WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 233 (class 1255 OID 41070)
-- Name: updatereview(integer, integer, text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.updatereview(IN p_review_id integer, IN p_rating integer, IN p_review text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
    IF NOT EXISTS (SELECT 1 FROM reviews WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Update the review
    UPDATE reviews
    SET rating = p_rating,
        review = p_review,
        last_update = CURRENT_TIMESTAMP
    WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 248 (class 1255 OID 41102)
-- Name: updatereview(integer, text, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.updatereview(IN p_review_id integer, IN p_review text, IN p_rating integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM reviews WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Update the review
    UPDATE reviews
    SET rating = p_rating,
        review = p_review,
        last_update = CURRENT_TIMESTAMP
    WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 249 (class 1255 OID 41103)
-- Name: updatereview(integer, character varying, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.updatereview(IN p_review_id integer, IN p_review character varying, IN p_rating integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if review exists
	-- SELECT 1 just checks if there is something there
    IF NOT EXISTS (SELECT 1 FROM review WHERE review_id = p_review_id) THEN
        RAISE EXCEPTION 'Review not found.';
    END IF;

    -- Validate rating range
    IF p_rating < 1 OR p_rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5.';
    END IF;

    -- Update the review
    UPDATE review
	SET rating = p_rating,
        review_text = p_review,
        last_update = CURRENT_TIMESTAMP
    WHERE review_id = p_review_id;
END;
$$;


--
-- TOC entry 230 (class 1259 OID 41135)
-- Name: cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart (
    cart_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 41134)
-- Name: cart_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5003 (class 0 OID 0)
-- Dependencies: 229
-- Name: cart_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_cart_id_seq OWNED BY public.cart.cart_id;


--
-- TOC entry 232 (class 1259 OID 41361)
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    comment_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    comment text NOT NULL,
    parent_comment_id integer,
    review_id integer,
    comment_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 231 (class 1259 OID 41360)
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5004 (class 0 OID 0)
-- Dependencies: 231
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- TOC entry 217 (class 1259 OID 24606)
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    dob date NOT NULL,
    password character varying(255) NOT NULL,
    role integer NOT NULL,
    gender character(1) NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 24609)
-- Name: member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5005 (class 0 OID 0)
-- Dependencies: 218
-- Name: member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_id_seq OWNED BY public.member.id;


--
-- TOC entry 219 (class 1259 OID 24610)
-- Name: member_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_role (
    id integer NOT NULL,
    name character varying(25)
);


--
-- TOC entry 220 (class 1259 OID 24613)
-- Name: member_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5006 (class 0 OID 0)
-- Dependencies: 220
-- Name: member_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_role_id_seq OWNED BY public.member_role.id;


--
-- TOC entry 221 (class 1259 OID 24614)
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id integer NOT NULL,
    name character varying(255),
    description text,
    unit_price numeric NOT NULL,
    stock_quantity numeric DEFAULT 0 NOT NULL,
    country character varying(100),
    product_type character varying(50),
    image_url character varying(255) DEFAULT '/images/product.png'::character varying,
    manufactured_on timestamp without time zone
);


--
-- TOC entry 222 (class 1259 OID 24621)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5007 (class 0 OID 0)
-- Dependencies: 222
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 228 (class 1259 OID 41055)
-- Name: review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    member_id integer NOT NULL,
    product_id integer NOT NULL,
    rating integer NOT NULL,
    review_text text,
    last_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    product_name character varying(75) NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 41054)
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5008 (class 0 OID 0)
-- Dependencies: 227
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- TOC entry 223 (class 1259 OID 24622)
-- Name: sale_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order (
    id integer NOT NULL,
    member_id integer,
    order_datetime timestamp without time zone NOT NULL,
    status character varying(10)
);


--
-- TOC entry 224 (class 1259 OID 24625)
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5009 (class 0 OID 0)
-- Dependencies: 224
-- Name: sale_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_id_seq OWNED BY public.sale_order.id;


--
-- TOC entry 225 (class 1259 OID 24626)
-- Name: sale_order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order_item (
    id integer NOT NULL,
    sale_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 24631)
-- Name: sale_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5010 (class 0 OID 0)
-- Dependencies: 226
-- Name: sale_order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_item_id_seq OWNED BY public.sale_order_item.id;


--
-- TOC entry 4822 (class 2604 OID 41138)
-- Name: cart cart_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart ALTER COLUMN cart_id SET DEFAULT nextval('public.cart_cart_id_seq'::regclass);


--
-- TOC entry 4823 (class 2604 OID 41364)
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- TOC entry 4813 (class 2604 OID 24632)
-- Name: member id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN id SET DEFAULT nextval('public.member_id_seq'::regclass);


--
-- TOC entry 4814 (class 2604 OID 24633)
-- Name: member_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role ALTER COLUMN id SET DEFAULT nextval('public.member_role_id_seq'::regclass);


--
-- TOC entry 4815 (class 2604 OID 24634)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 4820 (class 2604 OID 41058)
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- TOC entry 4818 (class 2604 OID 24635)
-- Name: sale_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order ALTER COLUMN id SET DEFAULT nextval('public.sale_order_id_seq'::regclass);


--
-- TOC entry 4819 (class 2604 OID 24636)
-- Name: sale_order_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item ALTER COLUMN id SET DEFAULT nextval('public.sale_order_item_id_seq'::regclass);


--
-- TOC entry 4842 (class 2606 OID 41140)
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (cart_id);


--
-- TOC entry 4844 (class 2606 OID 41369)
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- TOC entry 4826 (class 2606 OID 24638)
-- Name: member member_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_email_key UNIQUE (email);


--
-- TOC entry 4828 (class 2606 OID 24640)
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- TOC entry 4832 (class 2606 OID 24642)
-- Name: member_role member_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_role
    ADD CONSTRAINT member_role_pkey PRIMARY KEY (id);


--
-- TOC entry 4830 (class 2606 OID 24644)
-- Name: member member_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_username_key UNIQUE (username);


--
-- TOC entry 4834 (class 2606 OID 24646)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 4840 (class 2606 OID 41063)
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- TOC entry 4838 (class 2606 OID 24648)
-- Name: sale_order_item sale_order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT sale_order_item_pkey PRIMARY KEY (id);


--
-- TOC entry 4836 (class 2606 OID 24650)
-- Name: sale_order sale_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT sale_order_pkey PRIMARY KEY (id);


--
-- TOC entry 4849 (class 2606 OID 41370)
-- Name: comments comments_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(id) ON DELETE CASCADE;


--
-- TOC entry 4850 (class 2606 OID 41380)
-- Name: comments comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.comments(comment_id) ON DELETE CASCADE;


--
-- TOC entry 4851 (class 2606 OID 41375)
-- Name: comments comments_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id) ON DELETE CASCADE;


--
-- TOC entry 4852 (class 2606 OID 41385)
-- Name: comments comments_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.review(review_id) ON DELETE SET NULL;


--
-- TOC entry 4845 (class 2606 OID 24651)
-- Name: member fk_member_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT fk_member_role_id FOREIGN KEY (role) REFERENCES public.member_role(id);


--
-- TOC entry 4847 (class 2606 OID 24656)
-- Name: sale_order_item fk_sale_order_item_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_product FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- TOC entry 4848 (class 2606 OID 24661)
-- Name: sale_order_item fk_sale_order_item_sale_order; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_item
    ADD CONSTRAINT fk_sale_order_item_sale_order FOREIGN KEY (sale_order_id) REFERENCES public.sale_order(id);


--
-- TOC entry 4846 (class 2606 OID 24666)
-- Name: sale_order fk_sale_order_member; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order
    ADD CONSTRAINT fk_sale_order_member FOREIGN KEY (member_id) REFERENCES public.member(id);


-- Completed on 2025-07-03 11:45:21

--
-- PostgreSQL database dump complete
--

