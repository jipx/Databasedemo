
CREATE OR REPLACE PROCEDURE place_orders(p_member_id INT)
LANGUAGE plpgsql
AS $$
DECLARE
  v_cart_id   INT;
  v_item      RECORD;
  v_order_id  INT;               
  v_available NUMERIC(10,2);     
  v_qty_int   INT;
BEGIN
  
  SELECT "id" INTO v_cart_id
  FROM "Cart"
  WHERE "memberId" = p_member_id;

  IF v_cart_id IS NULL THEN
    RAISE EXCEPTION 'Cart not found for member %', p_member_id;
  END IF;

  
  FOR v_item IN
    SELECT ci."id" AS cart_item_id,
           ci."productId" AS product_id,
           ci."quantity"   AS qty
    FROM "CartItem" ci
    WHERE ci."cartId" = v_cart_id
    ORDER BY ci."id"
  LOOP
    v_qty_int := v_item.qty;


    SELECT "stock_quantity"
    INTO v_available
    FROM "product"
    WHERE "id" = v_item.product_id
    FOR UPDATE;


    IF v_available IS NULL THEN
      CONTINUE;
    END IF;


    IF v_available >= v_qty_int THEN

      IF v_order_id IS NULL THEN
        INSERT INTO "sale_order" ("member_id","order_datetime","status")
        VALUES (p_member_id, NOW(), 'PACKING')
        RETURNING "id" INTO v_order_id;
      END IF;


      UPDATE "product"
      SET "stock_quantity" = "stock_quantity" - v_qty_int
      WHERE "id" = v_item.product_id;

      INSERT INTO "sale_order_item" ("sale_order_id","product_id","quantity")
      VALUES (v_order_id, v_item.product_id, v_qty_int);

  
      DELETE FROM "CartItem"
      WHERE "id" = v_item.cart_item_id;
    ELSE
      CONTINUE;
    END IF;
  END LOOP;

END;
$$;
