window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");
    const form = document.querySelector("form");
    const loadingElement = document.getElementById("loading");
    const resultsElement = document.getElementById("results");

    // Initial load
    fetchSalesOrderSummary();

    form.addEventListener("submit", function(event) {
        event.preventDefault();
        fetchSalesOrderSummary(getQueryParams());
    });

    function getQueryParams() {
        const params = new URLSearchParams();
        
        const gender = document.getElementById("gender").value;
        if (gender) params.append("gender", gender);
        
        const productType = document.getElementById("product_type").value;
        if (productType) params.append("product_type", productType);
        
        const ageMin = document.getElementById("age_min").value;
        if (ageMin) params.append("age_min", ageMin);
        
        const ageMax = document.getElementById("age_max").value;
        if (ageMax) params.append("age_max", ageMax);
        
        const dateFrom = document.getElementById("date_from").value;
        if (dateFrom) params.append("date_from", dateFrom);
        
        const dateTo = document.getElementById("date_to").value;
        if (dateTo) params.append("date_to", dateTo);
        
        const minTotalSpending = document.getElementById("min_total_spending").value;
        if (minTotalSpending) params.append("min_total_spending", minTotalSpending);
        
        const minOrderCount = document.getElementById("min_order_count").value;
        if (minOrderCount) params.append("min_order_count", minOrderCount);
        
        const sortBy = document.getElementById("sort_by").value;
        params.append("sort_by", sortBy);
        
        const sortOrder = document.getElementById("sort_order").value;
        params.append("sort_order", sortOrder);
        
        return params.toString();
    }

    function fetchSalesOrderSummary(queryParams = "") {
        loadingElement.style.display = "block";
        resultsElement.style.display = "none";
        
        fetch(`/dashboard/salesordersummary?${queryParams}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        })
        .then(function (response) {
            if (!response.ok) throw new Error("Network response was not ok");
            return response.json();
        })
        .then(function (data) {
            renderSummaryData(data);
            loadingElement.style.display = "none";
            resultsElement.style.display = "block";
        })
        .catch(function (error) {
            console.error("Error:", error);
            loadingElement.style.display = "none";
            alert("Error loading data: " + error.message);
        });
    }

    function renderSummaryData(data) {
        const tableBody = document.getElementById("summary-data");
        tableBody.innerHTML = "";
        console.log(data);
        if (data.length === 0) {
            const row = document.createElement("tr");
            row.innerHTML = `<td colspan="10" style="text-align: center;">No data found</td>`;
            tableBody.appendChild(row);
            return;
        }
        
        data.forEach(item => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${item.memberId}</td>
                <td>${item.username}</td>
                <td>${item.gender === 'M' ? 'Male' : 'Female'}</td>
                <td>${item.age}</td>
                <td>${item.ageGroup}</td>
                <td>$${item.totalSpending.toFixed(2)}</td>
                <td>${item.orderCount}</td>
                <td>$${item.avgOrderValue.toFixed(2)}</td>
                <td>${item.favoriteProductType || 'N/A'}</td>
                <td>${item.mostPurchasedProduct || 'N/A'}</td>
            `;
            tableBody.appendChild(row);
        });
    }
});