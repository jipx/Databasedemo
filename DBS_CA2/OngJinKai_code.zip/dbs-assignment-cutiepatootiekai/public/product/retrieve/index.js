// you can modify the code to suit your needs

function fetchProduct(productId) {
  const token = localStorage.getItem("token");

  return fetch(`/products/${productId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (body) {
      if (body.error) throw new Error(body.error);
      const product = body.product;
      const tbody = document.querySelector("#product-tbody");

      const row = document.createElement("tr");
      row.classList.add("product");
      const nameCell = document.createElement("td");
      const descriptionCell = document.createElement("td");
      const unitPriceCell = document.createElement("td");
      const countryCell = document.createElement("td");
      const productTypeCell = document.createElement("td");
      const imageUrlCell = document.createElement("td");
      const manufacturedOnCell = document.createElement("td");

      nameCell.textContent = product.name;
      descriptionCell.textContent = product.description;
      unitPriceCell.textContent = product.unitPrice;
      countryCell.textContent = product.country;
      productTypeCell.textContent = product.productType;
      imageUrlCell.innerHTML = `<img src="${product.imageUrl}" alt="Product Image">`;
      manufacturedOnCell.textContent = new Date(
        product.manufacturedOn
      ).toLocaleString();

      row.appendChild(nameCell);
      row.appendChild(descriptionCell);
      row.appendChild(unitPriceCell);
      row.appendChild(countryCell);
      row.appendChild(productTypeCell);
      row.appendChild(imageUrlCell);
      row.appendChild(manufacturedOnCell);
      tbody.appendChild(row);
    })
    .catch(function (error) {
      console.error(error);
    });
}

function fetchProductReviews(productId) {
  const token = localStorage.getItem("token");
  const currentUserId = localStorage.getItem("userId"); // Make sure you have this

  let url = `/reviews/product/${productId}`;

  return fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (body) {
      if (body.error) throw new Error(body.error);
      const reviews = body.rows;
      console.log(reviews);
      const reviewsContainer = document.querySelector("#reviews-container");

      reviews.forEach(function (review) {
        const reviewDiv = document.createElement("div");
        reviewDiv.classList.add("review-row");
        let ratingStars = "";
        for (let i = 0; i < review.rating; i++) {
          ratingStars += "⭐";
        }

        reviewDiv.innerHTML = `            
          <h3>Member Username: ${review.username}</h3>
          <p>Rating: ${ratingStars}</p>
          <p>Review Text: ${review.reviewText}</p>
          <p>Last Updated: ${new Date(review.createdAt).toLocaleString("en-US")}</p>
          <div class="comments-section" data-review-id="${review.reviewId}">
              <h4>Comments</h4>
              <div class="comments-list">
                  <!-- Comments will appear here -->
              </div>
              ${review.memberId !== currentUserId ? 
                `<div class="add-comment">
                    <textarea class="comment-text" placeholder="Add a comment..."></textarea>
                    <button class="submit-comment">Post Comment</button>
                </div>` : ''}
          </div>
        `;

        reviewsContainer.appendChild(reviewDiv);

        // Only add event listener if comment box exists (user isn't the review author)
        if (review.memberId !== currentUserId) {
          const submitBtn = reviewDiv.querySelector('.submit-comment');
          submitBtn.addEventListener('click', async () => {
            const commentText = reviewDiv.querySelector('.comment-text').value.trim();
            const reviewId = reviewDiv.querySelector('.comments-section').dataset.reviewId;
            const memberId = localStorage.getItem('memberId');
            if (!commentText) {
              alert('Please enter a comment');
              return;
            }

            try {
              const response = await fetch('/comments', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                  reviewId,
                  commentText,
                  memberId
                })
              });

              if (!response.ok) {
                throw new Error('Failed to post comment');
              }

              // Clear the textarea
              reviewDiv.querySelector('.comment-text').value = '';
              
              // Refresh comments for this review
              await fetchCommentsForReview(review.reviewId, reviewDiv);
              
            } catch (error) {
              console.error('Error posting comment:', error);
              alert('Failed to post comment');
            }
          });
        }

        // Load existing comments for this review
        fetchCommentsForReview(review.reviewId, reviewDiv);
      });
    })
    .catch(function (error) {
      console.error(error);
    });
}

// Helper function to fetch and display comments for a review
async function fetchCommentsForReview(reviewId, reviewDiv) {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`/comments/${reviewId}`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) throw new Error('Failed to fetch comments');
    
    const comments = await response.json();
    const content = comments.rows;
    const commentsList = reviewDiv.querySelector('.comments-list');
    commentsList.innerHTML = ''; // Clear existing comments
    
    if (content.length === 0) {
      commentsList.innerHTML = '<p>No comments yet</p>';
      return;
    }
    
    // Process each comment and its replies
    for (const comment of content) {
      await displayCommentWithReplies(comment, commentsList, 0);
    }
    
  } catch (error) {
    console.error('Error fetching comments:', error);
    reviewDiv.querySelector('.comments-list').innerHTML = '<p>Error loading comments</p>';
  }
}

async function displayCommentWithReplies(comment, container, depth) {
  const commentElement = document.createElement('div');
  commentElement.className = 'comment';
  commentElement.style.marginLeft = `${depth * 20}px`; // Indent replies
 
  commentElement.innerHTML = `
    <div class="comment-container">
      <div class="comment-content">
        <p><strong>${comment.memberName}:</strong> ${comment.commentText}</p>
        <p class="comment-date">${new Date(comment.createdAt).toLocaleString()}</p>
      </div>
      <div class="comment-actions">
        <button class="reply-comment-btn" data-comment-id="${comment.commentId}" title="Reply">
          <svg viewBox="0 0 24 24" width="16" height="16">
            <path fill="currentColor" d="M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z"/>
          </svg>
          Reply
        </button>
        <button class="delete-comment-btn" data-comment-id="${comment.commentId}" title="Delete">
          <svg viewBox="0 0 24 24" width="16" height="16">
            <path fill="currentColor" d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z"/>
          </svg>
        </button>
      </div>
    </div>
    <div class="reply-list" id="reply-list-${comment.commentId}">
      <!-- Replies will be dynamically inserted here -->
    </div>
  `;
  
  container.appendChild(commentElement);
  
  // Add event listeners
  commentElement.querySelector('.reply-comment-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    const commentId = e.currentTarget.dataset.commentId;
    showReplyForm(commentId, commentElement);
  });
  
  commentElement.querySelector('.delete-comment-btn').addEventListener('click', async (e) => {
    e.stopPropagation();
    await deleteComment(comment.commentId, commentElement);
  });
  
  // Fetch and display replies for this comment
  await fetchAndDisplayReplies(comment.commentId, commentElement, depth + 1);
}

async function fetchAndDisplayReplies(commentId, parentElement, depth) {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(`/comments/reply/${commentId}`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) throw new Error('Failed to fetch replies');
    
    const replies = await response.json();
    const replyList = parentElement.querySelector(`#reply-list-${commentId}`);
    
    if (replies.rows && replies.rows.length > 0) {
      for (const reply of replies.rows) {
        await displayCommentWithReplies(reply, replyList, depth);
      }
    }
  } catch (error) {
    console.error('Error fetching replies:', error);
  }
}

async function showReplyForm(commentId, parentElement) {
  // Remove any existing reply form
  const existingForm = parentElement.querySelector('.reply-form');
  if (existingForm) existingForm.remove();
  
  const replyForm = document.createElement('div');
  replyForm.className = 'reply-form-container';
  replyForm.innerHTML = `
    <form class="reply-form" data-parent-id="${commentId}">
      <textarea placeholder="Write your reply..." required></textarea>
      <div class="form-buttons">
        <button type="submit" class="submit-reply">Post Reply</button>
        <button type="button" class="cancel-reply">Cancel</button>
      </div>
    </form>
  `;
  
  const replyList = parentElement.querySelector(`#reply-list-${commentId}`);
  replyList.prepend(replyForm);
  
  // Handle form submission
  replyForm.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const replyText = e.target.querySelector('textarea').value.trim();
    if (!replyText) return;
    
    try {
      await postReply(commentId, replyText);
      replyForm.remove();
      // Refresh just this comment's replies
      await fetchAndDisplayReplies(commentId, parentElement, 1);
    } catch (error) {
      console.error('Error posting reply:', error);
      alert('Failed to post reply');
    }
  });
  
  // Handle cancel
  replyForm.querySelector('.cancel-reply').addEventListener('click', () => {
    replyForm.remove();
  });
}

async function postReply(commentId, replyText) {
  const token = localStorage.getItem("token");
  const memberId = localStorage.getItem("memberId");

  
  const response = await fetch('/comments/reply', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      parentId: commentId,
      text: replyText,
      memberId: memberId
    })
  });
  
  if (!response.ok) throw new Error('Failed to post reply');
  return response.json();
}

async function deleteComment(commentId, commentElement) {
  if (!confirm('Are you sure you want to delete this comment?')) return;
  
  const token = localStorage.getItem("token");
  const memberId = localStorage.getItem("memberId");
  
  try {
    const response = await fetch(`/comments/${commentId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ memberId })
    });
    
    if (response.ok) {
      commentElement.remove();
    } else {
      throw new Error('Failed to delete comment');
    }
  } catch (error) {
    console.error('Error:', error);
    alert('Error deleting comment');
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const productId = localStorage.getItem("productId");

  fetchProduct(productId)
    .then(function (productData) {
      return fetchProductReviews(productId);
    })
    .then(function () {
      // Both fetchProduct and fetchProductReviews have been called
      console.log("Both fetchProduct and fetchProductReviews have been called");
    })
    .catch(function (error) {
      // Handle error
      console.error(error);
    });
});
