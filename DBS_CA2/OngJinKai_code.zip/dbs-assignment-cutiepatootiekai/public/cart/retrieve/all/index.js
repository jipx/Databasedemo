window.addEventListener("DOMContentLoaded", function () {
  const token = localStorage.getItem("token");
  const memberId = parseInt(localStorage.getItem("memberId"));

  const checkoutButton = document.getElementById("checkout-button");
  checkoutButton.addEventListener("click", function () {
    window.location.href = "/checkout";
  });

  refreshCart(token, memberId).catch(console.error);
});

function refreshCart(token, memberId) {
  return fetchCartItems(token, memberId).then(() =>
    fetchCartSummary(token, memberId)
  );
}

// GET /carts/items?memberId=...
function fetchCartItems(token, memberId) {
  return fetch(`/carts/items?memberId=${memberId}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.json())
    .then(function (items) {
      if (items.error) throw new Error(items.error);

      const tbody = document.querySelector("#cart-items-tbody");
      tbody.innerHTML = "";

      items.forEach(function (cartItem) {
        const row = document.createElement("tr");
        row.classList.add("product");

        const descriptionCell = document.createElement("td");
        const countryCell = document.createElement("td");
        const subTotalCell = document.createElement("td");
        const unitPriceCell = document.createElement("td");
        const quantityCell = document.createElement("td");
        const updateButtonCell = document.createElement("td");
        const deleteButtonCell = document.createElement("td");

        const updateButton = document.createElement("button");
        const deleteButton = document.createElement("button");

        const p = cartItem.product || {};
        const unitPrice = Number(p.unitPrice ?? p.original_price ?? 0);
        const qty = parseInt(cartItem.quantity);
        const subTotal = unitPrice * qty;

        descriptionCell.textContent = p.description ?? "(no description)";
        countryCell.textContent = p.country ?? "-";
        subTotalCell.textContent = subTotal.toFixed(2);
        unitPriceCell.textContent = unitPrice.toFixed(2);

        const quantityInput = document.createElement("input");
        quantityInput.type = "number";
        quantityInput.min = "1";
        quantityInput.value = qty;
        quantityCell.appendChild(quantityInput);

        // Update
        updateButton.textContent = "Update";
        updateButton.addEventListener("click", function () {
          const updatedQuantity = parseInt(quantityInput.value);
          if (!Number.isFinite(updatedQuantity) || updatedQuantity <= 0) {
            alert("Quantity must be a positive integer");
            return;
          }

          fetch(`/carts/items/${cartItem.productId}`, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ memberId, quantity: updatedQuantity }),
          })
            .then((r) => r.json())
            .then(function (body) {
              if (body.error) throw new Error(body.error);
              alert("✅ Update successful!");
              return refreshCart(token, memberId);
            })
            .catch(function (err) {
              console.error(err);
              alert(err.message || "Failed to update item");
            });
        });
        updateButtonCell.appendChild(updateButton);

        // Delete
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", function () {
          if (!confirm("Remove this item from your cart?")) return;
          fetch(`/carts/items/${cartItem.productId}`, {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ memberId }),
          })
            .then((r) => r.json())
            .then(function (body) {
              if (body.error) throw new Error(body.error);
              return refreshCart(token, memberId);
            })
            .catch(function (err) {
              console.error(err);
              alert(err.message || "Failed to delete item");
            });
        });
        deleteButtonCell.appendChild(deleteButton);

        row.appendChild(descriptionCell);
        row.appendChild(countryCell);
        row.appendChild(subTotalCell);
        row.appendChild(unitPriceCell);
        row.appendChild(quantityCell);
        row.appendChild(updateButtonCell);
        row.appendChild(deleteButtonCell);

        tbody.appendChild(row);
      });
    });
}

// GET /carts/summary?memberId=...  (no discounts on cart page)
function fetchCartSummary(token, memberId) {
  return fetch(`/carts/summary?memberId=${memberId}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.json())
    .then(function (summary) {
      if (summary.error) throw new Error(summary.error);
      const cartSummaryDiv = document.querySelector("#cart-summary");
      cartSummaryDiv.innerHTML = "";

      const addRow = (label, value) => {
        const lab = document.createElement("label");
        lab.textContent = label;
        lab.classList.add("label");
        const val = document.createElement("span");
        val.textContent = value;
        val.classList.add("value");
        cartSummaryDiv.appendChild(lab);
        cartSummaryDiv.appendChild(val);
        cartSummaryDiv.appendChild(document.createElement("br"));
      };

      addRow("Total Quantity: ", summary.itemCount);
      addRow("Total Checkout Price: $", summary.total.toFixed(2)); // equals subtotal at cart
    });
}
