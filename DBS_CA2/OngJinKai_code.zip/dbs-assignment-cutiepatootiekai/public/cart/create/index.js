// public/cart/create/index.js
window.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");
  if (!token) return (window.location.href = "/login.html");

  const form = document.querySelector("form");
  const productIdInput = document.getElementById("productId");
  const quantityInput = document.getElementById("quantity");
  const badge = document.getElementById("cart-product-id");

  // 1) Prefer productId from localStorage (set when user clicked "Add to cart" on product page)
  const cachedProductId = localStorage.getItem("cartProductId");
  if (cachedProductId) {
    productIdInput.value = cachedProductId;
    if (badge) badge.textContent = cachedProductId;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const productId = parseInt(productIdInput.value);
    const quantity = parseInt(quantityInput.value || 1);
    const memberId = parseInt(localStorage.getItem("memberId"));
    try {
      const res = await fetch("/carts/items", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ memberId, productId, quantity }), // 👈 send in body
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add item");

      alert(`Added product ${productId} x ${quantity} ✅`);
      window.location.href = "../retrieve/all/index.html";
    } catch (err) {
      alert(err.message);
    }
  });
});
