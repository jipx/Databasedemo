window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const reviewId = localStorage.getItem('reviewId');
    const form = document.querySelector('form');

    // Set the reviewId in the form
    form.querySelector('input[name="reviewId"]').value = reviewId;

    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        // Get form data
        const formData = {
            reviewId: form.querySelector('input[name="reviewId"]').value,
            memberId: localStorage.getItem('memberId')
        };
        // Basic validation
        if (!formData.reviewId) {
            alert('Please enter a review ID');
            return;
        }

        // Make DELETE request
        fetch('/reviews', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(formData)
        })
        .then(function(response) {
    if (response.status === 204) {
        
        // Handle 204 No Content response
        return { success: true };
    }
    if (!response.ok) {
        return response.json().then(function(err) {
            throw new Error(err.message || "Delete failed");
        });
    }
    return response.json();
})
.then(function(data) {
    if (data && data.success) {
        alert("Review deleted successfully!");
    }
})
.catch(function(error) {
    alert(error.message || "Failed to delete review");
    console.error('Error:', error);
});
    });
});