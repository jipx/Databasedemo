window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const reviewId = localStorage.getItem('reviewId');
    const form = document.querySelector('form');

    // Set the reviewId in the form
    form.querySelector('input[name="reviewId"]').value = reviewId;

    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        // Get all form data
        const formData = {
            memberId: localStorage.getItem("memberId"),
            reviewId: form.querySelector('input[name="reviewId"]').value,
            rating: form.querySelector('select[name="rating"]').value,
            reviewText: form.querySelector('textarea[name="reviewText"]').value
        };

        // Basic validation
        if (!formData.rating) {
            alert('Please select a rating');
            return;
        }

        if (!formData.reviewText.trim()) {
            alert('Please enter your review text');
            return;
        }

        // Convert rating to number
        formData.rating = parseInt(formData.rating);

        fetch('/reviews', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (response.status === 204) {
                // Handle 204 No Content response
                return { success: true };
            }
            if (!response.ok) {
                return response.json().then(err => {
                    throw new Error(err.message || "Update failed");
                });
            }
            return response.json();
        })
        .then(data => {
            if (data && data.success) {
                alert("Review updated successfully!");
            }
        })
        .catch(error => {
            alert(error.message || "Something went wrong. Please try again.");
            console.error('Error:', error);
        });
    });
});