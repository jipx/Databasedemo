window.addEventListener("DOMContentLoaded", () => {
  console.log("[checkout] DOM ready");
  const token = localStorage.getItem("token");
  const memberId = parseInt(localStorage.getItem("memberId"));
  if (!token || !Number.isFinite(memberId)) {
    console.warn("[checkout] Missing token/memberId → redirecting to /login");
    window.location.href = "/login";
    return;
  }

  const summaryRoot = document.getElementById("checkout-summary");
  const placeOrderBtn = document.getElementById("place-order");
  if (!summaryRoot || !placeOrderBtn) {
    console.error(
      "[checkout] Missing #checkout-summary or #place-order in HTML"
    );
    return;
  }

  function currency(n) {
    return Number(n || 0).toFixed(2);
  }

  function renderSummary(data) {
    summaryRoot.innerHTML = "";
    const table = document.createElement("table");
    table.border = "1";
    const thead = document.createElement("thead");
    thead.innerHTML = `
      <tr>
        <th>Product</th>
        <th>Country</th>
        <th>Unit Price</th>
        <th>Discount / Unit</th>
        <th>Final Unit Price</th>
        <th>Qty</th>
        <th>Line Subtotal</th>
        <th>Line Discount</th>
        <th>Line Total</th>
      </tr>`;
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    (data.items || []).forEach((it) => {
      const tr = document.createElement("tr");
      [
        it.product.description ?? "(no description)",
        it.product.country ?? "-",
        `$${currency(it.unitPrice)}`,
        it.discountPerUnit > 0 ? `-$${currency(it.discountPerUnit)}` : "$0.00",
        `$${currency(it.finalUnitPrice)}`,
        it.quantity,
        `$${currency(it.lineSubtotal)}`,
        it.lineDiscount > 0 ? `-$${currency(it.lineDiscount)}` : "$0.00",
        `$${currency(it.lineTotal)}`,
      ].forEach((txt) => {
        const td = document.createElement("td");
        td.textContent = txt;
        td.style.textAlign = "center";
        td.style.verticalAlign = "middle";
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    summaryRoot.appendChild(table);

    const totals = document.createElement("div");
    totals.style.marginTop = "12px";
    totals.innerHTML = `
      <p><strong>Items:</strong> ${data.itemCount}</p>
      <p><strong>Subtotal:</strong> $${currency(data.subtotal)}</p>
      <p><strong>Total Discount:</strong> -$${currency(data.totalDiscount)}</p>
      <p><strong>Total Payable:</strong> $${currency(data.total)}</p>
    `;
    summaryRoot.appendChild(totals);
  }

  function loadSummary() {
    console.log("[checkout] Loading summary…");
    return fetch(`/checkout/summary?memberId=${memberId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        renderSummary(data);
      })
      .catch((e) => {
        console.error("[checkout] Summary error:", e);
        alert(e.message || "Failed to load checkout summary");
      });
  }

  placeOrderBtn.addEventListener("click", () => {
    placeOrderBtn.disabled = true;
    fetch("/checkout/confirm", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ memberId }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        alert(data.message || "✅ Order confirmed!");
        return loadSummary(); // refresh after placing order
      })
      .catch((e) => {
        console.error("[checkout] Confirm error:", e);
        alert(e.message || "Checkout failed");
      })
      .finally(() => (placeOrderBtn.disabled = false));
  });

  // 🟢 IMPORTANT: actually load the summary at startup
  loadSummary();
});
