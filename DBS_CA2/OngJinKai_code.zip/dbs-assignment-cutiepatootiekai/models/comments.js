const pool = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

module.exports.createComment = (data, callback) =>
{
    const SQLSTATMENT = `
   CALL create_comment($1, $2, $3);
    `;
    const VALUES = [data.memberId,data.reviewId, data.commentText];

    pool.query(SQLSTATMENT, VALUES, callback);
};
module.exports.selectAll = (data,callback) => {
    const SQLSTATMENT = `
    SELECT * FROM get_comments($1); `;
const VALUES = [data.reviewId];
    pool.query(SQLSTATMENT, VALUES, callback);

};
module.exports.deleteComment = (data,callback) => {
    const SQLSTATMENT = `
    CALL delete_comment($1,$2);`;
    const VALUES=[data.commentId,data.memberId];
    pool.query(SQLSTATMENT,VALUES, callback);
    
}
module.exports.createReply = (data, callback) => {
    const SQLSTATMENT = `
    CALL create_reply($1,$2,$3)`
    const VALUES = [data.memberId,data.parentId,data.commentText];
    pool.query(SQLSTATMENT,VALUES, callback);

}

module.exports.selectReplies = (data,callback) => {
    const SQLSTATMENT = `
    SELECT * FROM get_comment_replies($1); `;
const VALUES = [data.parentId];
    pool.query(SQLSTATMENT, VALUES, callback);

};