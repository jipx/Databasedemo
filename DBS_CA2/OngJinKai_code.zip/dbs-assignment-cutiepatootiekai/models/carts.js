const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// Ensure a cart exists for a member
async function ensureCart(memberId) {
  const existing = await prisma.cart.findFirst({ where: { memberId } });
  return existing ?? prisma.cart.create({ data: { memberId } });
}

// Add item (or increment if exists)
async function addToCart(memberId, productId, qty = 1) {
  if (qty <= 0) throw new Error("Quantity must be >= 1");
  const cart = await ensureCart(memberId);
  return prisma.cartItem.upsert({
    where: { cartId_productId: { cartId: cart.id, productId } },
    update: { quantity: { increment: qty } },
    create: { cartId: cart.id, productId, quantity: qty },
    include: { product: true },
  });
}

// Set quantity on a line
async function updateLine(memberId, productId, qty) {
  if (qty <= 0) throw new Error("Quantity must be >= 1");
  const cart = await prisma.cart.findFirstOrThrow({ where: { memberId } });
  return prisma.cartItem.update({
    where: { cartId_productId: { cartId: cart.id, productId } },
    data: { quantity: qty },
    include: { product: true },
  });
}

// Remove a line
async function removeLine(memberId, productId) {
  const cart = await prisma.cart.findFirstOrThrow({ where: { memberId } });
  return prisma.cartItem.delete({
    where: { cartId_productId: { cartId: cart.id, productId } },
  });
}

// Get cart with items+products
async function getCart(memberId) {
  const cart = await prisma.cart.findFirst({
    where: { memberId },
    include: { items: { include: { product: true } } },
  });
  return cart ?? { id: null, items: [] };
}

async function getSummary(memberId) {
  const cart = await prisma.cart.findFirst({
    where: { memberId },
    include: { items: { include: { product: true } } },
  });
  if (!cart)
    return { itemCount: 0, subtotal: 0, discountTotal: 0, total: 0, items: [] };

  let itemCount = 0;
  let subtotal = 0;

  for (const it of cart.items) {
    const p = it.product || {};
    const price = Number(
      p.unitPrice != null
        ? p.unitPrice
        : p.original_price != null
        ? p.original_price
        : 0
    );
    const lineQty = it.quantity;
    const lineSubtotal = price * lineQty;

    itemCount += lineQty;
    subtotal += lineSubtotal;
  }

  // cart page shows no discounts; compute total = subtotal
  const discountTotal = 0;
  const total = subtotal;

  return { itemCount, subtotal, discountTotal, total, items: cart.items };
}

module.exports = {
  addToCart,
  updateLine,
  removeLine,
  getCart,
  getSummary,
};
