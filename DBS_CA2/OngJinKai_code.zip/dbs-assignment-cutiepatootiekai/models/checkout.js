const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

function bestDiscountPerUnit(unitPrice, qty, discounts) {
  const now = new Date();
  let best = 0;

  for (const d of discounts || []) {
    const isActive = (d.isActive ?? d.active ?? true) === true;
    const start = d.startAt ?? d.startsAt ?? d.startDate ?? null;
    const end = d.endAt ?? d.endsAt ?? d.endDate ?? null;
    if (!isActive) continue;
    if (start && now < new Date(start)) continue;
    if (end && now > new Date(end)) continue;

    const minQty = Number(d.minQuantity ?? d.min_qty ?? 0);
    if (qty < minQty) continue;

    const pct = d.discountPct ?? d.percentage ?? d.percent ?? d.percentOff;
    const amt = d.amount ?? d.amountOff ?? d.flat ?? null;

    let cut = 0;
    if (pct != null) {
      cut = (Number(pct) / 100) * unitPrice;
    } else if (amt != null) {
      cut = Number(amt);
    } else if (d.value != null) {
      const v = Number(d.value);
      cut = v <= 100 ? (v / 100) * unitPrice : v;
    }

    if (cut > best) best = cut;
  }
  return Math.min(best, unitPrice);
}

async function computeSummary(memberId) {
  const cart = await prisma.cart.findFirst({
    where: { memberId },
    include: {
      items: {
        include: {
          product: {
            include: {
              discounts: true,
            },
          },
        },
      },
    },
  });

  if (!cart || !cart.items?.length) {
    return {
      items: [],
      itemCount: 0,
      subtotal: 0,
      totalDiscount: 0,
      total: 0,
    };
  }

  let itemCount = 0;
  let subtotal = 0;
  let totalDiscount = 0;

  const items = cart.items.map((ci) => {
    const p = ci.product || {};
    const unitPrice = Number(p.unitPrice ?? p.price ?? p.original_price ?? 0);
    const qty = Number(ci.quantity || 0);

    const discountPerUnit = bestDiscountPerUnit(unitPrice, qty, p.discounts);

    const finalUnitPrice = unitPrice - discountPerUnit;

    const lineSubtotal = unitPrice * qty;
    const lineDiscount = discountPerUnit * qty;
    const lineTotal = finalUnitPrice * qty;

    itemCount += qty;
    subtotal += lineSubtotal;
    totalDiscount += lineDiscount;

    return {
      productId: ci.productId,
      quantity: qty,
      unitPrice,
      discountPerUnit,
      finalUnitPrice,
      lineSubtotal,
      lineDiscount,
      lineTotal,
      product: {
        description: p.description,
        country: p.country,
      },
    };
  });

  const total = subtotal - totalDiscount;

  return { items, itemCount, subtotal, totalDiscount, total };
}

async function placeOrdersForMember(memberId) {
  await prisma.$executeRaw`CALL place_orders(${memberId}::int)`;
}

async function confirm(memberId) {
  const before = await computeSummary(memberId);
  const beforeCount = before.itemCount; 


  await placeOrdersForMember(memberId);


  const after = await computeSummary(memberId);
  const afterCount = after.itemCount;


  let message;
  if (beforeCount === 0) {
    message = "Your cart is empty.";
  } else if (afterCount === beforeCount) {
    message = "No items were placed due to insufficient stock. Cart remains unchanged for those items.";
  } else if (afterCount > 0) {
    message = "Some items were placed; others lacked stock and were left in the cart.";
  } else {
    message = "Order placement completed. All items were processed successfully.";
  }

  return { message, summary: after };
}


module.exports = { computeSummary, confirm };
