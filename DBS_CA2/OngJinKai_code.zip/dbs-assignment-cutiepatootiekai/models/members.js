const { query } = require('../database');

module.exports.isAdmin = function isAdmin(memberId) {
    const sql = `SELECT * FROM member m JOIN member_role r ON m.role=r.id WHERE m.id = $1 AND role = 2`;
    return query(sql, [memberId])
        .then(function (result) {
            const rows = result.rows;
            console.log(rows, rows.length);
            if (rows.length == 1)
                return true;
            return false;
        })
        .catch(function (error) {
            throw error;
        });
};

module.exports.retrieveByUsername = function retrieveByUsername(username) {
    const sql = 'SELECT * FROM member WHERE username = $1';
    return query(sql, [username]).then(function (result) {
        const rows = result.rows;
        return rows[0];
    });
};

module.exports.retrieveSalesOrderSummary = function retrieveSalesOrderSummary(params) {
    const sql = `
        SELECT * FROM get_sale_order_summary(
            $1,  -- gender
            $2,  -- product_type
            $3,  -- age_min
            $4,  -- age_max
            $5,  -- date_from
            $6,  -- date_to
            $7,  -- min_total_spending
            $8,  -- min_order_count
            $9,  -- sort_by
            $10  -- sort_order
        )
    `;
    
    const values = [
        params.gender || null,
        params.product_type || null,
        params.age_min || null,
        params.age_max || null,
        params.date_from || null,
        params.date_to || null,
        params.min_total_spending || null,
        params.min_order_count || null,
        params.sort_by,
        params.sort_order
    ];

    return query(sql, values)
        .then(function(result) {
            return result.rows;
        })
        .catch(function(error) {
            console.error('Error in retrieveSalesOrderSummary:', error);
            throw error;
        });
};