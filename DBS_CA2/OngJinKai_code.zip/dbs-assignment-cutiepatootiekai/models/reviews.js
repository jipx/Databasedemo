const  pool  = require('../database');
const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');


module.exports.createReview = (data, callback) =>
{
    const SQLSTATMENT = `
   CALL create_review($1, $2, $3, $4, $5);
    `;
    const VALUES = [ parseInt(data.memberId), parseInt(data.productId), parseInt(data.orderId), parseInt(data.rating), data.reviewText];

    pool.query(SQLSTATMENT, VALUES, callback);
};

module.exports.selectAll = (data,callback) => {
    const SQLSTATMENT = `
    SELECT * FROM get_reviews($1); `;
const VALUES = [data.memberId];
    pool.query(SQLSTATMENT,VALUES, callback);

};

module.exports.updateReview = (data,callback) => {
    const SQLSTATMENT = `
    CALL update_review($1, $2, $3, $4);`;

    const VALUES = [data.reviewId,data.memberId,data.rating,data.reviewText];
    pool.query(SQLSTATMENT,VALUES, callback);
}

module.exports.deleteReview = (data,callback) => {
    const SQLSTATMENT = `
    CALL delete_review($1,$2);`;
    const VALUES=[data.reviewId,data.memberId];
    pool.query(SQLSTATMENT,VALUES, callback);
    
}
module.exports.getReviewById = (data,callback) => {
    
    const SQLSTATMENT = `
    SELECT * FROM getReviewsById($1)`
    const VALUES = [data.productId];
    pool.query(SQLSTATMENT,VALUES, callback);
    
}