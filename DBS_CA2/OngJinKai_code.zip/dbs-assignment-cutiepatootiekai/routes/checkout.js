// routes/checkout.js
const express = require("express");
const router = express.Router();
const jwtMiddleware = require("../middleware/jwtMiddleware");
const checkoutController = require("../controllers/checkoutController");

router.use(jwtMiddleware.verifyToken);

router.get("/summary", checkoutController.getCheckoutSummary);
router.post("/confirm", checkoutController.confirmCheckout);

module.exports = router;
