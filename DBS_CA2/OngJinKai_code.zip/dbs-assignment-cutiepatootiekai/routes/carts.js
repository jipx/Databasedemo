const express = require("express");
const ctrl = require("../controllers/cartsController");
const jwtMiddleware = require("../middleware/jwtMiddleware");

const router = express.Router();
router.use(jwtMiddleware.verifyToken);

// routes/carts.js
router.post("/items", ctrl.createCartItems);
router.get("/items", ctrl.retrieveCartItems);
router.put("/items/:productId", ctrl.updateCartItems);
router.delete("/items/:productId", ctrl.deleteCartItems);

// add this:
router.get("/summary", ctrl.getCartSummary);

module.exports = router;
