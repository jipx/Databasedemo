// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const router = express.Router();

const commentsController = require('../controllers/commentsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

router.post('/reply',commentsController.createReply)
router.post('/',commentsController.createComment);
router.get('/:reviewId',commentsController.readAllComments);
router.delete('/:commentId',commentsController.deleteComment);
router.get('/reply/:parentId',commentsController.readReplies);
router.use(jwtMiddleware.verifyToken);


module.exports = router;