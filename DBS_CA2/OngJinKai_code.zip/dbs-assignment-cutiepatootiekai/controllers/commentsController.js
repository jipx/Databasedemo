const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const commentsModel = require('../models/comments');

module.exports.createComment = (req, res, next) => {
  const data = {
    memberId: req.body.memberId,
    reviewId: req.body.reviewId,
    commentText: req.body.commentText
  };
  console.log(data);

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error createComments:", error);
      res.status(500).json(error);
    } else res.status(200).json(results);
  };
  commentsModel.createComment(data, callback);
};

// In your controller
module.exports.createReply = (req, res, next) => {
  const data = {
    memberId: req.body.memberId,
    parentId: req.body.parentId,
    commentText: req.body.text 
  };

  const callback = (error, results) => {
    if (error) {
      // Extract clean error message
      const errorMsg = error.message.replace(/^ERROR:\s*/, '');
      
      if (errorMsg.includes('cannot be empty')) {
        res.status(400).json({ success: false, message: errorMsg });
      } else if (errorMsg.includes('not exist')) {
        res.status(404).json({ success: false, message: errorMsg });
      } else {
        res.status(500).json({ success: false, message: errorMsg });
      }
    } else {
      res.status(201).json({ 
        success: true, 
        message: 'Reply posted successfully'
      });
    }
  };

  commentsModel.createReply(data, callback);
};

module.exports.readAllComments = (req, res, next) => {
  const data = {
    reviewId: req.params.reviewId
  };
  
  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error readAllComments:", error);
      res.status(500).json(error);
    } else {
      res.status(200).json(results);
    }
  };

  commentsModel.selectAll(data, callback);
};

module.exports.readReplies = (req, res, next) => {
  const data = {
    parentId: req.params.parentId
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error readReplies:", error);
      res.status(500).json(error);
    } else {
      res.status(200).json(results);
    }
  };

  commentsModel.selectReplies(data, callback);
};

module.exports.deleteComment = (req, res, next) => {
  const data = {
    commentId: req.params.commentId,
    memberId: req.body.memberId
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error deleteComment:", error);
      res.status(500).json(error);
    } else {
      res.status(204).send();
    }
  };

  commentsModel.deleteComment(data, callback);
};