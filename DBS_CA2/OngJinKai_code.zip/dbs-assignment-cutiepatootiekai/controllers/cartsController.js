// controllers/cartsController.js
const cartsModel = require("../models/carts");

module.exports.createCartItems = async function (req, res) {
  try {
    const { memberId, productId, quantity = 1 } = req.body || {};
    if (memberId == null)
      return res.status(400).json({ error: "memberId is required" });
    if (productId == null)
      return res.status(400).json({ error: "productId is required" });

    const item = await cartsModel.addToCart(memberId, productId, quantity);
    res.status(201).json(item);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};

module.exports.updateCartItems = async function (req, res) {
  try {
    const memberId = parseInt(req.body.memberId);
    const quantity = parseInt(req.body.quantity);
    const productId = parseInt(req.params.productId);

    if (!Number.isInteger(memberId))
      return res.status(400).json({ error: "memberId is required" });
    if (!Number.isInteger(productId))
      return res.status(400).json({ error: "productId is required" });
    if (!Number.isInteger(quantity) || quantity <= 0) {
      return res
        .status(400)
        .json({ error: "quantity must be a positive integer" });
    }

    const item = await cartsModel.updateLine(memberId, productId, quantity);
    res.json(item);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};

module.exports.retrieveCartItems = async function (req, res) {
  try {
    const memberId = Number(req.query.memberId || req.body.memberId);
    if (!memberId)
      return res.status(400).json({ error: "memberId is required" });

    const cart = await cartsModel.getCart(memberId);
    res.json(cart.items);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};

module.exports.deleteCartItems = async function (req, res) {
  try {
    const memberId = parseInt(req.query.memberId || req.body.memberId);
    const productId = parseInt(req.params.productId);

    if (!Number.isInteger(memberId))
      return res.status(400).json({ error: "memberId is required" });
    if (!Number.isInteger(productId))
      return res.status(400).json({ error: "productId is required" });

    await cartsModel.removeLine(memberId, productId);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};

module.exports.getCartSummary = async function (req, res) {
  try {
    const memberId = Number(req.query.memberId || req.body.memberId);
    if (!memberId)
      return res.status(400).json({ error: "memberId is required" });

    const summary = await cartsModel.getSummary(memberId);
    res.json(summary);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};
