// controllers/checkoutController.js
const checkoutModel = require("../models/checkout");

// get memberId from JWT or body/query
function getMemberId(req) {
  const mid =
    req.user?.memberId ??
    req.user?.id ??
    (req.body?.memberId != null ? Number(req.body.memberId) : undefined) ??
    (req.query?.memberId != null ? Number(req.query.memberId) : undefined);

  if (!Number.isFinite(mid)) {
    const err = new Error("memberId is required");
    err.status = 400;
    throw err;
  }
  return mid;
}

async function getCheckoutSummary(req, res) {
  try {
    const memberId = getMemberId(req);
    const summary = await checkoutModel.computeSummary(memberId);
    res.json(summary);
  } catch (err) {
    console.error(err);
    res
      .status(err.status || 500)
      .json({ error: err.message || "Server error" });
  }
}

async function confirmCheckout(req, res) {
  try {
    const memberId = getMemberId(req);
    const result = await checkoutModel.confirm(memberId);
    res.json(result);
  } catch (err) {
    console.error(err);
    res
      .status(err.status || 500)
      .json({ error: err.message || "Server error" });
  }
}

module.exports = {
  getCheckoutSummary,
  confirmCheckout,
};
