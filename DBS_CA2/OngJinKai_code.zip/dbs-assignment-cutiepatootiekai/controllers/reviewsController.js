const {
  EMPTY_RESULT_ERROR,
  UNIQUE_VIOLATION_ERROR,
  DUPLICATE_TABLE_ERROR,
} = require("../errors");
const reviewsModel = require("../models/reviews");

module.exports.createReview = (req, res, next) => {
  const data = {
    memberId: req.body.memberId,
    productId: req.body.productId,
    orderId: req.body.orderId,
    rating: req.body.rating,
    reviewText: req.body.reviewText
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error createReviews:", error);
      res.status(500).json(error); // Handle database error
    } else res.status(200).json(results);
  };
  reviewsModel.createReview(data, callback);
};

module.exports.getAllReviews = (req, res, next) => {
  const data = {
    memberId: req.params.memberId
  }
  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error getAllReviews:", error);
      res.status(500).json(error); // Handle database error
    } else res.status(200).json(results); // Successfully retrieved all reviews
  };

  reviewsModel.selectAll(data,callback); // Fetch all reviews
};

module.exports.updateReview = (req, res, next) => {
  const data = {
    memberId: req.body.memberId,
    reviewId: req.body.reviewId,
    rating: req.body.rating,
    reviewText: req.body.reviewText,
  };
  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error updateReview:", error);
      res.status(500).json(error);
    }

    return res.status(204).send();
  };
  reviewsModel.updateReview(data, callback);
};

module.exports.deleteReview = (req, res, next) => {
    const data={
        memberId:req.body.memberId,
        reviewId:req.body.reviewId
    }
    const callback = (error,results,fields) =>{
        if(error){
            console.error("Error deleteReview:", error);
            res.status(500).json(error);
        }else{
    return res.status(204).send();}
    
    }
    reviewsModel.deleteReview(data, callback);
}
module.exports.getReviewById = (req, res, next) => {
    
    const data = {
        productId: req.params.productId
    }
  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error getAllReviews:", error);
      res.status(500).json(error); // Handle database error
    } else res.status(200).json(results); // Successfully retrieved all reviews
  };

  reviewsModel.getReviewById(data,callback); // Fetch all reviews
};